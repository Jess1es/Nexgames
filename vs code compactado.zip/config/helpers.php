
<?php
/**
 * NEXGAMES — FUNÇÕES AUXILIARES
 * Arquivo: config/helpers.php
 *
 * Incluído pelo index.php com require_once.
 */

if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

/**
 * Erro de regra de negócio.
 */
class RegraNegocioException extends Exception {}

/**
 * Escapa texto para HTML.
 */
function e($valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/**
 * Formata valores monetários.
 */
function moeda($valor): string
{
    return "R$\u{00A0}" .
        number_format((float) $valor, 2, ',', '.');
}

/**
 * Remove caracteres que não são números.
 */
function somenteDigitos($valor): string
{
    return preg_replace('/\D+/', '', (string) $valor);
}

/**
 * Monta URLs internas da NexGames.
 */
function url(
    string $controller,
    string $action = 'index',
    array $params = []
): string {
    $query = array_merge(
        [
            'controller' => $controller,
            'action' => $action
        ],
        $params
    );

    return 'index.php?' . http_build_query($query);
}

/**
 * Redireciona para outra página.
 */
function redirecionar(string $destino): void
{
    header('Location: ' . $destino);
    exit;
}

/* ==========================================================
   IMAGENS DOS PRODUTOS
   ========================================================== */

/**
 * Retorna a imagem do jogo.
 *
 * 1. Procura imagem enviada para o produto.
 * 2. Verifica o caminho salvo no banco, se existir.
 * 3. Usa sem-img.png como imagem padrão.
 *
 * Compatível com:
 * imagemProduto($id)
 * imagemProduto($id, $imagem)
 */
function imagemProduto(
    int $produtoId,
    ?string $imagem = null
): string {

    $pasta = 'public/uploads/produtos/';

    // Procura imagem do produto pelo ID.
    foreach (['jpg', 'jpeg', 'png', 'webp', 'svg'] as $ext) {

        $relativo = $pasta . $produtoId . '.' . $ext;

        if (is_file(BASE_PATH . '/' . $relativo)) {
            return $relativo;
        }
    }

    // Verifica a imagem cadastrada no banco.
    if ($imagem !== null && trim($imagem) !== '') {

        $caminho = trim($imagem);

        // Aceita apenas caminhos locais.
        if (
            !preg_match('~^(?:https?:)?//~i', $caminho)
            && strpos($caminho, '..') === false
        ) {
            $relativo = ltrim(
                str_replace('\\', '/', $caminho),
                '/'
            );

            if (is_file(BASE_PATH . '/' . $relativo)) {
                return $relativo;
            }
        }
    }

    // Nova imagem padrão da NexGames.
    return 'public/assets/img/sem-img.png';
}

/* ==========================================================
   CPF
   ========================================================== */

/**
 * Valida CPF.
 */
function validarCpf(string $cpf): bool
{
    $cpf = somenteDigitos($cpf);

    if (
        strlen($cpf) !== 11 ||
        preg_match('/^(\d)\1{10}$/', $cpf)
    ) {
        return false;
    }

    for ($t = 9; $t < 11; $t++) {

        $soma = 0;

        for ($i = 0; $i < $t; $i++) {
            $soma += (int) $cpf[$i] * (($t + 1) - $i);
        }

        $digito = ((10 * $soma) % 11) % 10;

        if ((int) $cpf[$t] !== $digito) {
            return false;
        }
    }

    return true;
}

/**
 * Formata CPF.
 */
function formatarCpf(string $cpf): string
{
    $cpf = somenteDigitos($cpf);

    if (strlen($cpf) !== 11) {
        return $cpf;
    }

    return substr($cpf, 0, 3) . '.' .
           substr($cpf, 3, 3) . '.' .
           substr($cpf, 6, 3) . '-' .
           substr($cpf, 9, 2);
}

/**
 * Formata telefone.
 */
function formatarTelefone(?string $telefone): string
{
    $t = somenteDigitos((string) $telefone);

    if (strlen($t) === 11) {
        return '(' . substr($t, 0, 2) . ') ' .
               substr($t, 2, 5) . '-' .
               substr($t, 7);
    }

    if (strlen($t) === 10) {
        return '(' . substr($t, 0, 2) . ') ' .
               substr($t, 2, 4) . '-' .
               substr($t, 6);
    }

    return (string) $telefone;
}

/* ==========================================================
   MENSAGENS FLASH
   ========================================================== */

function flash(string $tipo, string $mensagem): void
{
    $_SESSION['flash'][] = [
        'tipo' => $tipo,
        'msg' => $mensagem
    ];
}

function pegarFlashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];

    unset($_SESSION['flash']);

    return $flashes;
}

/* ==========================================================
   SEGURANÇA CSRF
   ========================================================== */

function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function csrfCampo(): string
{
    return '<input type="hidden" name="csrf" value="' .
           e(csrfToken()) .
           '">';
}

function csrfValido(): bool
{
    $enviado = $_POST['csrf'] ?? '';

    return is_string($enviado)
        && $enviado !== ''
        && hash_equals(csrfToken(), $enviado);
}

/**
 * Exige requisição POST com CSRF válido.
 */
function csrfExigir(): void
{
    if (
        ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST'
        || !csrfValido()
    ) {
        http_response_code(403);

        die(
            'Requisição inválida ou sessão expirada. ' .
            'Volte à página anterior, recarregue e tente novamente.'
        );
    }
}

/**
 * Permite somente redirecionamentos internos.
 */
function destinoInternoSeguro(
    ?string $destino,
    string $padrao
): string {
    if (
        $destino &&
        strpos($destino, 'index.php?') === 0
    ) {
        return $destino;
    }

    return $padrao;
}
