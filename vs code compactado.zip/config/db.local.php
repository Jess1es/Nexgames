<?php

return [
    'host' => 'sql209.infinityfree.com',
    'name' => 'if0_43314714_nexgames',
    'user' => 'if0_43314714',
    'pass' => 'nexgames1234',
];