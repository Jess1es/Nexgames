
<?php

require_once __DIR__ . '/SiteBaseController.php';
require_once __DIR__ . '/../models/ClienteSite.php';
require_once __DIR__ . '/../models/Pedido.php';
require_once __DIR__ . '/../models/MetodoPagamento.php';

class PedidoController extends SiteBaseController
{
    public function checkout(): void
    {
        $this->exigirLogin();

        $carrinho = new Carrinho();

        foreach ($carrinho->sincronizar() as $aviso) {
            flash('aviso', $aviso);
        }

        if ($carrinho->vazio()) {
            flash('aviso', 'Seu carrinho está vazio.');
            redirecionar(url('carrinho', 'index'));
            return;
        }

        $metodosSalvos = (new MetodoPagamento())->listar(
            $this->clienteCpf()
        );

        $this->render(
            'pagamento',
            [
                'carrinho' => $carrinho,
                'erro' => '',
                'metodosSalvos' => $metodosSalvos
            ],
            'Forma de pagamento'
        );
    }

    public function finalizar(): void
    {
        $this->exigirLogin();
        $this->exigirPost(url('pedido', 'checkout'));

        $carrinho = new Carrinho();

        foreach ($carrinho->sincronizar() as $aviso) {
            flash('aviso', $aviso);
        }

        if ($carrinho->vazio()) {
            flash('aviso', 'Seu carrinho está vazio.');
            redirecionar(url('carrinho', 'index'));
            return;
        }

        $cpf = $this->clienteCpf();
        $metodoModel = new MetodoPagamento();

        $escolha = trim(
            (string) ($_POST['metodo'] ?? '')
        );

        $idMetodoSalvo = 0;
        $formaPagamento = '';
        $tipoParaSalvar = null;
        $identificacao = null;
        $ultimosDigitos = null;

        if (preg_match(
            '/^salvo:([1-9][0-9]*)$/',
            $escolha,
            $matches
        )) {
            $idMetodoSalvo = (int) $matches[1];

            $metodoSalvo = $metodoModel->buscar(
                $idMetodoSalvo,
                $cpf
            );

            if (!$metodoSalvo) {
                flash(
                    'erro',
                    'Método de pagamento não encontrado.'
                );
                redirecionar(url('pedido', 'checkout'));
                return;
            }

            $formaPagamento =
                $metodoSalvo['tipo'] === 'pix'
                    ? 'pix'
                    : 'cartao';

        } elseif ($escolha === 'cartao') {
            // Dados demonstrativos: nunca salvar CVV
            // ou o número completo do cartão.
            $numero = somenteDigitos(
                (string) ($_POST['numero_cartao'] ?? '')
            );

            $nome = trim(
                (string) ($_POST['nome_cartao'] ?? '')
            );

            $validade = trim(
                (string) ($_POST['validade_cartao'] ?? '')
            );

            $cvv = somenteDigitos(
                (string) ($_POST['cvv_cartao'] ?? '')
            );

            if (
                strlen($numero) !== 16 ||
                $nome === '' ||
                $validade === '' ||
                !preg_match('/^[0-9]{3,4}$/', $cvv)
            ) {
                flash(
                    'erro',
                    'Preencha os dados demonstrativos do cartão.'
                );
                redirecionar(url('pedido', 'checkout'));
                return;
            }

            $formaPagamento = 'cartao';
            $tipoParaSalvar = 'credito';
            $identificacao = mb_substr($nome, 0, 100);
            $ultimosDigitos = substr($numero, -4);

        } elseif ($escolha === 'pix') {
            $formaPagamento = 'pix';
            $tipoParaSalvar = 'pix';
            $identificacao = 'Pix';

        } else {
            flash('erro', 'Selecione uma forma de pagamento.');
            redirecionar(url('pedido', 'checkout'));
            return;
        }

        try {
            $pedidoId = (new Pedido())->criar(
                $cpf,
                $carrinho->itens(),
                $formaPagamento
            );

        } catch (RegraNegocioException $ex) {
            flash('erro', $ex->getMessage());
            redirecionar(url('carrinho', 'index'));
            return;

        } catch (Throwable $ex) {
            error_log(
                '[NexGames] Erro ao criar pedido: ' .
                $ex->getMessage()
            );

            flash(
                'erro',
                'Não foi possível criar o pedido.'
            );
            redirecionar(url('carrinho', 'index'));
            return;
        }

        if (
            $idMetodoSalvo === 0 &&
            $tipoParaSalvar !== null
        ) {
            try {
                $metodoModel->salvarSeNaoExistir(
                    $cpf,
                    $tipoParaSalvar,
                    $identificacao,
                    $ultimosDigitos
                );
            } catch (Throwable $ex) {
                error_log(
                    '[NexGames] Erro ao salvar método: ' .
                    $ex->getMessage()
                );
            }
        }

        $carrinho->limpar();

        // Permite concluir somente a compra
        // recém-criada por esta sessão.
        $_SESSION['pedido_simulado_pendente'] = [
            'id' => $pedidoId,
            'cpf' => $cpf,
            'inicio' => time()
        ];

        redirecionar(
            url('pedido', 'aguardandoPagamento', [
                'id' => $pedidoId
            ])
        );
    }

    public function aguardandoPagamento(): void
    {
        $this->exigirLogin();

        $idPedido = (int) ($_GET['id'] ?? 0);
        $cpf = $this->clienteCpf();

        $pedido = (new Pedido())->buscarDoCliente(
            $idPedido,
            $cpf
        );

        if (!$pedido) {
            http_response_code(404);
            $this->render(
                'nao_encontrado',
                ['mensagem' => 'Pedido não encontrado.'],
                'Pedido não encontrado'
            );
            return;
        }

        if (
            ($pedido['status'] ?? '') === 'pago' &&
            ($pedido['pagamento']['status'] ?? '') === 'aprovado'
        ) {
            redirecionar(
                url('pedido', 'confirmacao', [
                    'id' => $idPedido
                ])
            );
            return;
        }

        $pendente = $_SESSION['pedido_simulado_pendente'] ?? [];

        if (
            (int) ($pendente['id'] ?? 0) !== $idPedido ||
            ($pendente['cpf'] ?? '') !== $cpf
        ) {
            flash(
                'erro',
                'Esta simulação não está mais disponível.'
            );
            redirecionar(url('pedido', 'meusPedidos'));
            return;
        }

        $decorridos = max(
            0,
            time() - (int) ($pendente['inicio'] ?? time())
        );

        $restantes = max(0, 5 - $decorridos);

        if ($restantes === 0) {
            $this->concluirPagamentoSimulado($idPedido, $cpf);
            return;
        }

        $this->render(
            'aguardando_pagamento',
            [
                'pedido' => $pedido,
                'segundosRestantes' => $restantes
            ],
            'Aguardando pagamento'
        );
    }

    public function concluirPagamentoSimulado(
        ?int $pedidoIdInterno = null,
        ?string $cpfInterno = null
    ): void {
        $this->exigirLogin();

        $idPedido = $pedidoIdInterno ??
            (int) ($_GET['id'] ?? 0);

        $cpf = $cpfInterno ?? $this->clienteCpf();

        if ($cpf !== $this->clienteCpf()) {
            http_response_code(403);
            return;
        }

        $pendente = $_SESSION['pedido_simulado_pendente'] ?? [];

        if (
            (int) ($pendente['id'] ?? 0) !== $idPedido ||
            ($pendente['cpf'] ?? '') !== $cpf
        ) {
            flash(
                'erro',
                'A confirmação desta compra não está disponível.'
            );
            redirecionar(url('pedido', 'meusPedidos'));
            return;
        }

        $inicio = (int) ($pendente['inicio'] ?? 0);

        if ($inicio <= 0 || time() - $inicio < 5) {
            redirecionar(
                url('pedido', 'aguardandoPagamento', [
                    'id' => $idPedido
                ])
            );
            return;
        }

        try {
            $aprovado = (new Pedido())->aprovarSimulado(
                $idPedido,
                $cpf
            );

            if (!$aprovado) {
                flash(
                    'erro',
                    'Não foi possível aprovar o pagamento simulado.'
                );
                redirecionar(url('pedido', 'meusPedidos'));
                return;
            }

            unset($_SESSION['pedido_simulado_pendente']);

            redirecionar(
                url('pedido', 'confirmacao', [
                    'id' => $idPedido
                ])
            );

        } catch (Throwable $ex) {
            error_log(
                '[NexGames] Erro na aprovação simulada: ' .
                $ex->getMessage()
            );

            flash(
                'erro',
                'Não foi possível concluir a simulação.'
            );

            redirecionar(url('pedido', 'meusPedidos'));
        }
    }

    public function confirmacao(): void
    {
        $this->exigirLogin();

        $pedido = (new Pedido())->buscarDoCliente(
            (int) ($_GET['id'] ?? 0),
            $this->clienteCpf()
        );

        if (!$pedido) {
            http_response_code(404);

            $this->render(
                'nao_encontrado',
                ['mensagem' => 'Pedido não encontrado.'],
                'Pedido não encontrado'
            );
            return;
        }

        if (
            ($pedido['status'] ?? '') === 'aguardando_pagamento'
        ) {
            redirecionar(
                url('pedido', 'aguardandoPagamento', [
                    'id' => (int) $pedido['id']
                ])
            );
            return;
        }

        $this->render(
            'confirmacao',
            ['pedido' => $pedido],
            'Pedido realizado'
        );
    }

    public function verNota(): void
    {
        $this->exigirLogin();

        $idPedido = (int) ($_GET['id'] ?? 0);
        $cpf = $this->clienteCpf();

        if ($idPedido <= 0) {
            http_response_code(400);
            exit('Pedido inválido.');
        }

        try {
            $pedido = (new Pedido())->buscarDoCliente(
                $idPedido,
                $cpf
            );

            if (!$pedido) {
                http_response_code(404);

                $this->render(
                    'nao_encontrado',
                    ['mensagem' => 'Pedido não encontrado.'],
                    'Pedido não encontrado'
                );
                return;
            }

            if (
                ($pedido['status'] ?? '') !== 'pago' ||
                ($pedido['pagamento']['status'] ?? '') !== 'aprovado'
            ) {
                flash(
                    'aviso',
                    'A nota estará disponível após a aprovação.'
                );

                redirecionar(
                    url('pedido', 'confirmacao', [
                        'id' => $idPedido
                    ])
                );
                return;
            }

            require_once __DIR__ . '/../models/NotaFiscal.php';
            require_once __DIR__ . '/../models/Venda.php';

            $notaModel = new NotaFiscal();

            $nota = $notaModel->buscarPorPedido($idPedido);

            // Emite a nota caso o pedido esteja pago
            // e ainda não exista uma nota fiscal.
            if (!$nota) {
                $notaModel->emitirParaPedido($idPedido);
                $nota = $notaModel->buscarPorPedido($idPedido);
            }

            if (!$nota) {
                throw new RuntimeException(
                    'Não foi possível localizar a nota fiscal.'
                );
            }

            $venda = (new Venda())->buscarPorId($idPedido);

            if (!$venda) {
                throw new RuntimeException(
                    'Dados da compra não encontrados.'
                );
            }

            // Garante que a nota pertence ao
            // cliente que está autenticado.
            if (($venda['cliente_cpf'] ?? '') !== $cpf) {
                http_response_code(403);
                exit('Acesso não autorizado.');
            }

            require __DIR__ . '/../views/nota_fiscal_venda.php';

        } catch (Throwable $ex) {
            // Registra o erro sem mostrar detalhes
            // internos do servidor ao visitante.
            error_log(
                '[NexGames] Erro ao visualizar nota fiscal do pedido #' .
                $idPedido . ': ' . $ex->getMessage()
            );

            http_response_code(500);

            echo 'Não foi possível carregar a nota fiscal. '
               . 'Tente novamente mais tarde.';
        }
    }

    public function meusPedidos(): void
    {
        $this->exigirLogin();

        $pedidos = (new Pedido())->listarDoCliente(
            $this->clienteCpf()
        );

        $this->render(
            'meus_pedidos',
            ['pedidos' => $pedidos],
            'Meus pedidos'
        );
    }

    public function meusJogos(): void
    {
        $this->exigirLogin();

        $cpf = $this->clienteCpf();
        $pedidoModel = new Pedido();
        $vitrine = new Vitrine();

        $pedidos = $pedidoModel->listarDoCliente($cpf);
        $jogos = [];
        $idsAdicionados = [];

        foreach ($pedidos as $pedidoResumo) {
            if (($pedidoResumo['status'] ?? '') !== 'pago') {
                continue;
            }

            $pedido = $pedidoModel->buscarDoCliente(
                (int) $pedidoResumo['id'],
                $cpf
            );

            if (
                !$pedido ||
                ($pedido['pagamento']['status'] ?? '') !== 'aprovado'
            ) {
                continue;
            }

            foreach ($pedido['itens'] as $item) {
                $produtoId = (int) $item['produto_id'];

                if (isset($idsAdicionados[$produtoId])) {
                    continue;
                }

                $idsAdicionados[$produtoId] = true;

                $produto = $vitrine->buscarProduto($produtoId);
                $categorias = [];

                if ($produto) {
                    foreach (
                        ($produto['categorias'] ?? []) as $categoria
                    ) {
                        if (!empty($categoria['nome'])) {
                            $categorias[] = $categoria['nome'];
                        }
                    }
                }

                $jogos[] = [
                    'id' => $produtoId,
                    'nome' => $item['produto_nome'],
                    'imagem' => imagemProduto(
                        $produtoId,
                        $item['imagem']
                    ),
                    'categorias' => implode(', ', $categorias),
                    'data_compra' => $pedido['data'] ?? null
                ];
            }
        }

        $this->render(
            'meus_jogos',
            ['jogos' => $jogos],
            'Meus jogos'
        );
    }
}
