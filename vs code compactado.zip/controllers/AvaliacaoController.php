
<?php
/**
 * NexGames — Controller de avaliações.
 * Arquivo: controllers/AvaliacaoController.php
 *
 * Responsável por registrar as avaliações
 * dos jogos realizadas pelos clientes.
 */

require_once __DIR__ . '/SiteBaseController.php';
require_once __DIR__ . '/../models/Avaliacao.php';

class AvaliacaoController extends SiteBaseController
{
    /**
     * Salva a avaliação de um jogo.
     * Recebe o produto, a nota e o comentário.
     */
    public function salvar(): void
    {
        $produtoId = (int) (
            $_POST['produto_id'] ?? 0
        );

        $voltar = url(
            'loja',
            'produto',
            ['id' => $produtoId]
        ) . '#avaliacoes';

        // Verifica o método POST e o token CSRF.
        $this->exigirPost($voltar);

        // Permite avaliações somente de clientes autenticados.
        $this->exigirLogin();

        $cpf = $this->clienteCpf();

        $nota = filter_var(
            $_POST['nota'] ?? null,
            FILTER_VALIDATE_INT
        );

        $comentario = $_POST['comentario'] ?? '';

        try {
            if ($nota === false || $nota === null) {
                throw new RegraNegocioException(
                    'Selecione uma nota válida.'
                );
            }

            if (!is_string($comentario)) {
                throw new RegraNegocioException(
                    'Comentário inválido.'
                );
            }

            $avaliacao = new Avaliacao();

            $avaliacao->salvar(
                $cpf,
                $produtoId,
                (int) $nota,
                $comentario
            );

            flash(
                'sucesso',
                'Sua avaliação foi publicada com sucesso!'
            );

        } catch (RegraNegocioException $e) {

            flash('erro', $e->getMessage());

        }

        redirecionar($voltar);
    }
}
