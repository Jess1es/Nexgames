<?php

require_once __DIR__ . '/../models/entrada.php';

class EntradaController
{
    public function index(): void
    {
        $this->exigirAdmin();

        $model = new Entrada();

        $entradas = $model->listarComFornecedor();

        $itensPorEntrada = [];

        foreach ($entradas as $entrada) {
            $idEntrada = (int) $entrada['id'];

            $itensPorEntrada[$idEntrada] =
                $model->buscarItens($idEntrada);
        }

        $fornecedores = $model->listarFornecedoresAtivos();
        $produtos = $model->listarJogosAtivos();

        require_once __DIR__ . '/../views/entradas.php';
    }

    public function salvar(): void
    {
        $this->exigirAdmin();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit('Método não permitido.');
        }

        csrfExigir();

        try {
            $fornecedorId = filter_var(
                $_POST['fornecedor_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            $status = (string) (
                $_POST['status'] ?? 'confirmada'
            );

            $ids = $_POST['id_produto'] ?? [];
            $quantidades = $_POST['quantidade'] ?? [];
            $valores = $_POST['valor_unitario'] ?? [];

            if (
                !$fornecedorId ||
                !is_array($ids) ||
                !is_array($quantidades) ||
                !is_array($valores) ||
                count($ids) !== count($quantidades) ||
                count($ids) !== count($valores) ||
                count($ids) > 100
            ) {
                throw new InvalidArgumentException(
                    'Dados do formulário inválidos.'
                );
            }

            $itens = [];

            foreach ($ids as $indice => $idBruto) {
                $id = filter_var(
                    $idBruto,
                    FILTER_VALIDATE_INT
                );

                $quantidade = filter_var(
                    $quantidades[$indice] ?? null,
                    FILTER_VALIDATE_INT
                );

                $centavos = $this->converterCentavos(
                    $valores[$indice] ?? null
                );

                if (!$id || !$quantidade || $quantidade < 1) {
                    throw new InvalidArgumentException(
                        'Selecione jogos e quantidades válidos.'
                    );
                }

                $itens[] = [
                    'id_produto' => (int) $id,
                    'quantidade' => (int) $quantidade,
                    'valor_centavos' => $centavos,
                ];
            }

            $idEntrada = (new Entrada())->registrar(
                (int) $fornecedorId,
                $itens,
                $status
            );

            $_SESSION['sucesso_entrada'] =
                "Entrada #{$idEntrada} registrada com sucesso!";

        } catch (InvalidArgumentException $e) {
            $_SESSION['erro_entrada'] = $e->getMessage();

        } catch (Throwable $e) {
            error_log(
                '[NexGames entradas] ' . $e->getMessage()
            );

            $_SESSION['erro_entrada'] =
                'Não foi possível registrar a entrada. '
                . 'Verifique se a tabela de itens foi criada.';
        }

        header('Location: ' . url('entrada', 'index'));
        exit;
    }

    private function converterCentavos($valor): int
    {
        if (!is_string($valor) && !is_numeric($valor)) {
            throw new InvalidArgumentException(
                'Valor unitário inválido.'
            );
        }

        $valor = trim((string) $valor);

        // Aceita 123,45 ou 123.45.
        // Não aceita separadores de milhares.
        if (!preg_match('/^\d{1,7}([.,]\d{1,2})?$/', $valor)) {
            throw new InvalidArgumentException(
                'Use um valor como 19,90 '
                . '(sem separador de milhares).'
            );
        }

        $partes = preg_split('/[.,]/', $valor);

        return (int) $partes[0] * 100
            + (int) str_pad($partes[1] ?? '0', 2, '0');
    }

    private function exigirAdmin(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['usuario_id'])) {
            header('Location: ' . url('auth', 'form'));
            exit;
        }

        if (($_SESSION['perfil'] ?? '') !== 'admin') {
            http_response_code(403);
            exit('Acesso negado.');
        }
    }
}