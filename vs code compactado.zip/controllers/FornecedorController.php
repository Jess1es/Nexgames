
<?php
require_once __DIR__ . '/../models/fornecedor.php';

class FornecedorController
{
    public function index(): void
    {
        $this->check();
        $this->onlyAdmin();

        $fornecedorModel = new Fornecedor();
        $fornecedores = $fornecedorModel->listarTodos();

        $editar = null;
        if (isset($_GET['id'])) {
            $editar = $fornecedorModel->buscarPorId((int) $_GET['id']);
        }

        require_once __DIR__ . '/../views/fornecedores.php';
    }

    /** POST: id, nome, cnpj, telefone, email. */
    public function salvar(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id       = (int) ($_POST['id'] ?? 0);
        $nome     = trim($_POST['nome'] ?? '');
        $cnpj     = trim($_POST['cnpj'] ?? '');
        $telefone = trim($_POST['telefone'] ?? '');
        $email    = trim($_POST['email'] ?? '');

        $telefone = $telefone === '' ? null : $telefone;
        $email    = $email === '' ? null : $email;

        if ($nome === '' || mb_strlen($nome) > 100) {
            die("Nome do fornecedor é obrigatório (até 100 caracteres).");
        }

        if ($cnpj === '' || mb_strlen($cnpj) > 20) {
            die("O CNPJ é obrigatório (até 20 caracteres).");
        }

        if ($email !== null && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            die("Informe um e-mail válido.");
        }

        $fornecedorModel = new Fornecedor();

        if ($id > 0) {
            $fornecedorModel->atualizar($id, $nome, $cnpj, $telefone, $email);
        } else {
            $fornecedorModel->inserir($nome, $cnpj, $telefone, $email);
        }

        header("Location: index.php?controller=fornecedor&action=index");
        exit;
    }

    public function toggle(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id    = (int) ($_POST['id'] ?? 0);
        $ativo = (int) ($_POST['ativo'] ?? 1);

        if ($id <= 0) die("ID inválido.");

        (new Fornecedor())->setAtivo($id, $ativo === 1);

        header("Location: index.php?controller=fornecedor&action=index");
        exit;
    }

    private function check(): void
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?controller=auth&action=form");
            exit;
        }
    }

    private function onlyAdmin(): void
    {
        if (($_SESSION['perfil'] ?? '') !== 'admin') {
            die("Acesso negado.");
        }
    }
}
