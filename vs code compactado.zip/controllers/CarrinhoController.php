
<?php

require_once __DIR__ . '/SiteBaseController.php';

/**
 * NexGames — Carrinho de jogos digitais.
 *
 * Cada jogo pode aparecer uma única vez.
 */
class CarrinhoController extends SiteBaseController
{
    /**
     * Exibe os jogos adicionados ao carrinho.
     */
    public function index(): void
    {
        $carrinho = new Carrinho();

        foreach ($carrinho->sincronizar() as $aviso) {
            flash('aviso', $aviso);
        }

        $this->render(
            'carrinho',
            ['carrinho' => $carrinho],
            'Meu carrinho'
        );
    }

    /**
     * Adiciona um jogo ao carrinho.
     *
     * POST: produto_id, comprar_agora (opcional)
     */
    public function adicionar(): void
    {
        $produtoId = (int) ($_POST['produto_id'] ?? 0);

        $volta = url('carrinho', 'index');

        $this->exigirPost($volta);

        $paginaProduto = $produtoId > 0
            ? url('loja', 'produto', ['id' => $produtoId])
            : url('loja', 'index');

        try {
            $novo = (new Carrinho())->adicionar($produtoId);

        } catch (RegraNegocioException $ex) {

            flash('erro', $ex->getMessage());
            redirecionar($paginaProduto);
            return;
        }

        if (!empty($_POST['comprar_agora'])) {
            redirecionar(url('pedido', 'checkout'));
            return;
        }

        flash(
            $novo ? 'ok' : 'aviso',
            $novo
                ? 'Jogo adicionado ao carrinho.'
                : 'Esse jogo já está no seu carrinho.'
        );

        redirecionar($volta);
    }

    /**
     * Remove um jogo do carrinho.
     *
     * POST: produto_id
     */
    public function remover(): void
    {
        $volta = url('carrinho', 'index');

        $this->exigirPost($volta);

        $produtoId = (int) ($_POST['produto_id'] ?? 0);

        if ($produtoId <= 0) {
            flash('erro', 'Jogo inválido.');
            redirecionar($volta);
            return;
        }

        (new Carrinho())->remover($produtoId);

        flash('ok', 'Jogo removido do carrinho.');

        redirecionar($volta);
    }

    /**
     * Remove todos os jogos do carrinho.
     */
    public function limpar(): void
    {
        $volta = url('carrinho', 'index');

        $this->exigirPost($volta);

        (new Carrinho())->limpar();

        flash('ok', 'Carrinho esvaziado com sucesso.');

        redirecionar($volta);
    }
}
