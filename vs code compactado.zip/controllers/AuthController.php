
<?php

require_once __DIR__ . '/../models/usuario.php';
require_once __DIR__ . '/../models/ClienteSite.php';

class AuthController
{
    /**
     * Exibe a página de login de clientes e administradores.
     */
    public function form(): void
    {
        if (
            !empty($_SESSION['usuario_id'])
            && ($_SESSION['perfil'] ?? '') === 'admin'
        ) {
            redirecionar(url('auth', 'dashboard'));
            return;
        }

        if (!empty($_SESSION['cliente_id'])) {
            $this->voltarParaLoja();
            return;
        }

        $erro = $_SESSION['erro_login'] ?? '';
        $email = $_SESSION['email_login'] ?? '';

        unset(
            $_SESSION['erro_login'],
            $_SESSION['email_login']
        );

        require __DIR__ . '/../views/login.php';
    }

    /**
     * Autentica o usuário conforme seu tipo de acesso.
     */
    public function login(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirecionar(url('auth', 'form'));
            return;
        }

        csrfExigir();

        $email = mb_strtolower(
            trim((string) ($_POST['email'] ?? ''))
        );

        $senha = (string) ($_POST['senha'] ?? '');

        if (
            !filter_var($email, FILTER_VALIDATE_EMAIL)
            || $senha === ''
        ) {
            $this->erroLogin($email);
        }

        // Verifica o cadastro do administrador.
        $usuarioModel = new Usuario();
        $usuario = $usuarioModel->buscarPorEmail($email);

        if (
            $usuario
            && ($usuario['perfil'] ?? '') === 'admin'
        ) {
            $senhaGuardada = (string) $usuario['senha'];

            $senhaValida = password_verify(
                $senha,
                $senhaGuardada
            );

            // Compatibilidade com senhas antigas sem hash.
            $senhaLegada = false;

            if (
                empty(
                    password_get_info($senhaGuardada)['algo']
                )
            ) {
                $senhaValida = hash_equals(
                    $senhaGuardada,
                    $senha
                );

                $senhaLegada = $senhaValida;
            }

            if (
                (int) ($usuario['ativo'] ?? 0) !== 1
                || !$senhaValida
            ) {
                $this->erroLogin($email);
            }

            if (
                $senhaLegada
                || password_needs_rehash(
                    $senhaGuardada,
                    PASSWORD_DEFAULT
                )
            ) {
                $usuarioModel->atualizarSenhaHash(
                    (int) $usuario['id'],
                    password_hash(
                        $senha,
                        PASSWORD_DEFAULT
                    )
                );
            }

            session_regenerate_id(true);

            unset(
                $_SESSION['cliente_id'],
                $_SESSION['cliente_nome'],
                $_SESSION['redirect_apos_login']
            );

            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['perfil'] = 'admin';
            $_SESSION['nome'] = $usuario['nome'];

            redirecionar(url('auth', 'dashboard'));
            return;
        }

        // Verifica o cadastro do cliente.
        $clienteModel = new ClienteSite();

        $cliente = $clienteModel->autenticar(
            $email,
            $senha
        );

        if ($cliente) {
            session_regenerate_id(true);

            unset(
                $_SESSION['usuario_id'],
                $_SESSION['perfil'],
                $_SESSION['nome']
            );

            $_SESSION['cliente_id'] = $cliente['cpf'];
            $_SESSION['cliente_nome'] = $cliente['nome'];

            $this->voltarParaLoja();
            return;
        }

        $this->erroLogin($email);
    }

    /**
     * Exibe uma mensagem genérica para proteger os dados de acesso.
     */
    private function erroLogin(string $email): void
    {
        $_SESSION['erro_login'] =
            'E-mail ou senha incorretos.';

        $_SESSION['email_login'] = $email;

        redirecionar(url('auth', 'form'));
        exit;
    }

    /**
     * Retorna à página anterior ou à página inicial.
     */
    private function voltarParaLoja(): void
    {
        $destino = destinoInternoSeguro(
            $_SESSION['redirect_apos_login'] ?? null,
            url('loja', 'index')
        );

        unset($_SESSION['redirect_apos_login']);

        redirecionar($destino);
        exit;
    }

    /**
     * Exibe o painel administrativo da NexGames.
     */
    public function dashboard(): void
    {
        $this->onlyAdmin();

        require_once __DIR__ . '/../models/Relatorio.php';

        $relatorioModel = new Relatorio();

        $kpiVendasMes = $relatorioModel->kpiVendasMes();
        $kpiEntradasMes = $relatorioModel->kpiEntradasMes();
        $kpiTotalProdutos = $relatorioModel->kpiTotalProdutos();

        require_once __DIR__ . '/../views/dashboard.php';
    }

    /**
     * Encerra a sessão do administrador.
     */
    public function logout(): void
    {
        unset(
            $_SESSION['usuario_id'],
            $_SESSION['perfil'],
            $_SESSION['nome']
        );

        session_regenerate_id(true);

        redirecionar(url('loja', 'index'));
    }

    /**
     * Verifica se existe uma sessão administrativa.
     */
    public function check(): void
    {
        if (empty($_SESSION['usuario_id'])) {
            redirecionar(url('auth', 'form'));
            exit;
        }
    }

    /**
     * Restringe o acesso às páginas administrativas.
     */
    public function onlyAdmin(): void
    {
        $this->check();

        if (($_SESSION['perfil'] ?? '') !== 'admin') {
            http_response_code(403);
            die('Acesso negado.');
        }
    }
}
