
<?php
require_once __DIR__ . '/../models/usuario.php';

class UsuarioController
{
    /**
     * Exibe o formulário de cadastro de usuários.
     */
    public function create()
    {
        $this->exigirAdmin();

        require_once __DIR__ . '/../views/cadastro.php';
    }

    /**
     * Processa o cadastro de usuários.
     */
    public function store()
    {
        $this->exigirAdmin();
        csrfExigir();

        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $senhaPlana = $_POST['senha'] ?? '';

        if ($nome === '' || $email === '' || $senhaPlana === '') {
            die("Por favor, preencha todos os campos.");
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            die("Informe um e-mail válido.");
        }

        if (strlen($senhaPlana) < 8) {
            die("A senha precisa ter pelo menos 8 caracteres.");
        }

        $usuarioModel = new Usuario();

        if ($usuarioModel->buscarPorEmail($email)) {
            die("Já existe um usuário com esse e-mail.");
        }

        // Cadastra o usuário com o perfil definido no model.
        try {
            $sucesso = $usuarioModel->cadastrar(
                $nome,
                $email,
                password_hash($senhaPlana, PASSWORD_DEFAULT),
                Usuario::PERFIL_FUNCIONARIO,
                1
            );

        } catch (PDOException $e) {
            error_log('[usuario] ' . $e->getMessage());
            $sucesso = false;
        }

        if (!$sucesso) {
            die("Erro ao cadastrar o usuário no banco de dados.");
        }

        header("Location: index.php?controller=auth&action=dashboard");
        exit;
    }

    /**
     * Restringe o acesso aos administradores autenticados.
     */
    private function exigirAdmin(): void
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?controller=auth&action=form");
            exit;
        }

        if (($_SESSION['perfil'] ?? '') !== 'admin') {
            http_response_code(403);
            die("Acesso negado.");
        }
    }
}
