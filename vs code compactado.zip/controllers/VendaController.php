
<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Venda.php';

class VendaController
{
    /**
     * Lista os pedidos realizados na NexGames.
     */
    public function index(): void
    {
        $this->check();

        $vendas = (new Venda())->listarRecentes();

        require_once __DIR__ . '/../views/vendas.php';
    }

    /**
     * Visualiza os detalhes de uma venda.
     */
    public function detalhes(): void
    {
        $this->check();

        $idPedido = (int) ($_GET['id'] ?? 0);

        if ($idPedido <= 0) {
            $_SESSION['erro'] = 'Pedido inválido.';
            $this->redirecionar();
        }

        $venda = (new Venda())->buscarPorId($idPedido);

        if (!$venda) {
            $_SESSION['erro'] = 'Pedido não encontrado.';
            $this->redirecionar();
        }

        require_once __DIR__ . '/../views/detalhes_venda.php';
    }

    /**
     * Emite a nota fiscal fictícia de um pedido.
     *
     * A emissão só pode acontecer depois
     * da confirmação do pagamento simulado.
     */
    public function emitirNota(): void
    {
        $this->check();
        csrfExigir();

        $idPedido = (int) (
            $_POST['id_pedido']
            ?? $_POST['venda_id']
            ?? 0
        );

        if ($idPedido <= 0) {
            $_SESSION['erro'] = 'Pedido inválido.';
            $this->redirecionar();
        }

        try {
            $venda = (new Venda())->buscarPorId($idPedido);

            if (!$venda) {
                throw new RuntimeException(
                    'Pedido não encontrado.'
                );
            }

            if ($venda['status'] !== 'pago') {
                throw new RuntimeException(
                    'A nota fiscal só pode ser emitida após o pagamento.'
                );
            }

            if (
                !$venda['pagamento']
                || $venda['pagamento']['status'] !== 'aprovado'
            ) {
                throw new RuntimeException(
                    'O pagamento ainda não foi aprovado.'
                );
            }

            require_once __DIR__
                . '/../models/NotaFiscal.php';

            $notaFiscal = new NotaFiscal();

            $notaFiscal->emitirParaPedido($idPedido);

            $_SESSION['sucesso'] =
                "Nota fiscal fictícia emitida para o pedido #{$idPedido}!";

        } catch (RuntimeException | InvalidArgumentException $e) {
            $_SESSION['erro'] = $e->getMessage();

        } catch (Throwable $e) {
            error_log('[nota fiscal] ' . $e->getMessage());

            $_SESSION['erro'] =
                'Não foi possível emitir a nota fiscal.';
        }

        $this->redirecionar();
    }

    /**
     * Exibe a nota fiscal fictícia.
     */
    public function verNota(): void
    {
        $this->check();

        $idPedido = (int) (
            $_GET['id_pedido']
            ?? $_GET['venda_id']
            ?? 0
        );

        if ($idPedido <= 0) {
            $_SESSION['erro'] = 'Pedido inválido.';
            $this->redirecionar();
        }

        require_once __DIR__
            . '/../models/NotaFiscal.php';

        $nota = (new NotaFiscal())
            ->buscarPorPedido($idPedido);

        if (!$nota) {
            $_SESSION['erro'] =
                'Este pedido ainda não possui nota fiscal emitida.';

            $this->redirecionar();
        }

        $venda = (new Venda())->buscarPorId($idPedido);

        if (!$venda) {
            $_SESSION['erro'] = 'Pedido não encontrado.';
            $this->redirecionar();
        }

        require_once __DIR__
            . '/../views/nota_fiscal_venda.php';
    }

    /**
     * Verifica se o administrador está autenticado.
     */
    private function check(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (
            !isset($_SESSION['usuario_id'])
            || ($_SESSION['perfil'] ?? null) !== 'admin'
        ) {
            header(
                'Location: index.php?controller=auth&action=form'
            );
            exit;
        }
    }

    /**
     * Redireciona para a listagem de vendas.
     */
    private function redirecionar(): void
    {
        header(
            'Location: index.php?controller=venda&action=index'
        );
        exit;
    }
}
