
<?php
/**
 * NEXGAMES — LOJA CONTROLLER
 *
 * Página inicial, catálogo, categorias,
 * pesquisa, ofertas, detalhes e avaliações.
 */

require_once __DIR__ . '/SiteBaseController.php';
require_once __DIR__ . '/../models/Avaliacao.php';

class LojaController extends SiteBaseController
{
    private const POR_PAGINA = 12;
    private const QTD_DESTAQUES = 4;
    private const QTD_OFERTAS = 3;

    public function index(): void
    {
        $vitrine = new Vitrine();

        $filtros = [
            'categoria_id' => max(
                0,
                (int) ($_GET['categoria_id'] ?? 0)
            ),
            'busca' => trim(
                (string) ($_GET['q'] ?? '')
            ),
            'oferta' => !empty($_GET['oferta']),
        ];

        $modoLista =
            $filtros['categoria_id'] > 0
            || $filtros['busca'] !== ''
            || $filtros['oferta']
            || isset($_GET['catalogo'])
            || isset($_GET['pagina']);

        $total = $vitrine->contar($filtros);

        $paginas = max(
            1,
            (int) ceil($total / self::POR_PAGINA)
        );

        $pagina = min(
            $paginas,
            max(1, (int) ($_GET['pagina'] ?? 1))
        );

        $produtos = [];
        $destaques = [];
        $ofertas = [];

        if ($modoLista) {
            $produtos = $this->comImagem(
                $vitrine->listar(
                    $filtros,
                    self::POR_PAGINA,
                    ($pagina - 1) * self::POR_PAGINA
                )
            );
        } else {
            $todos = $vitrine->listar();

            usort(
                $todos,
                fn($a, $b) =>
                    (int) $b['id'] <=> (int) $a['id']
            );

            $destaques = $this->comImagem(
                array_slice(
                    $todos,
                    0,
                    self::QTD_DESTAQUES
                )
            );

            $ofertas = $this->comImagem(
                $vitrine->listar(
                    ['oferta' => true],
                    self::QTD_OFERTAS
                )
            );
        }

        // Identifica o nome da categoria selecionada.
        $categoriaNome = null;

        $categorias = $vitrine->categoriasAtivas();

        foreach ($categorias as $categoria) {
            if (
                (int) $categoria['id'] ===
                $filtros['categoria_id']
            ) {
                $categoriaNome = $categoria['nome'];
                break;
            }
        }

        // Envia os dados para a página.
        $this->render(
            'home',
            [
                'produtos' => $produtos,
                'destaques' => $destaques,
                'ofertas' => $ofertas,
                'modoLista' => $modoLista,
                'total' => $total,
                'pagina' => $pagina,
                'paginas' => $paginas,
                'filtros' => $filtros,
                'categoriaNome' => $categoriaNome,
            ],
            'NexGames'
        );
    }

    public function catalogo(): void
    {
        $_GET['catalogo'] = 1;
        $this->index();
    }

    public function ofertas(): void
    {
        $_GET['oferta'] = 1;
        $this->index();
    }

    public function produto(): void
    {
        $vitrine = new Vitrine();

        $id = (int) ($_GET['id'] ?? 0);

        $produto = $vitrine->buscarProduto($id);

        if (!$produto) {
            http_response_code(404);

            $this->render(
                'nao_encontrado',
                [
                    'mensagem' =>
                        'Esse jogo não existe ou não está mais à venda.'
                ],
                'Jogo não encontrado'
            );

            return;
        }

        $preco = (float) $produto['preco_final'];
        $precoCheio = (float) $produto['preco'];

        $emOferta =
            (int) $produto['em_oferta'] === 1
            && $produto['preco_promocional'] !== null;

        $imagem = imagemProduto(
            (int) $produto['id'],
            $produto['imagem']
        );

        $avaliacaoModel = new Avaliacao();

        $avaliacoes = $avaliacaoModel->listarPorProduto($id);

        $minhaAvaliacao = null;

        if (!empty($_SESSION['cliente_id'])) {
            $minhaAvaliacao =
                $avaliacaoModel->buscarDoCliente(
                    (string) $_SESSION['cliente_id'],
                    $id
                );
        }

        $this->render(
            'produto',
            [
                'produto' => $produto,
                'imagem' => $imagem,
                'preco' => $preco,
                'precoCheio' => $precoCheio,
                'emOferta' => $emOferta,
                'avaliacoes' => $avaliacoes,
                'minhaAvaliacao' => $minhaAvaliacao,
            ],
            $produto['nome']
        );
    }

    public function produtosJson(): void
    {
        $vitrine = new Vitrine();

        $produtos = $vitrine->listar([
            'categoria_id' => max(
                0,
                (int) ($_GET['categoria_id'] ?? 0)
            ),
            'busca' => trim(
                (string) ($_GET['q'] ?? '')
            ),
            'oferta' => !empty($_GET['oferta']),
        ]);

        $saida = [];

        foreach ($produtos as $p) {
            $saida[] = [
                'id' => (int) $p['id'],
                'nome' => $p['nome'],
                'descricao' => $p['descricao'],
                'categorias' => $p['categorias_nome'],

                'imagem' => imagemProduto(
                    (int) $p['id'],
                    $p['imagem']
                ),

                'preco' => (float) $p['preco'],

                'preco_promocional' =>
                    $p['preco_promocional'] !== null
                        ? (float) $p['preco_promocional']
                        : null,

                'em_oferta' =>
                    (int) $p['em_oferta'] === 1,

                'preco_final' =>
                    (float) $p['preco_final'],
            ];
        }

        header(
            'Content-Type: application/json; charset=utf-8'
        );

        echo json_encode(
            $saida,
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        );
    }

    private function comImagem(array $jogos): array
    {
        foreach ($jogos as &$j) {
            $j['imagem'] = imagemProduto(
                (int) $j['id'],
                $j['imagem']
            );
        }

        unset($j);

        return $jogos;
    }
}
