
<?php

require_once __DIR__ . '/../models/Vitrine.php';
require_once __DIR__ . '/../models/Carrinho.php';

/**
 * NEXGAMES — SITE BASE CONTROLLER
 *
 * Base dos controllers da área pública.
 */
abstract class SiteBaseController
{
    /**
     * Renderiza as páginas da área pública,
     * mantendo cabeçalho, conteúdo e rodapé
     * em escopos independentes.
     */
    protected function render(
        string $view,
        array $dados = [],
        string $titulo = 'NexGames'
    ): void {

        $carrinho = new Carrinho();

        $layout = [
            'titulo' => $titulo,

            'categorias' =>
                (new Vitrine())->categoriasAtivas(),

            'qtdCarrinho' => $carrinho->contar(),

            'clienteNome' =>
                $_SESSION['cliente_nome'] ?? null,

            'flashes' => pegarFlashes(),

            'buscaAtual' => trim(
                (string) ($_GET['q'] ?? '')
            ),

            'categoriaAtual' => (int) (
                $_GET['categoria_id'] ?? 0
            ),
        ];

        $arquivoView = __DIR__
            . '/../views/site/'
            . $view
            . '.php';

        if (!is_file($arquivoView)) {
            throw new RuntimeException(
                'A página "' . $view .
                '" não foi encontrada em views/site/.'
            );
        }

        /**
         * Executa cada arquivo PHP em um escopo
         * separado para evitar conflitos entre
         * variáveis das views.
         */
        $incluir = static function (
            string $arquivo,
            array $variaveis
        ): void {

            extract(
                $variaveis,
                EXTR_SKIP
            );

            require $arquivo;
        };

        $variaveis = array_merge(
            $layout,
            $dados,
            ['view' => $view]
        );

        // Cabeçalho
        $incluir(
            __DIR__ . '/../views/site/_header.php',
            $variaveis
        );

        // Conteúdo da página
        $incluir(
            $arquivoView,
            $variaveis
        );

        // Rodapé
        $incluir(
            __DIR__ . '/../views/site/_footer.php',
            $variaveis
        );
    }

    /**
     * Verifica se o cliente está logado.
     */
    protected function clienteLogado(): bool
    {
        return !empty($_SESSION['cliente_id']);
    }

    /**
     * Retorna o CPF do cliente logado.
     */
    protected function clienteCpf(): string
    {
        return (string) (
            $_SESSION['cliente_id'] ?? ''
        );
    }

    /**
     * Exige autenticação do cliente.
     */
    protected function exigirLogin(): void
    {
        if ($this->clienteLogado()) {
            return;
        }

        $_SESSION['redirect_apos_login'] =
            ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'
                ? 'index.php?' .
                    ($_SERVER['QUERY_STRING'] ?? '')
                : url('carrinho', 'index');

        flash(
            'aviso',
            'Entre na sua conta para continuar a compra.'
        );

        redirecionar(
            url('auth', 'form')
        );

        exit;
    }

    /**
     * Inicia a sessão do cliente.
     */
    protected function iniciarSessaoCliente(
        array $cliente
    ): void {

        session_regenerate_id(true);

        $_SESSION['cliente_id'] = $cliente['cpf'];
        $_SESSION['cliente_nome'] = $cliente['nome'];
    }

    /**
     * Aceita somente requisições POST
     * com token CSRF válido.
     */
    protected function exigirPost(
        string $voltarPara
    ): void {

        if (
            ($_SERVER['REQUEST_METHOD'] ?? 'GET')
            !== 'POST'
        ) {
            redirecionar($voltarPara);
            exit;
        }

        if (!csrfValido()) {
            flash(
                'erro',
                'Sua sessão expirou. Tente de novo.'
            );

            redirecionar($voltarPara);
            exit;
        }
    }
}
