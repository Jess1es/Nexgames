
<?php

require_once __DIR__ . '/SiteBaseController.php';
require_once __DIR__ . '/../models/ClienteSite.php';
require_once __DIR__ . '/AuthController.php';

class ClienteController extends SiteBaseController
{
    private const SENHA_MIN = 8;
    private const SENHA_MAX = 72;

    /* CADASTRO */

    public function cadastro(): void
    {
        if ($this->clienteLogado()) {
            redirecionar(url('cliente', 'meusDados'));
            return;
        }

        $old = [
            'nome' => '',
            'email' => '',
            'cpf' => '',
            'telefone' => ''
        ];

        $erros = [];

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            if (!csrfValido()) {
                $erros['geral'] =
                    'Sua sessão expirou. Envie o formulário de novo.';
            } else {
                $old = $this->lerDadosCadastro();

                $senha = (string) ($_POST['senha'] ?? '');
                $confirma = (string) (
                    $_POST['senha_confirmacao'] ?? ''
                );

                $model = new ClienteSite();

                $erros = $this->validarDados(
                    $old,
                    null,
                    $model
                );

                $erros += $this->validarNovaSenha(
                    $senha,
                    $confirma,
                    'senha',
                    'senha_confirmacao'
                );

                if (
                    !isset($erros['cpf']) &&
                    $model->buscarPorCpf($old['cpf'])
                ) {
                    $erros['cpf'] =
                        'Já existe um cadastro com esse CPF.';
                }

                if (!$erros) {
                    try {
                        $model->criar(
                            $old + ['senha' => $senha]
                        );

                        $this->iniciarSessaoCliente([
                            'cpf' => $old['cpf'],
                            'nome' => $old['nome']
                        ]);

                        flash(
                            'ok',
                            'Cadastro concluído. Bem-vindo(a), ' .
                            $old['nome'] . '!'
                        );

                        $this->voltarParaOndeParou();
                        return;

                    } catch (RegraNegocioException $ex) {
                        $erros['geral'] = $ex->getMessage();
                    }
                }
            }
        }

        $this->render(
            'cadastro',
            [
                'old' => $old,
                'erros' => $erros
            ],
            'Criar conta'
        );
    }

    /* LOGIN */

    public function login(): void
    {
        if ($this->clienteLogado()) {
            $this->voltarParaOndeParou();
            return;
        }

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            (new AuthController())->login();
            return;
        }

        redirecionar(url('auth', 'form'));
    }

    /* LOGOUT */

    public function logout(): void
    {
        $this->exigirPost(
            url('loja', 'index')
        );

        unset(
            $_SESSION['cliente_id'],
            $_SESSION['cliente_nome'],
            $_SESSION['redirect_apos_login']
        );

        session_regenerate_id(true);

        flash('ok', 'Você saiu da sua conta.');

        redirecionar(url('loja', 'index'));
    }

    /* MEUS DADOS */

    public function meusDados(): void
    {
        $this->exigirLogin();

        $model = new ClienteSite();

        $cliente = $model->buscarPorCpf(
            $this->clienteCpf()
        );

        if (!$cliente) {
            unset(
                $_SESSION['cliente_id'],
                $_SESSION['cliente_nome']
            );

            redirecionar(url('cliente', 'login'));
            return;
        }

        $old = [
            'nome' => $cliente['nome'],
            'email' => $cliente['email'],
            'cpf' => $cliente['cpf'],
            'telefone' => (string) $cliente['telefone']
        ];

        $erros = [];

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            if (!csrfValido()) {
                $erros['geral'] =
                    'Sua sessão expirou. Envie o formulário de novo.';
            } else {
                $old = $this->lerDadosCadastro();

                $old['cpf'] = $cliente['cpf'];

                $erros = $this->validarDados(
                    $old,
                    $cliente['cpf'],
                    $model
                );

                if (!$erros) {
                    try {
                        $model->atualizar(
                            $cliente['cpf'],
                            $old
                        );

                        $_SESSION['cliente_nome'] =
                            $old['nome'];

                        flash(
                            'ok',
                            'Dados atualizados.'
                        );

                        redirecionar(
                            url('cliente', 'meusDados')
                        );
                        return;

                    } catch (RegraNegocioException $ex) {
                        $erros['geral'] = $ex->getMessage();
                    }
                }
            }
        }

        $this->render(
            'meus_dados',
            [
                'old' => $old,
                'erros' => $erros,
                'errosSenha' => []
            ],
            'Meus dados'
        );
    }

    /* ALTERAR SENHA */

    public function alterarSenha(): void
    {
        $this->exigirLogin();

        $this->exigirPost(
            url('cliente', 'meusDados')
        );

        $model = new ClienteSite();

        $cliente = $model->buscarPorCpf(
            $this->clienteCpf()
        );

        if (!$cliente) {
            unset(
                $_SESSION['cliente_id'],
                $_SESSION['cliente_nome']
            );

            redirecionar(url('cliente', 'login'));
            return;
        }

        $erros = [];

        if (!password_verify(
            (string) ($_POST['senha_atual'] ?? ''),
            $cliente['senha_hash']
        )) {
            $erros['senha_atual'] =
                'A senha atual não confere.';
        }

        $erros += $this->validarNovaSenha(
            (string) ($_POST['senha'] ?? ''),
            (string) ($_POST['senha_confirmacao'] ?? ''),
            'senha',
            'senha_confirmacao'
        );

        if (!$erros) {
            $model->atualizarSenha(
                $cliente['cpf'],
                (string) $_POST['senha']
            );

            session_regenerate_id(true);

            flash('ok', 'Senha alterada.');

            redirecionar(url('cliente', 'meusDados'));
            return;
        }

        $old = [
            'nome' => $cliente['nome'],
            'email' => $cliente['email'],
            'cpf' => $cliente['cpf'],
            'telefone' => (string) $cliente['telefone']
        ];

        $this->render(
            'meus_dados',
            [
                'old' => $old,
                'erros' => [],
                'errosSenha' => $erros
            ],
            'Meus dados'
        );
    }

    /* VALIDAÇÕES */

    private function lerDadosCadastro(): array
    {
        return [
            'nome' => trim(
                (string) ($_POST['nome'] ?? '')
            ),
            'email' => mb_strtolower(
                trim((string) ($_POST['email'] ?? ''))
            ),
            'cpf' => somenteDigitos(
                (string) ($_POST['cpf'] ?? '')
            ),
            'telefone' => somenteDigitos(
                (string) ($_POST['telefone'] ?? '')
            )
        ];
    }

    private function validarDados(
        array $d,
        ?string $cpfAtual,
        ClienteSite $model
    ): array {
        $erros = [];

        if (
            mb_strlen($d['nome']) < 3 ||
            mb_strlen($d['nome']) > 100
        ) {
            $erros['nome'] =
                'Informe seu nome completo (3 a 100 caracteres).';
        }

        if (
            $cpfAtual === null &&
            strlen($d['cpf']) !== 11
        ) {
            $erros['cpf'] =
                'Informe o CPF com 11 dígitos.';
        }

        if (
            !filter_var(
                $d['email'],
                FILTER_VALIDATE_EMAIL
            ) ||
            mb_strlen($d['email']) > 100
        ) {
            $erros['email'] =
                'Informe um e-mail válido.';

        } elseif (
            $model->emailEmUso(
                $d['email'],
                $cpfAtual
            )
        ) {
            $erros['email'] =
                'Esse e-mail já está cadastrado.';
        }

        if (
            $d['telefone'] !== '' &&
            !in_array(
                strlen($d['telefone']),
                [10, 11],
                true
            )
        ) {
            $erros['telefone'] =
                'Telefone deve ter DDD + 8 ou 9 dígitos.';
        }

        return $erros;
    }

    private function validarNovaSenha(
        string $senha,
        string $confirma,
        string $campo,
        string $campoConfirma
    ): array {
        $erros = [];

        if (strlen($senha) < self::SENHA_MIN) {
            $erros[$campo] =
                'A senha precisa ter pelo menos ' .
                self::SENHA_MIN .
                ' caracteres.';

        } elseif (strlen($senha) > self::SENHA_MAX) {
            $erros[$campo] =
                'A senha pode ter no máximo ' .
                self::SENHA_MAX .
                ' caracteres.';

        } elseif ($senha !== $confirma) {
            $erros[$campoConfirma] =
                'A confirmação não é igual à senha.';
        }

        return $erros;
    }

    /* REDIRECIONAMENTO */

    private function voltarParaOndeParou(): void
    {
        $destino = destinoInternoSeguro(
            $_SESSION['redirect_apos_login'] ?? null,
            url('loja', 'index')
        );

        unset(
            $_SESSION['redirect_apos_login']
        );

        redirecionar($destino);
    }

    /* EXCLUIR CONTA */

    public function excluirConta(): void
    {
        $this->exigirLogin();

        $this->exigirPost(
            url('cliente', 'meusDados')
        );

        $model = new ClienteSite();

        $cliente = $model->buscarPorCpf(
            $this->clienteCpf()
        );

        if (!$cliente) {
            redirecionar(url('cliente', 'login'));
            return;
        }

        if (!password_verify(
            (string) ($_POST['senha'] ?? ''),
            $cliente['senha_hash']
        )) {
            flash(
                'erro',
                'Senha incorreta. A conta não foi excluída.'
            );

            redirecionar(url('cliente', 'meusDados'));
            return;
        }

        require_once __DIR__ . '/../models/Pedido.php';

        $temPedidos = (bool) (
            new Pedido()
        )->listarDoCliente(
            $cliente['cpf']
        );

        if ($temPedidos) {
            $model->anonimizar(
                $cliente['cpf']
            );

            $mensagem =
                'Sua conta foi encerrada. Como você possui pedidos, ' .
                'o histórico de compras foi mantido de forma anônima.';
        } else {
            $model->excluir(
                $cliente['cpf']
            );

            $mensagem =
                'Sua conta foi excluída com sucesso.';
        }

        unset(
            $_SESSION['cliente_id'],
            $_SESSION['cliente_nome']
        );

        session_regenerate_id(true);

        flash('ok', $mensagem);

        redirecionar(url('loja', 'index'));
    }

    /* LISTAR CLIENTES (ADMIN) */

    public function listar(): void
    {
        if (
            !isset($_SESSION['usuario_id']) ||
            ($_SESSION['perfil'] ?? '') !== 'admin'
        ) {
            header(
                'Location: index.php?controller=auth&action=form'
            );
            exit;
        }

        require_once __DIR__ . '/../config/db.php';

        $conn = Database::getConnection();

        $sql = "
            SELECT cpf, nome, email, telefone, criado_em
            FROM cliente_site
            ORDER BY criado_em DESC
        ";

        $stmt = $conn->query($sql);

        $clientes = $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

        require_once __DIR__ . '/../views/clientes.php';
    }

    /* MÉTODOS DE PAGAMENTO */

    public function metodosPagamento(): void
    {
        $this->exigirLogin();

        require_once __DIR__ .
            '/../models/MetodoPagamento.php';

        $model = new MetodoPagamento();

        $metodos = $model->listar(
            $this->clienteCpf()
        );

        $this->render(
            'metodos_pagamento',
            ['metodos' => $metodos],
            'Métodos de pagamento'
        );
    }

    /* ADICIONAR / EDITAR MÉTODO */

    public function formularioPagamento(): void
    {
        $this->exigirLogin();

        require_once __DIR__ .
            '/../models/MetodoPagamento.php';

        $model = new MetodoPagamento();

        $cpf = $this->clienteCpf();

        $id = (int) ($_GET['id'] ?? 0);

        $metodo = [
            'id_metodo' => 0,
            'tipo' => 'credito',
            'identificacao' => '',
            'ultimos_digitos' => ''
        ];

        // Busca um método de pagamento cadastrado.
        if ($id > 0) {
            $encontrado = $model->buscar(
                $id,
                $cpf
            );

            if (!$encontrado) {
                http_response_code(404);

                $this->render(
                    'nao_encontrado',
                    [
                        'mensagem' =>
                            'Método de pagamento não encontrado.'
                    ],
                    'Não encontrado'
                );

                return;
            }

            $metodo = $encontrado;
        }

        if (!isset($erros)) {
            $erros = [];
        }

        if (
            ($_SERVER['REQUEST_METHOD'] ?? 'GET')
            === 'POST'
        ) {
            $this->exigirPost(
                url('cliente', 'metodosPagamento')
            );

            $tipo = trim(
                (string) ($_POST['tipo'] ?? '')
            );

            $identificacao = trim(
                (string) ($_POST['identificacao'] ?? '')
            );

            $numeroCartao = trim(
                (string) ($_POST['numero_cartao'] ?? '')
            );

            $digitos = null;

            if (!in_array(
                $tipo,
                ['credito', 'pix'],
                true
            )) {
                $erros['tipo'] =
                    'Selecione cartão de crédito ou Pix.';
            }

            if ($tipo === 'pix') {
                $identificacao = 'Pix';
                $digitos = null;
            }

            if ($tipo === 'credito') {

                if (
                    $identificacao === '' ||
                    mb_strlen($identificacao) > 100
                ) {
                    $erros['identificacao'] =
                        'Informe um nome de até 100 caracteres.';
                }

                if ($id > 0) {

                    // Mantém os últimos dígitos na edição.
                    if (
                        ($encontrado['tipo'] ?? '')
                        === 'credito'
                    ) {
                        $digitos =
                            $encontrado['ultimos_digitos'];
                    } else {
                        $erros['numero_cartao'] =
                            'Para cadastrar um cartão, ' .
                            'utilize a opção de adicionar ' .
                            'novo método.';
                    }

                } else {

                    $numeroLimpo = str_replace(
                        ' ',
                        '',
                        $numeroCartao
                    );

                    if (!preg_match(
                        '/^[0-9]{16}$/',
                        $numeroLimpo
                    )) {
                        $erros['numero_cartao'] =
                            'Informe 16 dígitos demonstrativos.';
                    } else {
                        // Armazena somente os últimos 4 dígitos.
                        $digitos = substr(
                            $numeroLimpo,
                            -4
                        );
                    }
                }
            }

            // Preserva os dados caso haja erro.
            $metodo = [
                'id_metodo' => $id,
                'tipo' => $tipo,
                'identificacao' => $identificacao,
                'ultimos_digitos' => $digitos
            ];

            if (!$erros) {
                $model->salvar(
                    $cpf,
                    $tipo,
                    $identificacao,
                    $digitos,
                    $id
                );

                flash(
                    'ok',
                    $id > 0
                        ? 'Método atualizado com sucesso.'
                        : 'Método adicionado com sucesso.'
                );

                redirecionar(
                    url('cliente', 'metodosPagamento')
                );

                return;
            }
        }

        $this->render(
            'formulario_pagamento',
            [
                'metodo' => $metodo,
                'erros' => $erros
            ],
            $id > 0
                ? 'Editar método de pagamento'
                : 'Adicionar método de pagamento'
        );
    }

    /* EXCLUIR MÉTODO */

    public function excluirMetodoPagamento(): void
    {
        $this->exigirLogin();

        $volta = url(
            'cliente',
            'metodosPagamento'
        );

        $this->exigirPost($volta);

        require_once __DIR__ .
            '/../models/MetodoPagamento.php';

        $id = (int) (
            $_POST['id_metodo'] ?? 0
        );

        if ($id <= 0) {
            flash(
                'erro',
                'Método inválido.'
            );

            redirecionar($volta);
            return;
        }

        $model = new MetodoPagamento();

        $metodo = $model->buscar(
            $id,
            $this->clienteCpf()
        );

        if (!$metodo) {
            flash(
                'erro',
                'Método não encontrado.'
            );

            redirecionar($volta);
            return;
        }

        $model->excluir(
            $id,
            $this->clienteCpf()
        );

        flash(
            'ok',
            'Método excluído com sucesso.'
        );

        redirecionar($volta);
    }

    /* SUPORTE — NEXGAMES */

    public function suporte(): void
    {
        $this->exigirLogin();

        $this->render(
            'suporte',
            [],
            'Suporte'
        );
    }
}
