
<?php
require_once __DIR__ . '/../models/Relatorio.php';

class RelatorioController
{
    private function check(): void
    {
        if (
            !isset($_SESSION['usuario_id']) ||
            ($_SESSION['perfil'] ?? '') !== 'admin'
        ) {
            header("Location: index.php?controller=auth&action=form");
            exit;
        }
    }

    public function index(): void
    {
        $this->check();

        $relatorioModel = new Relatorio();
        $conn = Database::getConnection();

        // Jogos mais vendidos
        $topProdutos = $relatorioModel->topProdutosMaisVendidos(10);

        // Resumo geral da NexGames
        $resumo = [
            'total_vendas' => (int) $conn->query("
                SELECT COUNT(*)
                FROM pedido
                WHERE status = 'pago'
            ")->fetchColumn(),

            'pedidos_realizados' => (int) $conn->query("
                SELECT COUNT(*)
                FROM pedido
            ")->fetchColumn(),

            'clientes_ativos' => (int) $conn->query("
                SELECT COUNT(*)
                FROM cliente_site
            ")->fetchColumn(),

            'produtos_cadastrados' => (int) $conn->query("
                SELECT COUNT(*)
                FROM produto
            ")->fetchColumn()
        ];

        // Informações dos últimos 30 dias
        $periodo = [
            'dias' => 30,

            'total_pedidos' => (int) $conn->query("
                SELECT COUNT(*)
                FROM pedido
                WHERE data >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ")->fetchColumn(),

            'faturamento' => (float) $conn->query("
                SELECT COALESCE(SUM(valor_total), 0)
                FROM pedido
                WHERE status = 'pago'
                  AND data >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ")->fetchColumn()
        ];

        require_once __DIR__ . '/../views/relatorios.php';
    }

    /* EXPORTAR EXCEL */

    public function exportarExcel(): void
    {
        $this->check();

        $relatorioModel = new Relatorio();
        $topProdutos = $relatorioModel->topProdutosMaisVendidos(50);

        header('Content-Type: text/csv; charset=UTF-8');
        header(
            'Content-Disposition: attachment; filename="jogos_mais_vendidos.csv"'
        );

        // Evita problemas com acentos no Excel
        echo "\xEF\xBB\xBF";

        $saida = fopen('php://output', 'w');

        fputcsv(
            $saida,
            ['Jogo', 'Licenças vendidas', 'Receita (R$)'],
            ';'
        );

        foreach ($topProdutos as $linha) {
            fputcsv(
                $saida,
                [
                    $linha['nome'],
                    $linha['total_vendido'],
                    number_format(
                        (float) $linha['receita'],
                        2,
                        ',',
                        ''
                    )
                ],
                ';'
            );
        }

        fclose($saida);
        exit;
    }

    /* EXPORTAR PDF */

    public function exportarPdf(): void
    {
        $this->check();

        $autoload = __DIR__ . '/../vendor/autoload.php';

        if (!file_exists($autoload)) {
            die(
                'Biblioteca Dompdf não encontrada. ' .
                'Instale o Dompdf pelo Composer para exportar PDF.'
            );
        }

        require_once $autoload;

        $relatorioModel = new Relatorio();
        $topProdutos = $relatorioModel->topProdutosMaisVendidos(10);

        $conn = Database::getConnection();

        // Resumo geral da NexGames
        $resumo = [
            'total_vendas' => (int) $conn->query("
                SELECT COUNT(*)
                FROM pedido
                WHERE status = 'pago'
            ")->fetchColumn(),

            'pedidos_realizados' => (int) $conn->query("
                SELECT COUNT(*)
                FROM pedido
            ")->fetchColumn(),

            'clientes_ativos' => (int) $conn->query("
                SELECT COUNT(*)
                FROM cliente_site
            ")->fetchColumn(),

            'produtos_cadastrados' => (int) $conn->query("
                SELECT COUNT(*)
                FROM produto
            ")->fetchColumn()
        ];

        // Informações dos últimos 30 dias
        $periodo = [
            'dias' => 30,

            'total_pedidos' => (int) $conn->query("
                SELECT COUNT(*)
                FROM pedido
                WHERE data >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ")->fetchColumn(),

            'faturamento' => (float) $conn->query("
                SELECT COALESCE(SUM(valor_total), 0)
                FROM pedido
                WHERE status = 'pago'
                  AND data >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ")->fetchColumn()
        ];

        ob_start();

        require __DIR__ . '/../views/relatorio_pdf.php';

        $html = ob_get_clean();

        $dompdf = new \Dompdf\Dompdf();

        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $dompdf->stream(
            'relatorio_nexgames.pdf',
            ['Attachment' => true]
        );

        exit;
    }
}
