
<?php
require_once __DIR__ . '/../models/categoria.php';

class CategoriaController
{
    public function index(): void
    {
        $this->check();
        $this->onlyAdmin();

        $categoriaModel = new Categoria();
        $categorias = $categoriaModel->listarTodas();

        $editar = null;
        if (isset($_GET['id'])) {
            $editar = $categoriaModel->buscarPorId((int) $_GET['id']);
        }

        require_once __DIR__ . '/../views/categorias.php';
    }

    /** POST: id, nome, descricao */
    public function salvar(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id = (int) ($_POST['id'] ?? 0);
        $nome = trim($_POST['nome'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');

        if ($nome === '' || mb_strlen($nome) > 150) {
            die("Nome inválido (até 150 caracteres).");
        }

        if ($descricao === '') {
            die("Informe a descrição da categoria.");
        }

        $categoriaModel = new Categoria();

        if ($id > 0) {
            $categoriaModel->atualizar($id, $nome, $descricao);
        } else {
            $categoriaModel->inserir($nome, $descricao);
        }

        header("Location: index.php?controller=categoria&action=index");
        exit;
    }

    public function deletar(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id = (int) ($_POST['id_categoria'] ?? $_POST['id'] ?? 0);

        if ($id <= 0) {
            die("ID inválido.");
        }

        try {
            (new Categoria())->deletar($id);
        } catch (\PDOException $e) {
            die("Não é possível excluir esta categoria porque existem jogos vinculados a ela. Desative-a ou desvincule os jogos.");
        }

        header("Location: index.php?controller=categoria&action=index");
        exit;
    }

    public function toggle(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id = (int) ($_POST['id_categoria'] ?? $_POST['id'] ?? 0);
        $ativo = (int) ($_POST['ativo'] ?? 1);

        if ($id <= 0) {
            die("ID inválido.");
        }

        (new Categoria())->setAtivo($id, $ativo === 1);

        header("Location: index.php?controller=categoria&action=index");
        exit;
    }

    private function check(): void
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?controller=auth&action=form");
            exit;
        }
    }

    private function onlyAdmin(): void
    {
        if (($_SESSION['perfil'] ?? '') !== 'admin') {
            die("Acesso negado.");
        }
    }
}
