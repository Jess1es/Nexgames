<?php
require_once __DIR__ . '/../models/produto.php';
require_once __DIR__ . '/../models/categoria.php';

class ProdutoController
{
    public function index(): void
    {
        $this->check();
        $produtoModel = new Produto();
        $categoriaModel = new Categoria();

        $produtos = $produtoModel->listarComCategoria(false);
        $categorias = $categoriaModel->listarAtivas();

        $editar = null; // ao editar, $editar['categorias'] = ids das categorias do jogo
        if (isset($_GET['id'])) {
            $editar = $produtoModel->buscarPorId((int) $_GET['id']);
        }

        require_once __DIR__ . '/../views/produtos.php';
    }

    /**
     * POST: id, nome, descricao, preco, preco_promocional, em_oferta (checkbox),
     *       arquivo_download, categorias[] (várias), imagem (arquivo, opcional)
     */
    public function salvar(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id = (int) ($_POST['id_produto'] ?? $_POST['id'] ?? 0);
        $nome      = trim($_POST['nome'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');
        $preco = $this->converterPreco($_POST['preco'] ?? '0');
        $promoRaw = trim((string) ($_POST['preco_promocional'] ?? ''));
        $promo = $promoRaw === ''
        ? null
        : $this->converterPreco($promoRaw);
        $emOferta  = !empty($_POST['em_oferta']);
        // coluna NOT NULL no banco; os jogos do dump usam 'pendente' até o arquivo existir
        $arquivo   = trim((string) ($_POST['arquivo_download'] ?? '')) ?: 'pendente';
        $categorias = array_filter(array_map('intval', (array) ($_POST['categorias'] ?? [])), fn($c) => $c > 0);

        if ($nome === '' || mb_strlen($nome) > 150) {
            die("Informe o nome do jogo (até 150 caracteres).");
        }
        if ($preco <= 0) {
            die("Informe um preço válido.");
        }
        if ($promo !== null && ($promo <= 0 || $promo >= $preco)) {
            die("O preço promocional precisa ser maior que zero e menor que o preço normal.");
        }
        if ($emOferta && $promo === null) {
            die("Para marcar o jogo como 'em oferta', informe o preço promocional.");
        }
        if (!$categorias) {
            die("Selecione ao menos uma categoria.");
        }

        $dados = [
            'nome'              => $nome,
            'descricao'         => $descricao === '' ? null : $descricao,
            'preco'             => $preco,
            'arquivo_download'  => $arquivo,
            'preco_promocional' => $promo,
            'em_oferta'         => $emOferta,
        ];

        $produtoModel = new Produto();
        try {
            if ($id > 0) {
                $produtoModel->atualizar($id, $dados, $categorias);
                $produtoId = $id;
            } else {
                $produtoId = $produtoModel->inserir($dados, $categorias);
            }
        } catch (PDOException $e) {
            error_log('[produto] ' . $e->getMessage());
            die("Não foi possível salvar o jogo. Confira os dados (categorias inválidas?).");
        }

        $this->salvarImagemDoProduto($produtoId, $produtoModel); // upload opcional

        header("Location: index.php?controller=produto&action=index");
        exit;
    }

    public function toggle(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();
        
        $id = (int) ($_POST['id_produto'] ?? $_POST['id'] ?? 0);
        $ativo = (int) ($_POST['ativo'] ?? 1);
        if ($id <= 0) die("ID inválido.");

        (new Produto())->setAtivo($id, $ativo === 1);

        header("Location: index.php?controller=produto&action=index");
        exit;
    }

    /** Exclui o jogo (e seus vínculos de categoria) e, só depois, a imagem. */
    public function deletar(): void
    {
        $this->check();
        csrfExigir();
        $this->onlyAdmin();

        $id = (int) ($_POST['id_produto'] ?? $_POST['id'] ?? 0);
        if ($id <= 0) die("ID inválido.");

        try {
            (new Produto())->deletar($id);
        } catch (PDOException $e) {
            error_log('[produto] ' . $e->getMessage());
            die("Não foi possível excluir: este jogo já foi vendido (aparece em pedidos). Desative-o em vez de excluir.");
        }

        $destDir = __DIR__ . '/../public/uploads/produtos/';
        foreach (['jpg', 'png', 'webp'] as $ext) {
            $arquivo = $destDir . $id . '.' . $ext;
            if (file_exists($arquivo)) {
                unlink($arquivo);
            }
        }

        header("Location: index.php?controller=produto&action=index");
        exit;
    }

    /** JSON para o PDV: [{id, nome, preco}] com o preço final (promoção, se houver). */
    public function listarJson(): void
    {
        if (ob_get_length()) ob_clean();
        header('Content-Type: application/json; charset=utf-8');

        try {
            echo json_encode((new Produto())->listarParaPdv(), JSON_UNESCAPED_UNICODE);
        } catch (Throwable $e) {
            http_response_code(500);
            error_log('[produto] ' . $e->getMessage());
            echo json_encode(['erro' => 'Erro ao listar produtos.']);
        }
        exit;
    }

    // -------------------------
    // Upload: public/uploads/produtos/{id}.{ext} + caminho em produto.imagem
    // -------------------------
    private function salvarImagemDoProduto(int $produtoId, Produto $produtoModel): void
    {
        if (!isset($_FILES['imagem']) || $_FILES['imagem']['error'] !== UPLOAD_ERR_OK) {
            return; // sem imagem
        }
        if (($_FILES['imagem']['size'] ?? 0) > 2 * 1024 * 1024) {
            return; // limite de 2MB
        }

        $tmp = $_FILES['imagem']['tmp_name'];
        $mime = mime_content_type($tmp);

        $ext = match ($mime) {
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp',
            default      => null,
        };
        if ($ext === null) return;

        $destDir = __DIR__ . '/../public/uploads/produtos/';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }

        // remove versões antigas (se trocar)
        foreach (['jpg', 'png', 'webp'] as $e) {
            $old = $destDir . $produtoId . '.' . $e;
            if (file_exists($old)) unlink($old);
        }

        if (move_uploaded_file($tmp, $destDir . $produtoId . '.' . $ext)) {
            $produtoModel->setImagem($produtoId, "public/uploads/produtos/{$produtoId}.{$ext}");
        }
    }

    // -------------------------
    // Segurança básica de sessão
    // -------------------------
    private function check(): void
    {
        if (!isset($_SESSION['usuario_id'])) {
            header("Location: index.php?controller=auth&action=form");
            exit;
        }
    }

private function onlyAdmin(): void
{
    if (($_SESSION['perfil'] ?? '') !== 'admin') {
        die("Acesso negado.");
    }
}

// Conversão de preços
private function converterPreco($valor): float
{
    $valor = trim((string) $valor);

    if (strpos($valor, ',') !== false) {
        $valor = str_replace('.', '', $valor);
        $valor = str_replace(',', '.', $valor);
    }

    return (float) $valor;
}

}