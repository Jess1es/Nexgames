
<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de produtos.
 *
 * Gerencia o cadastro, a consulta, a atualização
 * e as categorias dos jogos digitais.
 */
class Produto
{
    /**
     * Calcula o preço final do jogo,
     * considerando promoções ativas.
     */
    public const PRECO_FINAL_SQL =
        "CASE WHEN p.em_oferta = 1 AND p.preco_promocional IS NOT NULL THEN p.preco_promocional ELSE p.preco END";

    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Lista os jogos e suas categorias para o painel.
     */
    public function listarComCategoria(
        bool $somenteAtivos = false
    ): array {
        $sql = "
            SELECT p.*, p.id_produto AS id,
                   " . self::PRECO_FINAL_SQL . " AS preco_final,
                   (SELECT GROUP_CONCAT(c.nome ORDER BY c.nome SEPARATOR ', ')
                      FROM produto_categoria pc
                      JOIN categoria c ON c.id_categoria = pc.id_categoria
                     WHERE pc.id_produto = p.id_produto) AS categorias_nome,
                   (SELECT GROUP_CONCAT(pc2.id_categoria)
                      FROM produto_categoria pc2
                     WHERE pc2.id_produto = p.id_produto) AS categorias_ids
            FROM produto p
        ";

        if ($somenteAtivos) {
            $sql .= " WHERE p.ativo = 1 ";
        }

        $sql .= " ORDER BY p.id_produto DESC";

        return $this->conn->query($sql)->fetchAll();
    }

    /**
     * Busca um jogo pelo ID e suas categorias.
     */
    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->conn->prepare(
            "SELECT p.*, p.id_produto AS id
             FROM produto p
             WHERE p.id_produto = :id"
        );

        $stmt->execute([':id' => $id]);

        $r = $stmt->fetch();

        if (!$r) {
            return null;
        }

        $r['categorias'] = $this->idsDasCategorias($id);

        return $r;
    }

    /**
     * Retorna os IDs das categorias de um jogo.
     */
    public function idsDasCategorias(int $produtoId): array
    {
        $stmt = $this->conn->prepare(
            "SELECT id_categoria
             FROM produto_categoria
             WHERE id_produto = :id"
        );

        $stmt->execute([':id' => $produtoId]);

        return array_map(
            'intval',
            $stmt->fetchAll(PDO::FETCH_COLUMN)
        );
    }

    /**
     * Cadastra um jogo e suas categorias.
     *
     * @param array $d Dados do jogo.
     * @param int[] $categorias IDs das categorias.
     */
    public function inserir(
        array $d,
        array $categorias
    ): int {
        $this->conn->beginTransaction();

        try {
            $stmt = $this->conn->prepare("
                INSERT INTO produto
                    (nome, descricao, preco, arquivo_download,
                     preco_promocional, em_oferta, ativo)
                VALUES
                    (:nome, :descricao, :preco, :arquivo,
                     :promo, :oferta, 1)
            ");

            $stmt->execute([
                ':nome' => $d['nome'],
                ':descricao' => $d['descricao'],
                ':preco' => $d['preco'],
                ':arquivo' => $d['arquivo_download'],
                ':promo' => $d['preco_promocional'],
                ':oferta' => $d['em_oferta'] ? 1 : 0,
            ]);

            $id = (int) $this->conn->lastInsertId();

            $this->gravarCategorias($id, $categorias);

            $this->conn->commit();

            return $id;

        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }

            throw $e;
        }
    }

    /**
     * Atualiza os dados e as categorias de um jogo.
     */
    public function atualizar(
        int $id,
        array $d,
        array $categorias
    ): void {
        $this->conn->beginTransaction();

        try {
            $stmt = $this->conn->prepare("
                UPDATE produto
                SET nome = :nome,
                    descricao = :descricao,
                    preco = :preco,
                    arquivo_download = :arquivo,
                    preco_promocional = :promo,
                    em_oferta = :oferta
                WHERE id_produto = :id
            ");

            $stmt->execute([
                ':id' => $id,
                ':nome' => $d['nome'],
                ':descricao' => $d['descricao'],
                ':preco' => $d['preco'],
                ':arquivo' => $d['arquivo_download'],
                ':promo' => $d['preco_promocional'],
                ':oferta' => $d['em_oferta'] ? 1 : 0,
            ]);

            $this->gravarCategorias($id, $categorias);

            $this->conn->commit();

        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }

            throw $e;
        }
    }

    /**
     * Atualiza o caminho da imagem de um jogo.
     */
    public function setImagem(
        int $id,
        ?string $caminho
    ): void {
        $stmt = $this->conn->prepare(
            "UPDATE produto
             SET imagem = :img
             WHERE id_produto = :id"
        );

        $stmt->execute([
            ':img' => $caminho,
            ':id' => $id
        ]);
    }

    /**
     * Ativa ou desativa um jogo.
     */
    public function setAtivo(
        int $id,
        bool $ativo
    ): void {
        $stmt = $this->conn->prepare(
            "UPDATE produto
             SET ativo = :ativo
             WHERE id_produto = :id"
        );

        $stmt->execute([
            ':id' => $id,
            ':ativo' => $ativo ? 1 : 0
        ]);
    }

    /**
     * Exclui um jogo e seus vínculos com categorias.
     */
    public function deletar(int $id): void
    {
        $this->conn->beginTransaction();

        try {
            $this->conn->prepare(
                "DELETE FROM produto_categoria
                 WHERE id_produto = :id"
            )->execute([':id' => $id]);

            $this->conn->prepare(
                "DELETE FROM produto
                 WHERE id_produto = :id"
            )->execute([':id' => $id]);

            $this->conn->commit();

        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }

            throw $e;
        }
    }

    /**
     * Lista os jogos ativos com seus preços finais.
     */
    public function listarParaPdv(): array
    {
        return $this->conn->query("
            SELECT
                p.id_produto AS id,
                p.nome,
                " . self::PRECO_FINAL_SQL . " AS preco
            FROM produto p
            WHERE p.ativo = 1
            ORDER BY p.nome ASC
        ")->fetchAll();
    }

    /**
     * Atualiza os vínculos entre jogos e categorias.
     */
    private function gravarCategorias(
        int $produtoId,
        array $categorias
    ): void {
        $this->conn->prepare(
            "DELETE FROM produto_categoria
             WHERE id_produto = :id"
        )->execute([':id' => $produtoId]);

        $ins = $this->conn->prepare(
            "INSERT INTO produto_categoria
                (id_produto, id_categoria)
             VALUES
                (:p, :c)"
        );

        foreach (
            array_unique(array_map('intval', $categorias)) as $cid
        ) {
            if ($cid > 0) {
                $ins->execute([
                    ':p' => $produtoId,
                    ':c' => $cid
                ]);
            }
        }
    }
}
