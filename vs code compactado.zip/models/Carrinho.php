
<?php
require_once __DIR__ . '/Vitrine.php';
require_once __DIR__ . '/../config/db.php';

class Carrinho
{
    private Vitrine $vitrine;
    private PDO $db;

    public function __construct()
    {
        $this->vitrine = new Vitrine();
        $this->db = Database::getConnection();

        if (
            !isset($_SESSION['carrinho']) ||
            !is_array($_SESSION['carrinho'])
        ) {
            $_SESSION['carrinho'] = [];
        }
    }

    private function clienteCpf(): ?string
    {
        $cpf = $_SESSION['cliente_id'] ?? null;

        return is_string($cpf) &&
            preg_match('/^[0-9]{11}$/', $cpf)
                ? $cpf
                : null;
    }

    /**
     * Confere se o cliente já possui o jogo.
     * Somente compras pagas e aprovadas contam.
     */
    public function jaPossui(int $produtoId): bool
    {
        $cpf = $this->clienteCpf();

        if ($cpf === null || $produtoId <= 0) {
            return false;
        }

        $stmt = $this->db->prepare("
            SELECT 1
            FROM pedido p
            INNER JOIN item_pedido ip
                ON ip.id_pedido = p.id_pedido
            INNER JOIN pagamento pg
                ON pg.id_pedido = p.id_pedido
            WHERE p.cliente_cpf = :cpf
              AND ip.id_produto = :produto
              AND p.STATUS = 'pago'
              AND pg.status = 'aprovado'
            LIMIT 1
        ");

        $stmt->execute([
            ':cpf' => $cpf,
            ':produto' => $produtoId
        ]);

        return $stmt->fetchColumn() !== false;
    }

    private function buscarIdCarrinho(string $cpf): ?int
    {
        $stmt = $this->db->prepare("
            SELECT id_carrinho
            FROM carrinho
            WHERE cliente_cpf = :cpf
        ");

        $stmt->execute([':cpf' => $cpf]);

        $id = $stmt->fetchColumn();

        return $id === false ? null : (int) $id;
    }

    private function obterIdCarrinho(string $cpf): int
    {
        $id = $this->buscarIdCarrinho($cpf);

        if ($id !== null) {
            return $id;
        }

        $stmt = $this->db->prepare("
            INSERT INTO carrinho (cliente_cpf)
            VALUES (:cpf)
            ON DUPLICATE KEY UPDATE
                id_carrinho = LAST_INSERT_ID(id_carrinho)
        ");

        $stmt->execute([':cpf' => $cpf]);

        return (int) $this->db->lastInsertId();
    }

    private function montarItem(array $produto): array
    {
        $categorias = [];

        foreach (($produto['categorias'] ?? []) as $categoria) {
            if (!empty($categoria['nome'])) {
                $categorias[] = $categoria['nome'];
            }
        }

        return [
            'produto_id' => (int) $produto['id'],
            'produto_nome' => $produto['nome'],
            'preco_unitario' => (float) $produto['preco_final'],
            'preco_original' => (float) $produto['preco'],
            'quantidade' => 1,
            'categorias_nomes' => implode(', ', $categorias),
            'imagem' => imagemProduto(
                (int) $produto['id'],
                $produto['imagem']
            )
        ];
    }

    private function idsDoBanco(string $cpf): array
    {
        $idCarrinho = $this->buscarIdCarrinho($cpf);

        if ($idCarrinho === null) {
            return [];
        }

        $stmt = $this->db->prepare("
            SELECT id_produto
            FROM itens_carrinho
            WHERE id_carrinho = :id
            ORDER BY data_adicionado, id_item_carrinho
        ");

        $stmt->execute([':id' => $idCarrinho]);

        return array_map(
            'intval',
            $stmt->fetchAll(PDO::FETCH_COLUMN)
        );
    }

    private function inserirNoBanco(
        string $cpf,
        int $produtoId
    ): bool {
        if ($this->jaPossui($produtoId)) {
            throw new RegraNegocioException(
                'Você já possui esse jogo. Acesse Meus jogos.'
            );
        }

        $idCarrinho = $this->obterIdCarrinho($cpf);

        $stmt = $this->db->prepare("
            INSERT INTO itens_carrinho
                (id_carrinho, id_produto)
            VALUES (:carrinho, :produto)
            ON DUPLICATE KEY UPDATE
                id_produto = id_produto
        ");

        $stmt->execute([
            ':carrinho' => $idCarrinho,
            ':produto' => $produtoId
        ]);

        return $stmt->rowCount() === 1;
    }

    private function transferirSessao(): void
    {
        $cpf = $this->clienteCpf();

        if ($cpf === null || empty($_SESSION['carrinho'])) {
            return;
        }

        foreach (array_keys($_SESSION['carrinho']) as $id) {
            $produtoId = (int) $id;

            try {
                if (
                    $produtoId > 0 &&
                    !$this->jaPossui($produtoId) &&
                    $this->vitrine->buscarProduto($produtoId)
                ) {
                    $this->inserirNoBanco($cpf, $produtoId);
                }
            } finally {
                unset($_SESSION['carrinho'][$id]);
            }
        }
    }

    public function itens(): array
    {
        $cpf = $this->clienteCpf();

        if ($cpf === null) {
            return array_values($_SESSION['carrinho']);
        }

        $this->transferirSessao();

        $itens = [];

        foreach ($this->idsDoBanco($cpf) as $produtoId) {
            if ($this->jaPossui($produtoId)) {
                $this->remover($produtoId);
                continue;
            }

            $produto = $this->vitrine->buscarProduto($produtoId);

            if ($produto) {
                $itens[] = $this->montarItem($produto);
            }
        }

        return $itens;
    }

    public function vazio(): bool
    {
        return count($this->itens()) === 0;
    }

    public function contar(): int
    {
        return count($this->itens());
    }

    public function subtotal(array $item): float
    {
        return round((float) $item['preco_unitario'], 2);
    }

    public function total(): float
    {
        $total = 0.0;

        foreach ($this->itens() as $item) {
            $total += (float) $item['preco_unitario'];
        }

        return round($total, 2);
    }

    public function adicionar(int $produtoId): bool
    {
        if ($produtoId <= 0) {
            throw new RegraNegocioException('Jogo inválido.');
        }

        $produto = $this->vitrine->buscarProduto($produtoId);

        if (!$produto) {
            throw new RegraNegocioException(
                'Esse jogo não está mais disponível.'
            );
        }

        $cpf = $this->clienteCpf();

        if ($cpf === null) {
            if (isset($_SESSION['carrinho'][$produtoId])) {
                return false;
            }

            $_SESSION['carrinho'][$produtoId] =
                $this->montarItem($produto);

            return true;
        }

        if ($this->jaPossui($produtoId)) {
            throw new RegraNegocioException(
                'Você já comprou esse jogo! Ele está disponível em Meus jogos.'
            );
        }

        $this->transferirSessao();

        return $this->inserirNoBanco($cpf, $produtoId);
    }

    public function remover(int $produtoId): void
    {
        unset($_SESSION['carrinho'][$produtoId]);

        $cpf = $this->clienteCpf();

        if ($cpf === null) {
            return;
        }

        $idCarrinho = $this->buscarIdCarrinho($cpf);

        if ($idCarrinho === null) {
            return;
        }

        $stmt = $this->db->prepare("
            DELETE FROM itens_carrinho
            WHERE id_carrinho = :carrinho
              AND id_produto = :produto
        ");

        $stmt->execute([
            ':carrinho' => $idCarrinho,
            ':produto' => $produtoId
        ]);
    }

    public function limpar(): void
    {
        $_SESSION['carrinho'] = [];

        $cpf = $this->clienteCpf();

        if ($cpf === null) {
            return;
        }

        $idCarrinho = $this->buscarIdCarrinho($cpf);

        if ($idCarrinho === null) {
            return;
        }

        $stmt = $this->db->prepare("
            DELETE FROM itens_carrinho
            WHERE id_carrinho = :id
        ");

        $stmt->execute([':id' => $idCarrinho]);
    }

    public function sincronizar(): array
    {
        $avisos = [];
        $cpf = $this->clienteCpf();

        if ($cpf !== null) {
            $this->transferirSessao();
        }

        if ($cpf === null) {
            foreach ($_SESSION['carrinho'] as $id => $item) {
                $produto = $this->vitrine->buscarProduto((int) $id);
                $nome = $item['produto_nome'] ?? 'Jogo';

                if (!$produto) {
                    unset($_SESSION['carrinho'][$id]);
                    $avisos[] = "“{$nome}” não está mais disponível.";
                    continue;
                }

                $precoAtual = (float) $produto['preco_final'];

                if (
                    abs(
                        $precoAtual -
                        (float) $item['preco_unitario']
                    ) > 0.001
                ) {
                    $_SESSION['carrinho'][$id] =
                        $this->montarItem($produto);

                    $avisos[] = "O preço de “{$nome}” foi atualizado para "
                        . moeda($precoAtual) . '.';
                }
            }

            return $avisos;
        }

        foreach ($this->idsDoBanco($cpf) as $produtoId) {
            if ($this->jaPossui($produtoId)) {
                $this->remover($produtoId);

                $avisos[] =
                    'Um jogo que você já possui foi removido do carrinho.';

                continue;
            }

            if (!$this->vitrine->buscarProduto($produtoId)) {
                $this->remover($produtoId);

                $avisos[] =
                    'Um jogo indisponível foi removido do carrinho.';
            }
        }

        return $avisos;
    }
}
