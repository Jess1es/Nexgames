
<?php
/**
 * NexGames — Model de avaliações.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/Carrinho.php';

class Avaliacao
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * Lista as avaliações de um jogo.
     */
    public function listarPorProduto(int $produtoId): array
    {
        $stmt = $this->db->prepare("
            SELECT
                a.id_avaliacao,
                a.nota,
                a.comentario,
                a.data_avaliacao,
                c.nome AS cliente_nome
            FROM avaliacao a
            INNER JOIN cliente_site c
                ON c.cpf = a.cliente_cpf
            WHERE a.id_produto = :produto
            ORDER BY a.data_avaliacao DESC,
                     a.id_avaliacao DESC
        ");

        $stmt->execute([
            ':produto' => $produtoId
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Verifica se o cliente já avaliou o jogo.
     */
    public function buscarDoCliente(
        string $cpf,
        int $produtoId
    ): ?array {
        $stmt = $this->db->prepare("
            SELECT *
            FROM avaliacao
            WHERE cliente_cpf = :cpf
              AND id_produto = :produto
            LIMIT 1
        ");

        $stmt->execute([
            ':cpf' => $cpf,
            ':produto' => $produtoId
        ]);

        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

        return $resultado ?: null;
    }

    /**
     * Salva uma avaliação e valida
     * as permissões do cliente.
     */
    public function salvar(
        string $cpf,
        int $produtoId,
        int $nota,
        string $comentario
    ): void {
        if (!preg_match('/^[0-9]{11}$/', $cpf)) {
            throw new RegraNegocioException(
                'Entre na sua conta para avaliar.'
            );
        }

        if ($produtoId <= 0) {
            throw new RegraNegocioException(
                'Jogo inválido.'
            );
        }

        if ($nota < 1 || $nota > 5) {
            throw new RegraNegocioException(
                'Escolha uma nota de 1 a 5 estrelas.'
            );
        }

        $comentario = trim($comentario);

        if (mb_strlen($comentario, 'UTF-8') > 1000) {
            throw new RegraNegocioException(
                'O comentário deve ter até 1000 caracteres.'
            );
        }

        // Apenas clientes que possuem o jogo podem avaliá-lo.
        $carrinho = new Carrinho();

        if (!$carrinho->jaPossui($produtoId)) {
            throw new RegraNegocioException(
                'Você precisa possuir este jogo para avaliá-lo.'
            );
        }

        if ($this->buscarDoCliente($cpf, $produtoId)) {
            throw new RegraNegocioException(
                'Você já avaliou este jogo.'
            );
        }

        try {
            $stmt = $this->db->prepare("
                INSERT INTO avaliacao
                    (cliente_cpf, id_produto, nota, comentario)
                VALUES
                    (:cpf, :produto, :nota, :comentario)
            ");

            $stmt->execute([
                ':cpf' => $cpf,
                ':produto' => $produtoId,
                ':nota' => $nota,
                ':comentario' =>
                    $comentario !== '' ? $comentario : null
            ]);

        } catch (PDOException $e) {

            // Trata tentativas de avaliações duplicadas.
            if ($e->getCode() === '23000') {
                throw new RegraNegocioException(
                    'Não foi possível cadastrar a avaliação. '
                    . 'Verifique se você já avaliou este jogo.'
                );
            }

            throw $e;
        }
    }
}
