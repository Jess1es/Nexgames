
<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de vendas.
 *
 * Consulta os pedidos realizados na loja,
 * incluindo os dados dos clientes, jogos,
 * pagamentos e notas fiscais fictícias.
 */
class Venda
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Lista as vendas mais recentes para o painel.
     */
    public function listarRecentes(int $limite = 20): array
    {
        $limite = max(1, $limite);

        $stmt = $this->conn->prepare("
            SELECT
                p.id_pedido AS id,
                p.id_pedido,
                p.data,
                p.STATUS AS status,
                p.valor_total,
                c.nome AS cliente_nome,
                c.email AS cliente_email,
                p.cliente_cpf,
                p.forma_pagamento,
                CASE
                    WHEN nf.id IS NOT NULL THEN 1
                    ELSE 0
                END AS tem_nota
            FROM pedido p
            INNER JOIN cliente_site c
                ON c.cpf = p.cliente_cpf
            LEFT JOIN nota_fiscal_venda nf
                ON nf.id_pedido = p.id_pedido
            ORDER BY p.id_pedido DESC
            LIMIT :limite
        ");

        $stmt->bindValue(
            ':limite',
            $limite,
            PDO::PARAM_INT
        );

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Busca os detalhes de uma venda.
     */
    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT
                p.id_pedido AS id,
                p.id_pedido,
                p.data,
                p.STATUS AS status,
                p.valor_total,
                p.forma_pagamento,
                p.cliente_cpf,
                c.nome AS cliente_nome,
                c.email AS cliente_email,
                c.telefone AS cliente_telefone,
                nf.id AS nota_id,
                nf.serie AS nota_serie,
                nf.numero AS nota_numero,
                nf.data_emissao AS nota_data_emissao
            FROM pedido p
            INNER JOIN cliente_site c
                ON c.cpf = p.cliente_cpf
            LEFT JOIN nota_fiscal_venda nf
                ON nf.id_pedido = p.id_pedido
            WHERE p.id_pedido = :id
        ");

        $stmt->execute([
            ':id' => $id
        ]);

        $venda = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$venda) {
            return null;
        }

        $stmtItens = $this->conn->prepare("
            SELECT
                ip.id_item_pedido,
                ip.id_produto,
                pr.nome AS produto_nome,
                pr.imagem,
                ip.preco_unitario,
                ip.subtotal
            FROM item_pedido ip
            INNER JOIN produto pr
                ON pr.id_produto = ip.id_produto
            WHERE ip.id_pedido = :id
            ORDER BY ip.id_item_pedido
        ");

        $stmtItens->execute([
            ':id' => $id
        ]);

        $venda['itens'] = $stmtItens->fetchAll(
            PDO::FETCH_ASSOC
        );

        $stmtPagamento = $this->conn->prepare("
            SELECT
                id_pagamento,
                data_pagamento,
                forma_pagamento,
                valor,
                status
            FROM pagamento
            WHERE id_pedido = :id
            LIMIT 1
        ");

        $stmtPagamento->execute([
            ':id' => $id
        ]);

        $venda['pagamento'] = $stmtPagamento->fetch(
            PDO::FETCH_ASSOC
        ) ?: null;

        $venda['tem_nota'] = $venda['nota_id'] !== null;

        return $venda;
    }
}
