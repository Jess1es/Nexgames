
<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/produto.php';

/**
 * NexGames — Model da vitrine.
 *
 * Gerencia a exibição dos jogos digitais,
 * categorias, pesquisas e filtros do catálogo.
 */
class Vitrine
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * Lista as categorias ativas da loja.
     */
    public function categoriasAtivas(): array
    {
        return $this->db->query("
            SELECT
                id_categoria,
                id_categoria AS id,
                nome,
                descricao
            FROM categoria
            WHERE ativo = 1
            ORDER BY nome
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Lista os jogos ativos conforme os filtros.
     */
    public function listar(
        array $filtros = [],
        ?int $limite = null,
        int $offset = 0
    ): array {
        [$where, $params] =
            $this->montarFiltro($filtros);

        $sql = "
            SELECT
                p.id_produto AS id,
                p.nome,
                p.descricao,
                p.preco,
                p.preco_promocional,
                p.em_oferta,
                p.imagem,

                " . Produto::PRECO_FINAL_SQL . "
                AS preco_final,

                (
                    SELECT GROUP_CONCAT(
                        c.nome
                        ORDER BY c.nome
                        SEPARATOR ', '
                    )
                    FROM produto_categoria pc
                    JOIN categoria c
                        ON c.id_categoria = pc.id_categoria
                    WHERE pc.id_produto = p.id_produto
                      AND c.ativo = 1
                ) AS categorias_nome

            FROM produto p
            WHERE $where
            ORDER BY p.nome
        ";

        if ($limite !== null) {
            $sql .= " LIMIT :limite OFFSET :offset";
        }

        $stmt = $this->db->prepare($sql);

        foreach ($params as $nome => $valor) {
            $stmt->bindValue(
                $nome,
                $valor,
                is_int($valor)
                    ? PDO::PARAM_INT
                    : PDO::PARAM_STR
            );
        }

        if ($limite !== null) {
            $stmt->bindValue(
                ':limite',
                $limite,
                PDO::PARAM_INT
            );

            $stmt->bindValue(
                ':offset',
                $offset,
                PDO::PARAM_INT
            );
        }

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Conta os jogos conforme os filtros.
     */
    public function contar(array $filtros = []): int
    {
        [$where, $params] =
            $this->montarFiltro($filtros);

        $stmt = $this->db->prepare("
            SELECT COUNT(*)
            FROM produto p
            WHERE $where
        ");

        foreach ($params as $nome => $valor) {
            $stmt->bindValue(
                $nome,
                $valor,
                is_int($valor)
                    ? PDO::PARAM_INT
                    : PDO::PARAM_STR
            );
        }

        $stmt->execute();

        return (int) $stmt->fetchColumn();
    }

    /**
     * Monta os filtros de pesquisa do catálogo.
     */
    private function montarFiltro(
        array $filtros
    ): array {
        $where = ['p.ativo = 1'];
        $params = [];

        // Filtra pela categoria selecionada.
        if (!empty($filtros['categoria_id'])) {
            $where[] = "
                EXISTS (
                    SELECT 1
                    FROM produto_categoria pcf
                    JOIN categoria cf
                        ON cf.id_categoria = pcf.id_categoria
                    WHERE pcf.id_produto = p.id_produto
                      AND pcf.id_categoria = :categoria_id
                      AND cf.ativo = 1
                )
            ";

            $params[':categoria_id'] =
                (int) $filtros['categoria_id'];
        }

        // Pesquisa pelo nome do jogo.
        if (!empty($filtros['busca'])) {
            $where[] = "p.nome LIKE :busca";

            $busca = str_replace(
                ['\\', '%', '_'],
                ['\\\\', '\\%', '\\_'],
                $filtros['busca']
            );

            $params[':busca'] = '%' . $busca . '%';
        }

        // Exibe apenas jogos em oferta.
        if (!empty($filtros['oferta'])) {
            $where[] = "
                p.em_oferta = 1
                AND p.preco_promocional IS NOT NULL
            ";
        }

        return [
            implode(' AND ', $where),
            $params
        ];
    }

    /**
     * Busca os detalhes de um jogo ativo.
     */
    public function buscarProduto(int $id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT
                p.id_produto AS id,
                p.nome,
                p.descricao,
                p.preco,
                p.preco_promocional,
                p.em_oferta,
                p.imagem,
                " . Produto::PRECO_FINAL_SQL . "
                AS preco_final

             FROM produto p

             WHERE p.id_produto = :id
               AND p.ativo = 1"
        );

        $stmt->execute([
            ':id' => $id
        ]);

        $produto = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$produto) {
            return null;
        }

        // Consulta as categorias vinculadas ao jogo.
        $stmt = $this->db->prepare(
            "SELECT
                c.id_categoria AS id,
                c.nome

             FROM produto_categoria pc

             JOIN categoria c
                ON c.id_categoria = pc.id_categoria

             WHERE pc.id_produto = :id
               AND c.ativo = 1

             ORDER BY c.nome"
        );

        $stmt->execute([
            ':id' => $id
        ]);

        $produto['categorias'] =
            $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $produto;
    }
}
