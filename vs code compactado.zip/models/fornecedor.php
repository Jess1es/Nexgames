
<?php
require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de fornecedores.
 *
 * Gerencia o cadastro, a consulta,
 * a atualização e a situação dos fornecedores.
 */
class Fornecedor
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Lista todos os fornecedores.
     */
    public function listarTodos(): array
    {
        return $this->conn->query("
            SELECT
                id_fornecedor AS id,
                nome,
                cnpj,
                telefone,
                email,
                ativo
            FROM fornecedor
            ORDER BY nome
        ")->fetchAll();
    }

    /**
     * Lista os fornecedores ativos.
     */
    public function listarAtivos(): array
    {
        return $this->conn->query("
            SELECT
                id_fornecedor AS id,
                nome
            FROM fornecedor
            WHERE ativo = 1
            ORDER BY nome
        ")->fetchAll();
    }

    /**
     * Busca um fornecedor pelo ID.
     */
    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT
                f.*,
                f.id_fornecedor AS id
            FROM fornecedor f
            WHERE f.id_fornecedor = :id
        ");

        $stmt->execute([
            ':id' => $id
        ]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Cadastra um novo fornecedor.
     */
    public function inserir(
        string $nome,
        string $cnpj,
        ?string $telefone,
        ?string $email
    ): int {
        $stmt = $this->conn->prepare("
            INSERT INTO fornecedor
                (nome, cnpj, telefone, email, ativo)
            VALUES
                (:nome, :cnpj, :telefone, :email, 1)
        ");

        $stmt->execute([
            ':nome' => $nome,
            ':cnpj' => $cnpj,
            ':telefone' => $telefone,
            ':email' => $email
        ]);

        return (int) $this->conn->lastInsertId();
    }

    /**
     * Atualiza os dados de um fornecedor.
     */
    public function atualizar(
        int $id,
        string $nome,
        string $cnpj,
        ?string $telefone,
        ?string $email
    ): void {
        $stmt = $this->conn->prepare("
            UPDATE fornecedor
            SET
                nome = :nome,
                cnpj = :cnpj,
                telefone = :telefone,
                email = :email
            WHERE id_fornecedor = :id
        ");

        $stmt->execute([
            ':id' => $id,
            ':nome' => $nome,
            ':cnpj' => $cnpj,
            ':telefone' => $telefone,
            ':email' => $email
        ]);
    }

    /**
     * Ativa ou desativa um fornecedor.
     */
    public function setAtivo(
        int $id,
        bool $ativo
    ): void {
        $stmt = $this->conn->prepare("
            UPDATE fornecedor
            SET ativo = :ativo
            WHERE id_fornecedor = :id
        ");

        $stmt->execute([
            ':id' => $id,
            ':ativo' => $ativo ? 1 : 0
        ]);
    }
}
