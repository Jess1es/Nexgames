
<?php
require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de clientes.
 *
 * Gerencia a consulta e o cadastro
 * de clientes na tabela cliente.
 */
class Cliente
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Busca um cliente pelo ID.
     */
    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT
                c.*,
                c.id_cliente AS id
            FROM cliente c
            WHERE c.id_cliente = :id
        ");

        $stmt->execute([
            ':id' => $id
        ]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Busca um cliente pelo CPF.
     */
    public function buscarPorCpf(
        string $cpfSomenteDigitos
    ): ?array {
        $stmt = $this->conn->prepare("
            SELECT
                c.*,
                c.id_cliente AS id
            FROM cliente c
            WHERE REPLACE(
                REPLACE(CAST(c.cpf AS CHAR), '.', ''),
                '-',
                ''
            ) = :cpf
            LIMIT 1
        ");

        $stmt->execute([
            ':cpf' => $cpfSomenteDigitos
        ]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Cadastra um cliente na tabela cliente
     * utilizando os dados de cliente_site.
     */
    public function criarAPartirDoSite(
        array $clienteSite
    ): int {
        $stmt = $this->conn->prepare("
            INSERT INTO cliente
                (nome, cpf, telefone, email)
            VALUES
                (:nome, :cpf, :telefone, :email)
        ");

        $stmt->execute([
            ':nome' => $clienteSite['nome'],
            ':cpf' => $clienteSite['cpf'],
            ':telefone' => $clienteSite['telefone'],
            ':email' => $clienteSite['email'],
        ]);

        return (int) $this->conn->lastInsertId();
    }
}
