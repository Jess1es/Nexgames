
<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de notas fiscais fictícias.
 *
 * Gerencia a emissão e a consulta de notas
 * fiscais vinculadas aos pedidos da loja.
 */
class NotaFiscal
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Busca a nota fiscal de um pedido.
     */
    public function buscarPorPedido(int $idPedido): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT
                nf.*,
                p.cliente_cpf,
                c.nome AS cliente_nome,
                c.email AS cliente_email
            FROM nota_fiscal_venda nf
            INNER JOIN pedido p
                ON p.id_pedido = nf.id_pedido
            INNER JOIN cliente_site c
                ON c.cpf = p.cliente_cpf
            WHERE nf.id_pedido = :id_pedido
            LIMIT 1
        ");

        $stmt->execute([
            ':id_pedido' => $idPedido
        ]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Emite uma nota fiscal fictícia
     * para um pedido com pagamento aprovado.
     */
    public function emitirParaPedido(
        int $idPedido,
        string $serie = '1'
    ): int {
        if ($idPedido <= 0) {
            throw new InvalidArgumentException(
                'Pedido inválido.'
            );
        }

        $serie = trim($serie);

        if ($serie === '' || strlen($serie) > 5) {
            throw new InvalidArgumentException(
                'A série deve conter de 1 a 5 caracteres.'
            );
        }

        $this->conn->beginTransaction();

        try {
            $stmt = $this->conn->prepare("
                SELECT
                    p.id_pedido,
                    p.STATUS AS status_pedido,
                    p.valor_total,
                    pg.status AS status_pagamento
                FROM pedido p
                LEFT JOIN pagamento pg
                    ON pg.id_pedido = p.id_pedido
                WHERE p.id_pedido = :id_pedido
                FOR UPDATE
            ");

            $stmt->execute([
                ':id_pedido' => $idPedido
            ]);

            $pedido = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$pedido) {
                throw new RuntimeException(
                    'Pedido não encontrado.'
                );
            }

            if ($pedido['status_pedido'] !== 'pago') {
                throw new RuntimeException(
                    'O pedido ainda não foi pago.'
                );
            }

            if ($pedido['status_pagamento'] !== 'aprovado') {
                throw new RuntimeException(
                    'O pagamento ainda não foi aprovado.'
                );
            }

            $notaExistente = $this->buscarPorPedido(
                $idPedido
            );

            if ($notaExistente) {
                $this->conn->commit();

                return (int) $notaExistente['id'];
            }

            $numero = $this->proximoNumero($serie);

            if (strlen($numero) > 5) {
                throw new RuntimeException(
                    'A numeração da série foi esgotada.'
                );
            }

            $ins = $this->conn->prepare("
                INSERT INTO nota_fiscal_venda (
                    id_pedido,
                    serie,
                    numero,
                    data_emissao,
                    valor_total
                ) VALUES (
                    :id_pedido,
                    :serie,
                    :numero,
                    CURDATE(),
                    :valor_total
                )
            ");

            $ins->execute([
                ':id_pedido' => $idPedido,
                ':serie' => $serie,
                ':numero' => $numero,
                ':valor_total' => $pedido['valor_total']
            ]);

            $idNota = (int) $this->conn->lastInsertId();

            $this->conn->commit();

            return $idNota;

        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }

            if (
                $e instanceof PDOException
                && $e->getCode() === '23000'
            ) {
                throw new RuntimeException(
                    'Não foi possível emitir a nota: '
                    . 'verifique se o pedido já possui uma nota.',
                    0,
                    $e
                );
            }

            throw $e;
        }
    }

    /**
     * Obtém o próximo número da série.
     */
    private function proximoNumero(string $serie): string
    {
        $stmt = $this->conn->prepare("
            SELECT
                MAX(CAST(numero AS UNSIGNED)) AS ultimo
            FROM nota_fiscal_venda
            WHERE serie = :serie
        ");

        $stmt->execute([
            ':serie' => $serie
        ]);

        $ultimo = (int) (
            $stmt->fetchColumn() ?: 0
        );

        return (string) ($ultimo + 1);
    }
}
