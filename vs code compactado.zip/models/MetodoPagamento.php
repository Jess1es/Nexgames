
<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de métodos de pagamento.
 *
 * Gerencia os métodos de pagamento
 * cadastrados pelos clientes.
 */
class MetodoPagamento
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * Lista os métodos de pagamento de um cliente.
     */
    public function listar(string $cpf): array
    {
        $sql = "SELECT *
                FROM metodo_pagamento
                WHERE cliente_cpf = :cpf
                ORDER BY criado_em DESC, id_metodo DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([':cpf' => $cpf]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Busca um método de pagamento pelo ID e CPF.
     */
    public function buscar(int $id, string $cpf): ?array
    {
        $sql = "SELECT *
                FROM metodo_pagamento
                WHERE id_metodo = :id
                  AND cliente_cpf = :cpf";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $id,
            ':cpf' => $cpf
        ]);

        $metodo = $stmt->fetch(PDO::FETCH_ASSOC);

        return $metodo ?: null;
    }

    /**
     * Cadastra ou atualiza um método de pagamento.
     */
    public function salvar(
        string $cpf,
        string $tipo,
        string $identificacao,
        ?string $ultimosDigitos,
        int $id = 0
    ): void {
        if ($id > 0) {
            $sql = "UPDATE metodo_pagamento
                    SET tipo = :tipo,
                        identificacao = :identificacao,
                        ultimos_digitos = :digitos
                    WHERE id_metodo = :id
                      AND cliente_cpf = :cpf";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
                ':tipo' => $tipo,
                ':identificacao' => $identificacao,
                ':digitos' => $ultimosDigitos,
                ':id' => $id,
                ':cpf' => $cpf
            ]);

            return;
        }

        $sql = "INSERT INTO metodo_pagamento
                    (cliente_cpf, tipo, identificacao, ultimos_digitos)
                VALUES
                    (:cpf, :tipo, :identificacao, :digitos)";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':cpf' => $cpf,
            ':tipo' => $tipo,
            ':identificacao' => $identificacao,
            ':digitos' => $ultimosDigitos
        ]);
    }

    /**
     * Exclui um método de pagamento do cliente.
     */
    public function excluir(int $id, string $cpf): void
    {
        $sql = "DELETE FROM metodo_pagamento
                WHERE id_metodo = :id
                  AND cliente_cpf = :cpf";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':id' => $id,
            ':cpf' => $cpf
        ]);
    }

    /**
     * Salva um método de pagamento
     * somente se ele ainda não estiver cadastrado.
     */
    public function salvarSeNaoExistir(
        string $cpf,
        string $tipo,
        string $identificacao,
        ?string $ultimosDigitos = null
    ): void {
        if (!in_array($tipo, ['credito', 'debito', 'pix'], true)) {
            throw new InvalidArgumentException(
                'Tipo de pagamento inválido.'
            );
        }

        $identificacao = trim($identificacao);

        if ($tipo === 'pix') {
            $identificacao = 'Pix';
            $ultimosDigitos = null;
        } elseif (
            $identificacao === '' ||
            mb_strlen($identificacao) > 100 ||
            !preg_match('/^[0-9]{4}$/', (string) $ultimosDigitos)
        ) {
            throw new InvalidArgumentException(
                'Dados do cartão inválidos.'
            );
        }

        $sql = "SELECT id_metodo
                FROM metodo_pagamento
                WHERE cliente_cpf = :cpf
                  AND tipo = :tipo
                  AND identificacao = :identificacao
                  AND ultimos_digitos <=> :digitos
                LIMIT 1";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            ':cpf' => $cpf,
            ':tipo' => $tipo,
            ':identificacao' => $identificacao,
            ':digitos' => $ultimosDigitos
        ]);

        if ($stmt->fetchColumn() !== false) {
            return;
        }

        $this->salvar(
            $cpf,
            $tipo,
            $identificacao,
            $ultimosDigitos
        );
    }
}
