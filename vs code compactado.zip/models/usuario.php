
<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de usuários.
 *
 * Gerencia o cadastro, a consulta e a
 * atualização de senhas dos usuários do sistema.
 */
class Usuario
{
    public const PERFIL_FUNCIONARIO = 'cliente';

    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Busca um usuário pelo e-mail.
     */
    public function buscarPorEmail(string $email): ?array
    {
        $stmt = $this->conn->prepare(
            "SELECT *
             FROM usuario
             WHERE email = :email
             LIMIT 1"
        );

        $stmt->execute([
            ':email' => $email
        ]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Cadastra um novo usuário no sistema.
     */
    public function cadastrar(
        string $nome,
        string $email,
        string $senhaHash,
        string $perfil = self::PERFIL_FUNCIONARIO,
        int $ativo = 1
    ): bool {
        $stmt = $this->conn->prepare("
            INSERT INTO usuario
                (nome, email, senha, perfil, ativo)
            VALUES
                (:nome, :email, :senha, :perfil, :ativo)
        ");

        return $stmt->execute([
            ':nome' => $nome,
            ':email' => $email,
            ':senha' => $senhaHash,
            ':perfil' => $perfil,
            ':ativo' => $ativo
        ]);
    }

    /**
     * Atualiza o hash da senha de um usuário.
     */
    public function atualizarSenhaHash(
        int $id,
        string $hash
    ): void {
        $stmt = $this->conn->prepare(
            "UPDATE usuario
             SET senha = :senha
             WHERE id = :id"
        );

        $stmt->execute([
            ':senha' => $hash,
            ':id' => $id
        ]);
    }
}
