<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de entradas de jogos digitais.
 * Não realiza controle de estoque físico.
 */
class Entrada
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    public function listarComFornecedor(): array
    {
        $stmt = $this->conn->query("
            SELECT
                e.id_entrada_mercadoria AS id,
                e.fornecedor_id,
                e.data,
                e.status,
                e.valor_total,
                f.nome AS fornecedor_nome,
                COUNT(i.id_item_entrada) AS total_jogos

            FROM entrada_jogos e

            INNER JOIN fornecedor f
                ON f.id_fornecedor = e.fornecedor_id

            LEFT JOIN item_entrada_jogos i
                ON i.id_entrada_mercadoria =
                   e.id_entrada_mercadoria

            GROUP BY
                e.id_entrada_mercadoria,
                e.fornecedor_id,
                e.data,
                e.status,
                e.valor_total,
                f.nome

            ORDER BY e.id_entrada_mercadoria DESC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listarFornecedoresAtivos(): array
    {
        return $this->conn->query("
            SELECT
                id_fornecedor,
                nome
            FROM fornecedor
            WHERE ativo = 1
            ORDER BY nome
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listarJogosAtivos(): array
    {
        return $this->conn->query("
            SELECT
                id_produto,
                nome
            FROM produto
            WHERE ativo = 1
            ORDER BY nome
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarItens(int $idEntrada): array
    {
        $stmt = $this->conn->prepare("
            SELECT
                i.id_produto,
                p.nome AS jogo_nome,
                i.quantidade,
                i.valor_unitario,
                i.subtotal

            FROM item_entrada_jogos i

            INNER JOIN produto p
                ON p.id_produto = i.id_produto

            WHERE i.id_entrada_mercadoria = :id
            ORDER BY p.nome
        ");

        $stmt->execute([
            ':id' => $idEntrada
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Registra uma entrada e seus respectivos jogos.
     *
     * @param array<int, array{
     *     id_produto:int,
     *     quantidade:int,
     *     valor_centavos:int
     * }> $itens
     */
    public function registrar(
        int $fornecedorId,
        array $itens,
        string $status = 'confirmada'
    ): int {
        if (
            $fornecedorId <= 0 ||
            !in_array(
                $status,
                ['rascunho', 'confirmada'],
                true
            )
        ) {
            throw new InvalidArgumentException(
                'Fornecedor ou status inválido.'
            );
        }

        if (!$itens) {
            throw new InvalidArgumentException(
                'Selecione pelo menos um jogo.'
            );
        }

        $this->conn->beginTransaction();

        try {
            // Verifica se o fornecedor está ativo.
            $stmt = $this->conn->prepare("
                SELECT id_fornecedor
                FROM fornecedor
                WHERE id_fornecedor = ?
                  AND ativo = 1
            ");

            $stmt->execute([$fornecedorId]);

            if (!$stmt->fetchColumn()) {
                throw new InvalidArgumentException(
                    'Fornecedor inexistente ou inativo.'
                );
            }

            // Verifica os jogos.
            $verificarJogo = $this->conn->prepare("
                SELECT id_produto
                FROM produto
                WHERE id_produto = ?
                  AND ativo = 1
            ");

            $normalizados = [];
            $totalCentavos = 0;

            foreach ($itens as $item) {
                $id = (int) (
                    $item['id_produto'] ?? 0
                );

                $quantidade = (int) (
                    $item['quantidade'] ?? 0
                );

                $centavos = (int) (
                    $item['valor_centavos'] ?? -1
                );

                if (
                    $id <= 0 ||
                    $quantidade <= 0 ||
                    $quantidade > 100000 ||
                    $centavos < 0 ||
                    $centavos > 999999999 ||
                    isset($normalizados[$id])
                ) {
                    throw new InvalidArgumentException(
                        'Dados dos jogos inválidos ou repetidos.'
                    );
                }

                $verificarJogo->execute([$id]);

                if (!$verificarJogo->fetchColumn()) {
                    throw new InvalidArgumentException(
                        'Um dos jogos está inativo ou não existe.'
                    );
                }

                $subtotal = $quantidade * $centavos;
                $totalCentavos += $subtotal;

                if (
                    $subtotal > 999999999 ||
                    $totalCentavos > 999999999
                ) {
                    throw new InvalidArgumentException(
                        'Valor da entrada excede o limite permitido.'
                    );
                }

                $normalizados[$id] = [
                    'quantidade' => $quantidade,
                    'valor' => number_format(
                        $centavos / 100,
                        2,
                        '.',
                        ''
                    ),
                    'subtotal' => number_format(
                        $subtotal / 100,
                        2,
                        '.',
                        ''
                    ),
                ];
            }

            // Registra a entrada.
            $stmt = $this->conn->prepare("
                INSERT INTO entrada_jogos (
                    fornecedor_id,
                    data,
                    status,
                    valor_total
                )
                VALUES (
                    :fornecedor,
                    CURDATE(),
                    :status,
                    :total
                )
            ");

            $stmt->execute([
                ':fornecedor' => $fornecedorId,
                ':status' => $status,
                ':total' => number_format(
                    $totalCentavos / 100,
                    2,
                    '.',
                    ''
                ),
            ]);

            $idEntrada = (int) $this->conn->lastInsertId();

            // Registra os jogos da entrada.
            $inserir = $this->conn->prepare("
                INSERT INTO item_entrada_jogos (
                    id_entrada_mercadoria,
                    id_produto,
                    quantidade,
                    valor_unitario,
                    subtotal
                )
                VALUES (
                    :entrada,
                    :produto,
                    :quantidade,
                    :valor,
                    :subtotal
                )
            ");

            foreach ($normalizados as $idProduto => $item) {
                $inserir->execute([
                    ':entrada' => $idEntrada,
                    ':produto' => $idProduto,
                    ':quantidade' => $item['quantidade'],
                    ':valor' => $item['valor'],
                    ':subtotal' => $item['subtotal'],
                ]);
            }

            $this->conn->commit();

            return $idEntrada;

        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }

            throw $e;
        }
    }
}