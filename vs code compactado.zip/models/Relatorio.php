
<?php

require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de relatórios.
 *
 * Consulta os indicadores de vendas,
 * faturamento e jogos cadastrados.
 */
class Relatorio
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Retorna a quantidade de pedidos pagos
     * no mês atual.
     */
    public function kpiVendasMes(): int
    {
        $sql = "
            SELECT COUNT(*)
            FROM pedido
            WHERE STATUS = 'pago'
              AND MONTH(data) = MONTH(CURDATE())
              AND YEAR(data) = YEAR(CURDATE())
        ";

        return (int) $this->conn->query($sql)->fetchColumn();
    }

    /**
     * Calcula o faturamento do mês atual
     * considerando os pedidos pagos.
     */
    public function kpiEntradasMes(): float
    {
        $sql = "
            SELECT COALESCE(SUM(valor_total), 0)
            FROM pedido
            WHERE STATUS = 'pago'
              AND MONTH(data) = MONTH(CURDATE())
              AND YEAR(data) = YEAR(CURDATE())
        ";

        return (float) $this->conn->query($sql)->fetchColumn();
    }

    /**
     * Retorna a quantidade de jogos ativos na loja.
     */
    public function kpiTotalProdutos(): int
    {
        $sql = "
            SELECT COUNT(*)
            FROM produto
            WHERE ativo = 1
        ";

        return (int) $this->conn->query($sql)->fetchColumn();
    }

    /**
     * Lista os jogos mais vendidos da NexGames.
     *
     * Considera somente pedidos pagos.
     * Cada registro em item_pedido representa
     * uma unidade de jogo vendida.
     */
    public function topProdutosMaisVendidos(
        int $limite = 5
    ): array {
        $sql = "
            SELECT
                p.nome,
                COUNT(*) AS total_vendido,
                COALESCE(SUM(ip.subtotal), 0) AS receita
            FROM item_pedido ip

            INNER JOIN pedido pe
                ON pe.id_pedido = ip.id_pedido

            INNER JOIN produto p
                ON p.id_produto = ip.id_produto

            WHERE pe.STATUS = 'pago'

            GROUP BY
                p.id_produto,
                p.nome

            ORDER BY
                total_vendido DESC,
                p.nome ASC

            LIMIT :limite
        ";

        $stmt = $this->conn->prepare($sql);

        $stmt->bindValue(
            ':limite',
            max(1, $limite),
            PDO::PARAM_INT
        );

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
