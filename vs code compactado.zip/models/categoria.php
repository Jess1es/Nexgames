
<?php
require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de categorias.
 *
 * Gerencia o cadastro, a consulta,
 * a atualização e a exclusão de categorias.
 */
class Categoria
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Lista todas as categorias e a quantidade
     * de jogos associados a cada uma.
     */
    public function listarTodas(): array
    {
        return $this->conn->query("
            SELECT
                c.*,
                c.id_categoria AS id,
                (
                    SELECT COUNT(*)
                    FROM produto_categoria pc
                    WHERE pc.id_categoria = c.id_categoria
                ) AS qtd_produtos
            FROM categoria c
            ORDER BY c.id_categoria DESC
        ")->fetchAll();
    }

    /**
     * Lista as categorias ativas.
     */
    public function listarAtivas(): array
    {
        return $this->conn->query("
            SELECT
                id_categoria,
                id_categoria AS id,
                nome
            FROM categoria
            WHERE ativo = 1
            ORDER BY nome
        ")->fetchAll();
    }

    /**
     * Busca uma categoria pelo ID.
     */
    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT
                c.*,
                c.id_categoria AS id
            FROM categoria c
            WHERE c.id_categoria = :id
        ");

        $stmt->execute([
            ':id' => $id
        ]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Cadastra uma nova categoria.
     */
    public function inserir(
        string $nome,
        string $descricao
    ): int {
        $stmt = $this->conn->prepare("
            INSERT INTO categoria
                (nome, descricao, ativo)
            VALUES
                (:nome, :descricao, 1)
        ");

        $stmt->execute([
            ':nome' => $nome,
            ':descricao' => $descricao
        ]);

        return (int) $this->conn->lastInsertId();
    }

    /**
     * Atualiza os dados de uma categoria.
     */
    public function atualizar(
        int $id,
        string $nome,
        string $descricao
    ): void {
        $stmt = $this->conn->prepare("
            UPDATE categoria
            SET
                nome = :nome,
                descricao = :descricao
            WHERE id_categoria = :id
        ");

        $stmt->execute([
            ':id' => $id,
            ':nome' => $nome,
            ':descricao' => $descricao
        ]);
    }

    /**
     * Ativa ou desativa uma categoria.
     */
    public function setAtivo(
        int $id,
        bool $ativo
    ): void {
        $stmt = $this->conn->prepare("
            UPDATE categoria
            SET ativo = :ativo
            WHERE id_categoria = :id
        ");

        $stmt->execute([
            ':id' => $id,
            ':ativo' => $ativo ? 1 : 0
        ]);
    }

    /**
     * Exclui uma categoria pelo ID.
     */
    public function deletar(int $id): void
    {
        $stmt = $this->conn->prepare("
            DELETE FROM categoria
            WHERE id_categoria = :id
        ");

        $stmt->execute([
            ':id' => $id
        ]);
    }
}
