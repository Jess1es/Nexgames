
<?php
require_once __DIR__ . '/../config/db.php';

/**
 * NexGames — Model de clientes do site.
 *
 * Gerencia cadastro, autenticação,
 * atualização e exclusão de contas.
 */
class ClienteSite
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    /**
     * Busca um cliente pelo CPF.
     */
    public function buscarPorCpf(string $cpf): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM cliente_site WHERE cpf = :cpf"
        );

        $stmt->execute([':cpf' => $cpf]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Busca um cliente pelo e-mail.
     */
    public function buscarPorEmail(string $email): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM cliente_site WHERE email = :email"
        );

        $stmt->execute([':email' => $email]);

        return $stmt->fetch() ?: null;
    }

    /**
     * Verifica se o e-mail pertence a outro cliente.
     */
    public function emailEmUso(
        string $email,
        ?string $cpfAtual = null
    ): bool {
        $stmt = $this->db->prepare(
            "SELECT cpf FROM cliente_site WHERE email = :email"
        );

        $stmt->execute([':email' => $email]);

        $cpf = $stmt->fetchColumn();

        return $cpf !== false && $cpf !== $cpfAtual;
    }

    /**
     * Cadastra um novo cliente.
     *
     * @param array $d Dados do cliente.
     * @throws RegraNegocioException
     */
    public function criar(array $d): void
    {
        $stmt = $this->db->prepare(
            "INSERT INTO cliente_site
                (cpf, nome, email, senha_hash, telefone)
             VALUES
                (:cpf, :nome, :email, :senha_hash, :telefone)"
        );

        try {
            $stmt->execute([
                ':cpf' => $d['cpf'],
                ':nome' => $d['nome'],
                ':email' => $d['email'],
                ':senha_hash' => password_hash(
                    $d['senha'],
                    PASSWORD_DEFAULT
                ),
                ':telefone' => $d['telefone'] !== ''
                    ? $d['telefone']
                    : null,
            ]);

        } catch (PDOException $ex) {

            // Trata violações de unicidade no cadastro.
            if ($ex->getCode() === '23000') {
                throw new RegraNegocioException(
                    'Já existe um cadastro com esse CPF ou e-mail.'
                );
            }

            throw $ex;
        }
    }

    /**
     * Atualiza os dados cadastrais do cliente.
     */
    public function atualizar(
        string $cpf,
        array $d
    ): void {
        $stmt = $this->db->prepare(
            "UPDATE cliente_site
             SET
                nome = :nome,
                email = :email,
                telefone = :telefone
             WHERE cpf = :cpf"
        );

        try {
            $stmt->execute([
                ':nome' => $d['nome'],
                ':email' => $d['email'],
                ':telefone' => $d['telefone'] !== ''
                    ? $d['telefone']
                    : null,
                ':cpf' => $cpf,
            ]);

        } catch (PDOException $ex) {

            if ($ex->getCode() === '23000') {
                throw new RegraNegocioException(
                    'Esse e-mail já está em uso por outro cadastro.'
                );
            }

            throw $ex;
        }
    }

    /**
     * Atualiza a senha do cliente.
     */
    public function atualizarSenha(
        string $cpf,
        string $novaSenha
    ): void {
        $stmt = $this->db->prepare(
            "UPDATE cliente_site
             SET senha_hash = :h
             WHERE cpf = :cpf"
        );

        $stmt->execute([
            ':h' => password_hash(
                $novaSenha,
                PASSWORD_DEFAULT
            ),
            ':cpf' => $cpf
        ]);
    }

    /**
     * Autentica o cliente por e-mail e senha.
     */
    public function autenticar(
        string $email,
        string $senha
    ): ?array {
        $cliente = $this->buscarPorEmail($email);

        // Executa a verificação mesmo quando o e-mail não existe.
        $hash = $cliente['senha_hash']
            ?? '$2y$10$abcdefghijklmnopqrstuuAbCdEfGhIjKlMnOpQrStUvWxYzAbCdE';

        $ok = password_verify($senha, $hash);

        if ($cliente && $ok) {
            if (
                password_needs_rehash(
                    $cliente['senha_hash'],
                    PASSWORD_DEFAULT
                )
            ) {
                $this->atualizarSenha(
                    $cliente['cpf'],
                    $senha
                );
            }

            return $cliente;
        }

        return null;
    }

    /**
     * Exclui um cliente sem histórico de pedidos.
     */
    public function excluir(string $cpf): void
    {
        $stmt = $this->db->prepare(
            "DELETE FROM cliente_site WHERE cpf = :cpf"
        );

        $stmt->execute([':cpf' => $cpf]);
    }

    /**
     * Anonimiza os dados da conta,
     * preservando o histórico de pedidos.
     */
    public function anonimizar(string $cpf): void
    {
        $stmt = $this->db->prepare(
            "UPDATE cliente_site
             SET
                nome = 'Conta excluída',
                email = CONCAT('excluido+', cpf, '@removido.local'),
                senha_hash = :hashInvalido,
                telefone = NULL
             WHERE cpf = :cpf"
        );

        // Substitui a senha por um hash aleatório.
        $stmt->execute([
            ':hashInvalido' => password_hash(
                bin2hex(random_bytes(16)),
                PASSWORD_DEFAULT
            ),
            ':cpf' => $cpf
        ]);
    }
}
