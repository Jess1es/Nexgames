
<?php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/produto.php';

/**
 * NexGames — Model de pedidos.
 *
 * Gerencia a criação de pedidos, pagamentos
 * simulados e histórico de compras dos clientes.
 */
class Pedido
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function criar(
        string $cpf,
        array $itens,
        string $metodo
    ): int {
        if (empty($itens)) {
            throw new RegraNegocioException(
                'Seu carrinho está vazio.'
            );
        }

        if (!in_array($metodo, ['pix', 'cartao'], true)) {
            throw new RegraNegocioException(
                'Forma de pagamento inválida.'
            );
        }

        $this->db->beginTransaction();

        try {
            $bloquearCliente = $this->db->prepare("
                SELECT cpf
                FROM cliente_site
                WHERE cpf = :cpf
                FOR UPDATE
            ");

            $bloquearCliente->execute([
                ':cpf' => $cpf
            ]);

            if ($bloquearCliente->fetchColumn() === false) {
                throw new RegraNegocioException(
                    'Cliente não encontrado.'
                );
            }

            $buscaProduto = $this->db->prepare(
                "SELECT p.nome, " .
                Produto::PRECO_FINAL_SQL .
                " AS preco
                 FROM produto p
                 WHERE p.id_produto = :id
                   AND p.ativo = 1"
            );

            $verificarCompra = $this->db->prepare("
                SELECT 1
                FROM pedido p
                INNER JOIN item_pedido ip
                    ON ip.id_pedido = p.id_pedido
                INNER JOIN pagamento pg
                    ON pg.id_pedido = p.id_pedido
                WHERE p.cliente_cpf = :cpf
                  AND ip.id_produto = :produto
                  AND p.STATUS = 'pago'
                  AND pg.status = 'aprovado'
                LIMIT 1
            ");

            $conferidos = [];
            $vistos = [];
            $total = 0.0;

            foreach ($itens as $item) {
                $produtoId = (int) (
                    $item['produto_id'] ?? 0
                );

                if ($produtoId <= 0) {
                    throw new RegraNegocioException(
                        'Jogo inválido no carrinho.'
                    );
                }

                if (isset($vistos[$produtoId])) {
                    continue;
                }

                $vistos[$produtoId] = true;

                $verificarCompra->execute([
                    ':cpf' => $cpf,
                    ':produto' => $produtoId
                ]);

                if ($verificarCompra->fetchColumn() !== false) {
                    throw new RegraNegocioException(
                        'Você já possui um dos jogos do carrinho.'
                    );
                }

                $buscaProduto->execute([
                    ':id' => $produtoId
                ]);

                $produto = $buscaProduto->fetch(
                    PDO::FETCH_ASSOC
                );

                if (!$produto) {
                    throw new RegraNegocioException(
                        'Um jogo não está mais disponível.'
                    );
                }

                $preco = round(
                    (float) $produto['preco'],
                    2
                );

                $conferidos[] = [
                    'produto_id' => $produtoId,
                    'preco' => $preco
                ];

                $total += $preco;
            }

            $total = round($total, 2);

            $stmt = $this->db->prepare("
                INSERT INTO pedido
                    (cliente_cpf, STATUS,
                     valor_total, forma_pagamento)
                VALUES
                    (:cpf, 'aguardando_pagamento',
                     :total, :forma)
            ");

            $stmt->execute([
                ':cpf' => $cpf,
                ':total' => $total,
                ':forma' => $metodo
            ]);

            $pedidoId = (int) $this->db->lastInsertId();

            $insItem = $this->db->prepare("
                INSERT INTO item_pedido
                    (id_pedido, id_produto,
                     preco_unitario, subtotal)
                VALUES
                    (:pedido, :produto,
                     :preco, :subtotal)
            ");

            foreach ($conferidos as $item) {
                $insItem->execute([
                    ':pedido' => $pedidoId,
                    ':produto' => $item['produto_id'],
                    ':preco' => $item['preco'],
                    ':subtotal' => $item['preco']
                ]);
            }

            $insPagamento = $this->db->prepare("
                INSERT INTO pagamento
                    (id_pedido, forma_pagamento,
                     valor, status)
                VALUES
                    (:pedido, :forma, :valor, 'pendente')
            ");

            $insPagamento->execute([
                ':pedido' => $pedidoId,
                ':forma' => $metodo,
                ':valor' => $total
            ]);

            $this->db->commit();

            return $pedidoId;

        } catch (Throwable $ex) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $ex;
        }
    }

    public function aprovarSimulado(
        int $pedidoId,
        string $cpf
    ): bool {
        if ($pedidoId <= 0) {
            return false;
        }

        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare("
                SELECT id_pedido, STATUS
                FROM pedido
                WHERE id_pedido = :id
                  AND cliente_cpf = :cpf
                FOR UPDATE
            ");

            $stmt->execute([
                ':id' => $pedidoId,
                ':cpf' => $cpf
            ]);

            $pedido = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$pedido || $pedido['STATUS'] === 'cancelado') {
                $this->db->rollBack();
                return false;
            }

            $pagamento = $this->db->prepare("
                SELECT id_pagamento, status
                FROM pagamento
                WHERE id_pedido = :id
                FOR UPDATE
            ");

            $pagamento->execute([
                ':id' => $pedidoId
            ]);

            $dadosPagamento = $pagamento->fetch(
                PDO::FETCH_ASSOC
            );

            if (
                !$dadosPagamento ||
                $dadosPagamento['status'] === 'cancelado'
            ) {
                $this->db->rollBack();
                return false;
            }

            $atualizarPagamento = $this->db->prepare("
                UPDATE pagamento
                SET status = 'aprovado'
                WHERE id_pedido = :id
                  AND status IN ('pendente', 'aprovado')
            ");

            $atualizarPagamento->execute([
                ':id' => $pedidoId
            ]);

            $atualizarPedido = $this->db->prepare("
                UPDATE pedido
                SET STATUS = 'pago'
                WHERE id_pedido = :id
                  AND cliente_cpf = :cpf
                  AND STATUS IN
                    ('aguardando_pagamento', 'pago')
            ");

            $atualizarPedido->execute([
                ':id' => $pedidoId,
                ':cpf' => $cpf
            ]);

            $this->db->commit();

        } catch (Throwable $ex) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            throw $ex;
        }

        // A nota fictícia não interfere na compra.
        try {
            require_once __DIR__ . '/NotaFiscal.php';

            $nota = new NotaFiscal();
            $nota->emitirParaPedido($pedidoId);

        } catch (Throwable $ex) {
            error_log(
                '[NexGames] Falha ao emitir nota #' .
                $pedidoId . ': ' . $ex->getMessage()
            );
        }

        return true;
    }

    public function buscarDoCliente(
        int $pedidoId,
        string $cpf
    ): ?array {
        $stmt = $this->db->prepare("
            SELECT p.*,
                   p.id_pedido AS id,
                   p.STATUS AS status
            FROM pedido p
            WHERE p.id_pedido = :id
              AND p.cliente_cpf = :cpf
        ");

        $stmt->execute([
            ':id' => $pedidoId,
            ':cpf' => $cpf
        ]);

        $pedido = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pedido) {
            return null;
        }

        $itens = $this->itensDosPedidos([$pedidoId]);

        $pedido['itens'] = $itens[$pedidoId] ?? [];

        $stmt = $this->db->prepare("
            SELECT *
            FROM pagamento
            WHERE id_pedido = :id
        ");

        $stmt->execute([
            ':id' => $pedidoId
        ]);

        $pedido['pagamento'] =
            $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        return $pedido;
    }

    public function listarDoCliente(string $cpf): array
    {
        $stmt = $this->db->prepare("
            SELECT p.*,
                   p.id_pedido AS id,
                   p.STATUS AS status
            FROM pedido p
            WHERE p.cliente_cpf = :cpf
            ORDER BY p.data DESC, p.id_pedido DESC
        ");

        $stmt->execute([
            ':cpf' => $cpf
        ]);

        $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $itens = $this->itensDosPedidos(
            array_column($pedidos, 'id')
        );

        foreach ($pedidos as &$pedido) {
            $pedido['itens'] =
                $itens[$pedido['id']] ?? [];
        }

        unset($pedido);

        return $pedidos;
    }

    private function itensDosPedidos(array $ids): array
    {
        if (empty($ids)) {
            return [];
        }

        $marcadores = implode(
            ',',
            array_fill(0, count($ids), '?')
        );

        $stmt = $this->db->prepare("
            SELECT
                ip.id_pedido AS pedido_id,
                ip.preco_unitario,
                ip.subtotal,
                p.id_produto AS produto_id,
                p.nome AS produto_nome,
                p.imagem
            FROM item_pedido ip
            JOIN produto p
                ON p.id_produto = ip.id_produto
            WHERE ip.id_pedido IN ($marcadores)
            ORDER BY ip.id_item_pedido
        ");

        $stmt->execute(
            array_map('intval', array_values($ids))
        );

        $agrupado = [];

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC) as $linha
        ) {
            $linha['quantidade'] = 1;

            $agrupado[$linha['pedido_id']][] = $linha;
        }

        return $agrupado;
    }
}
