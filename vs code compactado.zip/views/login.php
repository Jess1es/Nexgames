
<?php

$erro = $erro ?? '';
$email = $email ?? '';
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Entrar — NexGames</title>

    <link rel="icon"
          type="image/png"
          href="public/assets/img/site.png">

    <link rel="stylesheet"
          href="public/assets/css/loja.css">

    <link rel="stylesheet"
          href="public/assets/css/nex.css">

    <link rel="stylesheet"
          href="public/assets/css/login.css">
</head>

<body class="nx-login">

    <!-- CABEÇALHO -->
    <header class="nx-login-header">

        <div class="nx-login-header-inner">

            <a class="nx-login-logo"
               href="<?= e(url('loja', 'index')) ?>">

                <img
                    src="public/assets/img/logo-nex.jpeg?v=20261116"
                    alt="NEX Gaming Store">

            </a>

            <nav class="nx-login-nav"
                 aria-label="Navegação principal">

                <a href="<?= e(url('loja', 'index')) ?>">
                    Início
                </a>

                <a href="<?= e(url('loja', 'index')) ?>#produtos">
                    Produto
                </a>

                <a href="<?= e(url('loja', 'index')) ?>#categorias">
                    Categorias
                </a>

                <a href="<?= e(url('loja', 'index')) ?>#ofertas">
                    Ofertas
                </a>

            </nav>

            <div class="nx-login-header-actions">

                <form class="nx-login-search"
                      method="get"
                      action="index.php">

                    <input type="hidden"
                           name="controller"
                           value="loja">

                    <input type="hidden"
                           name="action"
                           value="index">

                    <input
                        type="search"
                        name="q"
                        placeholder="Pesquisar jogos"
                        aria-label="Pesquisar jogos">

                    <button type="submit"
                            aria-label="Pesquisar">
                        <icon></icon>⌕
                    </button>

                </form>

                <a class="nx-login-cart"
                   href="<?= e(url('carrinho', 'index')) ?>">
                    <span aria-hidden="true">▣</span>
                    Carrinho
                </a>

                <a class="nx-login-account"
                   href="<?= e(url('auth', 'form')) ?>">
                    <span aria-hidden="true">●</span>
                    Login
                </a>

            </div>

        </div>

    </header>

    <!-- CONTEÚDO -->
    <main class="nx-login-main">

        <section class="nx-login-card">

            <!-- LOGO CENTRAL -->
            <a class="nx-login-card-logo"
               href="<?= e(url('loja', 'index')) ?>">

                <img
                    src="public/assets/img/logo-nex.jpeg?v=20261116"
                    alt="NEX Gaming Store">

            </a>

            <h1>Bem-vindo de volta!</h1>

            <p class="nx-login-subtitle">
                Faça login para continuar sua jornada.
            </p>

            <!-- ERRO DE LOGIN -->
            <?php if ($erro !== ''): ?>

                <div class="nx-login-error"
                     role="alert">

                    <?= e($erro) ?>

                </div>

            <?php endif; ?>

            <!-- FORMULÁRIO -->
            <form
                class="nx-login-form"
                method="post"
                action="<?= e(url('auth', 'login')) ?>"
                novalidate>

                <?= csrfCampo() ?>

                <div class="nx-login-field">

                    <label for="email">
                        E-mail
                    </label>

                    <input
                        id="email"
                        type="email"
                        name="email"
                        value="<?= e($email) ?>"
                        autocomplete="username"
                        maxlength="150"
                        required
                        autofocus>

                </div>

                <div class="nx-login-field">

                    <label for="senha">
                        Senha
                    </label>

                    <input
                        id="senha"
                        type="password"
                        name="senha"
                        autocomplete="current-password"
                        maxlength="72"
                        required>

                </div>

                <button
                    class="nx-login-submit"
                    type="submit">

                    Entre

                </button>

            </form>

            <!-- LINKS -->
            <div class="nx-login-links">

                <p>
                    Ainda não tem conta?
                    <a href="<?= e(url('cliente', 'cadastro')) ?>">
                        Cadastre-se
                    </a>
                </p>

                <a href="<?= e(url('loja', 'index')) ?>">
                    Voltar à loja
                </a>

            </div>

        </section>

    </main>

</body>
</html>
