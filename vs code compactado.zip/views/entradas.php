<?php
/** NexGames — Registro e histórico de entradas de jogos digitais. */

$entradas = isset($entradas) && is_array($entradas) ? $entradas : [];
$fornecedores = isset($fornecedores) && is_array($fornecedores) ? $fornecedores : [];
$produtos = isset($produtos) && is_array($produtos) ? $produtos : [];
$itensPorEntrada = isset($itensPorEntrada) && is_array($itensPorEntrada)
    ? $itensPorEntrada
    : [];

$nomeUser = (string) ($_SESSION['nome'] ?? 'Administrador');
$sucesso = (string) ($_SESSION['sucesso_entrada'] ?? '');
$erro = (string) ($_SESSION['erro_entrada'] ?? '');

unset($_SESSION['sucesso_entrada'], $_SESSION['erro_entrada']);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entradas | NexGames</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            background: #08070c;
            color: #ffffff;
            font-family: Arial, sans-serif;
        }

        a {
            text-decoration: none;
        }

        .nex-header {
            width: 100%;
            background: #08070c;
            padding: 15px 35px;
        }

        .nex-header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            max-width: 1400px;
            margin: auto;
            padding-bottom: 15px;
            border-bottom: 1px solid #6222aa;
        }

        .nex-logo {
            display: block;
            width: 95px;
            max-width: 95px;
            flex-shrink: 0;
        }

        .nex-logo img {
            display: block;
            width: 95px;
            max-width: 95px;
            max-height: 75px;
            height: auto;
            object-fit: contain;
        }

        .admin-area {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #48424e;
            border: 2px solid #8126ef;
            color: #b67bff;
            font-size: 20px;
        }

        .admin-info {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .admin-info strong {
            font-family: Georgia, serif;
            font-size: 15px;
            font-weight: normal;
            color: #ffffff;
        }

        .admin-links {
            display: flex;
            gap: 12px;
        }

        .admin-links a {
            color: #bd8aff;
            font-size: 12px;
        }

        .admin-links a:hover {
            color: #ffffff;
        }

        .nex-container {
            width: 94%;
            max-width: 1120px;
            margin: 65px auto;
        }

        .page-label {
            display: inline-block;
            min-width: 160px;
            padding: 12px 25px;
            margin-bottom: 25px;
            background: #99999c;
            border: 2px solid #8126ef;
            border-radius: 22px;
            color: #161616;
            font-family: Georgia, serif;
            font-size: 16px;
            text-align: center;
        }

        .nex-panel {
            width: 100%;
            padding: 28px;
            background: #121017;
            border: 2px solid #8126ef;
            border-radius: 32px;
        }

        .panel-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 25px;
        }

        .panel-title h1 {
            font-family: Georgia, serif;
            font-size: 29px;
            font-weight: normal;
            margin-bottom: 8px;
        }

        .panel-title p {
            color: #bfbfbf;
            font-size: 13px;
        }

        .total-jogos {
            padding: 10px 18px;
            background: #1b1425;
            border: 1px solid #8126ef;
            border-radius: 20px;
            color: #c49aff;
            font-size: 13px;
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
            background: #08070c;
            border: 2px solid #8126ef;
            border-radius: 24px;
        }

        .nex-table {
            width: 100%;
            border-collapse: collapse;
            color: #ffffff;
            font-size: 14px;
        }

        .nex-table thead {
            background: #100d16;
        }

        .nex-table th {
            padding: 19px 16px;
            color: #ffffff;
            font-weight: 600;
            text-align: left;
            border-bottom: 2px solid #8126ef;
        }

        .nex-table td {
            padding: 20px 16px;
            color: #eeeeee;
            border-bottom: 1px solid #52217f;
            vertical-align: middle;
        }

        .nex-table tbody tr:last-child td {
            border-bottom: none;
        }

        .nex-table tbody tr:hover {
            background: #1d132b;
        }

        .col-id {
            color: #c69aff !important;
            font-weight: bold;
            white-space: nowrap;
        }

        .col-nome {
            font-weight: 600;
        }

        .col-preco {
            white-space: nowrap;
            font-weight: 600;
        }

        .status {
            display: inline-block;
            padding: 8px 15px;
            border-radius: 12px;
            color: #ffffff;
            font-size: 12px;
            font-weight: 600;
        }

        .status-ativo {
            background: #32884b;
        }

        .status-inativo {
            background: #686868;
        }

        .empty-message {
            text-align: center;
            padding: 40px 15px !important;
            color: #cccccc;
        }

        .nex-form {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 28px;
        }

        .nex-field {
            display: flex;
            flex-direction: column;
            gap: 8px;
            font-size: 13px;
            color: #ddd;
        }

        .nex-field select,
        .nex-field input {
            width: 100%;
            min-width: 0;
            padding: 12px;
            color: #fff;
            background: #08070c;
            border: 1px solid #8126ef;
            border-radius: 12px;
        }

        .nex-field option {
            background: #121017;
        }

        .nex-form .full {
            grid-column: 1 / -1;
        }

        .nex-item-row {
            display: grid;
            grid-template-columns: 3fr 1fr 1.5fr auto;
            gap: 12px;
            align-items: end;
            margin: 12px 0;
        }

        .nex-btn {
            cursor: pointer;
            padding: 12px 17px;
            border-radius: 12px;
            background: #8126ef;
            border: 1px solid #a875ff;
            color: white;
            font-weight: 600;
        }

        .nex-btn.secondary {
            background: #241632;
        }

        .nex-btn.danger {
            background: #592b42;
        }

        .nex-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .nex-section-title {
            font-size: 21px;
            font-family: Georgia, serif;
            font-weight: normal;
            margin: 0 0 20px;
        }

        .nex-alert {
            padding: 14px 18px;
            margin-bottom: 20px;
            border-radius: 12px;
            background: #23172f;
            border: 1px solid #8126ef;
        }

        .nex-alert.error {
            border-color: #d66;
        }

        .nex-summary {
            color: #c49aff;
            font-size: 14px;
        }

        .nex-details {
            margin-top: 12px;
        }

        .nex-details summary {
            cursor: pointer;
            color: #c49aff;
        }

        .nex-details ul {
            margin: 10px 0 0 20px;
            line-height: 1.8;
        }

        .nex-divider {
            border: 0;
            border-top: 1px solid #52217f;
            margin: 30px 0;
        }

        @media (max-width: 800px) {
            .nex-container {
                margin: 40px auto;
            }

            .nex-table {
                min-width: 680px;
            }

            .nex-panel {
                padding: 20px;
            }

            .nex-form {
                grid-template-columns: 1fr;
            }

            .nex-item-row {
                grid-template-columns: 1fr 1fr;
            }

            .nex-item-row .jogo {
                grid-column: 1 / -1;
            }
        }

        @media (max-width: 500px) {
            .nex-header {
                padding: 12px 15px;
            }

            .nex-logo,
            .nex-logo img {
                width: 80px;
                max-width: 80px;
            }

            .admin-info strong {
                font-size: 13px;
            }

            .admin-links {
                gap: 8px;
            }

            .nex-container {
                margin: 30px auto;
            }

            .nex-panel {
                padding: 15px;
                border-radius: 24px;
            }

            .panel-title h1 {
                font-size: 24px;
            }

            .table-container {
                border-radius: 18px;
            }

            .nex-item-row {
                grid-template-columns: 1fr;
            }

            .nex-item-row .jogo {
                grid-column: auto;
            }
        }
    </style>
</head>

<body>

<header class="nex-header">
    <div class="nex-header-content">
        <a class="nex-logo"
           href="<?= e(url('auth', 'dashboard')) ?>">
            <img
                src="public/assets/img/logo-nex.jpeg?v=20261116"
                alt="NexGames"
                width="95"
                height="70"
            >
        </a>

        <div class="admin-area">
            <div class="admin-avatar" aria-hidden="true">●</div>

            <div class="admin-info">
                <strong><?= e($nomeUser) ?></strong>

                <div class="admin-links">
                    <a href="<?= e(url('auth', 'dashboard')) ?>">
                        Dashboard
                    </a>

                    <a href="<?= e(url('auth', 'logout')) ?>">
                        Sair
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<main class="nex-container">
    <div class="page-label">Entradas</div>

    <section class="nex-panel">
        <div class="panel-top">
            <div class="panel-title">
                <h1>Entradas de jogos</h1>
                <p>
                    Registre jogos digitais recebidos de fornecedores
                    e consulte o histórico.
                </p>
            </div>

            <div class="total-jogos">
                Total: <?= count($entradas) ?> entradas
            </div>
        </div>

        <?php if ($sucesso !== ''): ?>
            <div class="nex-alert" role="status">
                <?= e($sucesso) ?>
            </div>
        <?php endif; ?>

        <?php if ($erro !== ''): ?>
            <div class="nex-alert error" role="alert">
                <?= e($erro) ?>
            </div>
        <?php endif; ?>

        <h2 class="nex-section-title">Cadastrar entrada</h2>

        <?php if (!$fornecedores || !$produtos): ?>
            <p class="nex-alert error">
                Cadastre pelo menos um fornecedor ativo
                e um jogo ativo antes de registrar entradas.
            </p>
        <?php endif; ?>

        <form
            method="post"
            action="<?= e(url('entrada', 'salvar')) ?>"
            id="form-entrada"
        >
            <?= csrfCampo() ?>

            <div class="nex-form">
                <label class="nex-field">
                    Fornecedor

                    <select name="fornecedor_id" required>
                        <option value="">
                            Selecione o fornecedor
                        </option>

                        <?php foreach ($fornecedores as $fornecedor): ?>
                            <option
                                value="<?= (int) $fornecedor['id_fornecedor'] ?>"
                            >
                                <?= e((string) $fornecedor['nome']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="nex-field">
                    Status

                    <select name="status" required>
                        <option value="confirmada">
                            Confirmada
                        </option>
                        <option value="rascunho">
                            Rascunho
                        </option>
                    </select>
                </label>

                <div class="nex-field">
                    Total calculado

                    <div class="nex-summary" id="total-entrada">
                        R$ 0,00
                    </div>
                </div>

                <div class="full">
                    <h3 class="nex-section-title">
                        Jogos desta entrada
                    </h3>

                    <div id="lista-itens"></div>

                    <div class="nex-actions">
                        <button
                            type="button"
                            class="nex-btn secondary"
                            id="adicionar-jogo"
                        >
                            + Adicionar jogo
                        </button>

                        <button
                            type="submit"
                            class="nex-btn"
                            <?= (!$fornecedores || !$produtos) ? 'disabled' : '' ?>
                        >
                            Salvar entrada
                        </button>
                    </div>
                </div>
            </div>
        </form>

        <template id="modelo-item">
            <div class="nex-item-row">
                <label class="nex-field jogo">
                    Jogo

                    <select name="id_produto[]" required>
                        <option value="">
                            Selecione um jogo
                        </option>

                        <?php foreach ($produtos as $produto): ?>
                            <option
                                value="<?= (int) $produto['id_produto'] ?>"
                            >
                                <?= e((string) $produto['nome']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="nex-field">
                    Quantidade de licenças

                    <input
                        type="number"
                        name="quantidade[]"
                        min="1"
                        max="100000"
                        value="1"
                        required
                    >
                </label>

                <label class="nex-field">
                    Valor unitário (R$)

                    <input
                        type="text"
                        name="valor_unitario[]"
                        inputmode="decimal"
                        placeholder="Ex.: 19,90"
                        pattern="[0-9]{1,7}([.,][0-9]{1,2})?"
                        required
                    >
                </label>

                <button
                    type="button"
                    class="nex-btn danger remover-jogo"
                    aria-label="Remover jogo"
                >
                    Remover
                </button>
            </div>
        </template>

        <hr class="nex-divider">

        <h2 class="nex-section-title">
            Histórico de entradas
        </h2>

        <div class="table-container">
            <table class="nex-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Fornecedor</th>
                        <th>Data</th>
                        <th>Jogos</th>
                        <th>Valor</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!$entradas): ?>
                        <tr>
                            <td colspan="6" class="empty-message">
                                Nenhuma entrada registrada.
                            </td>
                        </tr>
                    <?php else: ?>

                        <?php foreach ($entradas as $entrada): ?>
                            <?php
                            $idEntrada = (int) $entrada['id'];
                            ?>

                            <tr>
                                <td class="col-id">
                                    #<?= $idEntrada ?>
                                </td>

                                <td class="col-nome">
                                    <?= e((string) $entrada['fornecedor_nome']) ?>
                                </td>

                                <td>
                                    <?= e(date(
                                        'd/m/Y',
                                        strtotime((string) $entrada['data'])
                                    )) ?>
                                </td>

                                <td>
                                    <?= (int) $entrada['total_jogos'] ?> tipo(s)

                                    <?php if (!empty($itensPorEntrada[$idEntrada])): ?>
                                        <details class="nex-details">
                                            <summary>Ver jogos</summary>

                                            <ul>
                                                <?php foreach ($itensPorEntrada[$idEntrada] as $item): ?>
                                                    <li>
                                                        <?= e((string) $item['jogo_nome']) ?>
                                                        —
                                                        <?= (int) $item['quantidade'] ?>
                                                        licença(s) ×
                                                        R$
                                                        <?= number_format(
                                                            (float) $item['valor_unitario'],
                                                            2,
                                                            ',',
                                                            '.'
                                                        ) ?>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </details>
                                    <?php endif; ?>
                                </td>

                                <td class="col-preco">
                                    R$
                                    <?= number_format(
                                        (float) $entrada['valor_total'],
                                        2,
                                        ',',
                                        '.'
                                    ) ?>
                                </td>

                                <td>
                                    <span class="status <?= $entrada['status'] === 'confirmada' ? 'status-ativo' : 'status-inativo' ?>">
                                        <?= $entrada['status'] === 'confirmada' ? 'Confirmada' : 'Rascunho' ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<script>
(() => {
    const lista = document.getElementById('lista-itens');
    const modelo = document.getElementById('modelo-item');
    const total = document.getElementById('total-entrada');

    const formatar = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });

    function atualizar() {
        let soma = 0;

        lista.querySelectorAll('.nex-item-row').forEach(linha => {
            const qtd = Number(
                linha.querySelector('[name="quantidade[]"]').value
            ) || 0;

            const valor = Number(
                linha.querySelector('[name="valor_unitario[]"]')
                    .value.replace(',', '.')
            ) || 0;

            soma += qtd * valor;
        });

        total.textContent = formatar.format(soma);
    }

    function adicionar() {
        if (lista.children.length >= 100) {
            return;
        }

        lista.appendChild(
            modelo.content.cloneNode(true)
        );

        atualizar();
    }

    document.getElementById('adicionar-jogo')
        .addEventListener('click', adicionar);

    lista.addEventListener('input', atualizar);
    lista.addEventListener('change', atualizar);

    lista.addEventListener('click', e => {
        if (e.target.closest('.remover-jogo')) {
            if (lista.children.length > 1) {
                e.target.closest('.nex-item-row').remove();
            }

            atualizar();
        }
    });

    document.getElementById('form-entrada')
        .addEventListener('submit', e => {
            const ids = [
                ...lista.querySelectorAll('[name="id_produto[]"]')
            ].map(el => el.value);

            if (new Set(ids).size !== ids.length) {
                e.preventDefault();

                alert(
                    'Não selecione o mesmo jogo mais de uma vez ' +
                    'na mesma entrada.'
                );
            }
        });

    adicionar();
})();
</script>

</body>
</html>