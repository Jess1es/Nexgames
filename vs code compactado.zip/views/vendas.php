
<?php

$nomeUser = $_SESSION['nome'] ?? 'Administrador';
$vendas = $vendas ?? [];

/* Status dos pedidos */
$statusMap = [
    'pago' => ['Pago', 'st-pago'],
    'aguardando_pagamento' => ['Pendente', 'st-pendente'],
    'cancelado' => ['Cancelado', 'st-cancelado'],
];

/* Formas de pagamento */
$formaMap = [
    'cartao' => 'Cartão',
    'pix' => 'Pix',
    'boleto' => 'Boleto',
    'outro' => 'Outro',
];
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Vendas / Pedidos — NexGames</title>

    <link rel="icon"
          type="image/png"
          href="public/assets/img/dashboard.png">

    <link rel="stylesheet"
          href="public/assets/css/style.css">

    <link rel="stylesheet"
          href="public/assets/css/nex.css">

    <link rel="stylesheet"
          href="public/assets/css/vendas.css">
</head>

<body class="nx-vendas">

    <!-- CABEÇALHO -->
    <header class="nx-vendas-header">

        <div class="nx-vendas-header-inner">

            <!-- LOGO -->
            <a
                class="nx-vendas-logo"
                href="<?= e(url('auth', 'dashboard')) ?>"
                title="Voltar ao Dashboard">

                <img
                    src="public/assets/img/logo-nex.jpeg?v=20261116"
                    alt="NEX Gaming Store">

            </a>

            <!-- ADMINISTRADOR -->
            <div class="nx-vendas-admin">

                <div class="nx-vendas-avatar"
                     aria-hidden="true">
                    ●
                </div>

                <div class="nx-vendas-admin-info">

                    <strong>
                        <?= e($nomeUser) ?>
                    </strong>

                    <a href="<?= e(url('auth', 'dashboard')) ?>">
                        Dashboard
                    </a>

                    <a href="<?= e(url('auth', 'logout')) ?>">
                        Sair
                    </a>

                </div>

            </div>

        </div>

    </header>

    <!-- CONTEÚDO -->
    <main class="nx-vendas-container">

        <!-- MENSAGENS DE ERRO -->
        <?php if (isset($_SESSION['erro'])): ?>

            <div class="nx-vendas-alert nx-vendas-alert-erro"
                 role="alert">

                <?= e($_SESSION['erro']) ?>

            </div>

            <?php unset($_SESSION['erro']); ?>

        <?php endif; ?>

        <!-- MENSAGENS DE SUCESSO -->
        <?php if (isset($_SESSION['sucesso'])): ?>

            <div class="nx-vendas-alert nx-vendas-alert-sucesso"
                 role="status">

                <?= e($_SESSION['sucesso']) ?>

            </div>

            <?php unset($_SESSION['sucesso']); ?>

        <?php endif; ?>

        <!-- TÍTULO -->
        <div class="nx-vendas-pagebar">

            <h1 class="nx-vendas-chip">
                Vendas/Pedidos
            </h1>

        </div>

        <!-- TABELA DE PEDIDOS -->
        <section class="nx-vendas-card">

            <div class="nx-vendas-table-scroll">

                <table class="nx-vendas-table">

                    <thead>
                        <tr>

                            <th scope="col">
                                Nº do pedido
                            </th>

                            <th scope="col">
                                Cliente
                            </th>

                            <th scope="col">
                                Data
                            </th>

                            <th scope="col">
                                Valor
                            </th>

                            <th scope="col">
                                Pagamento
                            </th>

                            <th scope="col"
                                class="nx-vendas-col-status">
                                Status
                            </th>

                            <th scope="col">
                                Nota fiscal
                            </th>

                        </tr>
                    </thead>

                    <tbody>

                        <?php if (empty($vendas)): ?>

                            <tr>

                                <td colspan="7"
                                    class="nx-vendas-empty">

                                    Nenhum pedido registrado ainda.

                                </td>

                            </tr>

                        <?php else: ?>

                            <?php foreach ($vendas as $v): ?>

                                <?php
                                $idPedido = (int) (
                                    $v['id_pedido'] ?? $v['id'] ?? 0
                                );

                                $statusBanco = $v['status']
                                    ?? $v['STATUS']
                                    ?? 'aguardando_pagamento';

                                [$statusTexto, $statusClasse] =
                                    $statusMap[$statusBanco]
                                    ?? [
                                        ucfirst((string) $statusBanco),
                                        'st-pendente'
                                    ];

                                $forma = $v['forma_pagamento'] ?? null;

                                $formaTexto = $forma
                                    ? ($formaMap[$forma]
                                        ?? ucfirst((string) $forma))
                                    : '—';

                                $dataPedido = $v['data']
                                    ?? $v['data_pedido']
                                    ?? null;

                                $dataFormatada = $dataPedido
                                    ? date(
                                        'd/m/Y',
                                        strtotime($dataPedido)
                                    )
                                    : '—';

                                $temNota = !empty($v['tem_nota']);
                                ?>

                                <tr>

                                    <!-- NÚMERO DO PEDIDO -->
                                    <td class="nx-vendas-num">

                                        #<?= $idPedido ?>

                                    </td>

                                    <!-- CLIENTE -->
                                    <td>

                                        <?= e(
                                            $v['cliente_nome'] ?? '—'
                                        ) ?>

                                    </td>

                                    <!-- DATA -->
                                    <td class="nx-vendas-num">

                                        <?= e($dataFormatada) ?>

                                    </td>

                                    <!-- VALOR -->
                                    <td class="nx-vendas-num">

                                        <strong>

                                            R$
                                            <?= number_format(
                                                (float) ($v['valor_total'] ?? 0),
                                                2,
                                                ',',
                                                '.'
                                            ) ?>

                                        </strong>

                                    </td>

                                    <!-- PAGAMENTO -->
                                    <td>

                                        <?= e($formaTexto) ?>

                                    </td>

                                    <!-- STATUS -->
                                    <td class="nx-vendas-col-status">

                                        <span class="nx-vendas-selo <?= e($statusClasse) ?>">

                                            <?= e($statusTexto) ?>

                                        </span>

                                    </td>

                                    <!-- NOTA FISCAL -->
                                    <td>

                                        <?php if ($temNota): ?>

                                            <!-- Nota já emitida -->
                                            <a
                                                class="nx-vendas-btn"
                                                href="<?= e(url(
                                                    'venda',
                                                    'verNota',
                                                    ['id_pedido' => $idPedido]
                                                )) ?>">

                                                Ver nota

                                            </a>

                                        <?php elseif ($statusBanco === 'pago'): ?>

                                            <!-- Pedido pago, sem nota -->
                                            <form
                                                method="POST"
                                                action="<?= e(url(
                                                    'venda',
                                                    'emitirNota'
                                                )) ?>">

                                                <input
                                                    type="hidden"
                                                    name="id_pedido"
                                                    value="<?= $idPedido ?>">

                                                <?php if (function_exists('csrfCampo')): ?>

                                                    <?= csrfCampo() ?>

                                                <?php else: ?>

                                                    <input
                                                        type="hidden"
                                                        name="csrf_token"
                                                        value="<?= e(
                                                            $_SESSION['csrf_token'] ?? ''
                                                        ) ?>">

                                                <?php endif; ?>

                                                <button
                                                    type="submit"
                                                    class="nx-vendas-btn">

                                                    Emitir NF

                                                </button>

                                            </form>

                                        <?php else: ?>

                                            <span class="nx-vendas-indisponivel">

                                                Indisponível

                                            </span>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</body>
</html>
