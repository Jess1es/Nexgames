
<?php
$clientes = $clientes ?? [];
$nomeUser = $_SESSION['nome'] ?? 'Administrador';
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Clientes — NexGames</title>

    <link rel="stylesheet"
          href="public/assets/css/style.css">

    <link rel="stylesheet"
          href="public/assets/css/nex.css">

    <link rel="stylesheet"
          href="public/assets/css/clientes.css">
</head>

<body class="nx-clientes">

    <!-- CABEÇALHO -->
    <header class="nx-clientes-header">

        <div class="nx-clientes-header-inner">

            <!-- LOGO NEX -->
            <a
                class="nx-clientes-logo"
                href="<?= e(url('auth', 'dashboard')) ?>">

                <img
                    src="public/assets/img/logo-nex.jpeg?v=20261116"
                    alt="NEX Gaming Store">

            </a>

            <!-- ADMINISTRADOR -->
            <div class="nx-clientes-admin">

                <div class="nx-clientes-avatar"
                     aria-hidden="true">
                    ●
                </div>

                <div class="nx-clientes-admin-info">

                    <strong>
                        <?= e($nomeUser) ?>
                    </strong>

                    <a href="<?= e(url('auth', 'dashboard')) ?>">
                        Dashboard
                    </a>

                    <a href="<?= e(url('auth', 'logout')) ?>">
                        Sair
                    </a>

                </div>

            </div>

        </div>

    </header>

    <!-- CONTEÚDO -->
    <main class="nx-clientes-container">

        <div class="nx-clientes-pagebar">

            <span class="nx-clientes-chip">
                Cliente
            </span>

        </div>

        <!-- TABELA -->
        <section class="nx-clientes-table-wrapper">

            <div class="nx-clientes-table-scroll">

                <table class="nx-clientes-table">

                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>CPF</th>
                            <th>Telefone</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (empty($clientes)): ?>

                            <tr>
                                <td colspan="4"
                                    class="nx-clientes-empty">
                                    Nenhum cliente cadastrado.
                                </td>
                            </tr>

                        <?php else: ?>

                            <?php foreach ($clientes as $cliente): ?>

                                <tr>

                                    <td>
                                        <?= e($cliente['nome'] ?? '-') ?>
                                    </td>

                                    <td>
                                        <?= e($cliente['email'] ?? '-') ?>
                                    </td>

                                    <td>
                                        <?= e($cliente['cpf'] ?? '-') ?>
                                    </td>

                                    <td>
                                        <?= e($cliente['telefone'] ?: '-') ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</body>
</html>
