
<?php

$old = ($old ?? []) + [
    'nome' => '',
    'email' => '',
    'cpf' => '',
    'telefone' => ''
];

$erros = $erros ?? [];

$erroCampo = fn(string $c) => isset($erros[$c])
    ? '<span class="campo__erro" id="erro-' . $c . '">'
        . e($erros[$c]) . '</span>'
    : '';

$descrito = fn(string $c) => isset($erros[$c])
    ? ' aria-invalid="true" aria-describedby="erro-' . $c . '"'
    : '';
?>

<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">

    <title>Criar conta — NEX Games</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" type="image/png" href="public/assets/img/site.png">

    <link rel="stylesheet" href="public/assets/css/loja.css">
    <link rel="stylesheet" href="public/assets/css/nex.css">
</head>

<body class="auth">

<main class="auth__caixa">

    <a class="marca marca--grande"
       href="<?= e(url('loja', 'index')) ?>"
       aria-label="NEX Gaming Store — página inicial">

        <span class="marca__logo">NE<b>X</b></span>
        <span class="marca__sub">Gaming Store</span>

    </a>

    <section class="formulario">

        <h1>Criar conta</h1>

        <p class="formulario__intro">
            Com a conta você compra seus jogos e baixa tudo em “Meus jogos”.
        </p>

        <?php if (isset($erros['geral'])): ?>

            <div class="aviso aviso--erro" role="alert">
                <?= e($erros['geral']) ?>
            </div>

        <?php endif; ?>

        <form action="<?= e(url('cliente', 'cadastro')) ?>"
              method="post"
              novalidate>

            <?= csrfCampo() ?>

            <!-- NOME COMPLETO -->

            <div class="campo">

                <label for="nome">Nome completo</label>

                <input
                    id="nome"
                    type="text"
                    name="nome"
                    value="<?= e($old['nome']) ?>"
                    maxlength="150"
                    autocomplete="name"
                    required<?= $descrito('nome') ?>
                >

                <?= $erroCampo('nome') ?>

            </div>

            <!-- E-MAIL -->

            <div class="campo">

                <label for="email">E-mail</label>

                <input
                    id="email"
                    type="email"
                    name="email"
                    value="<?= e($old['email']) ?>"
                    maxlength="150"
                    autocomplete="email"
                    required<?= $descrito('email') ?>
                >

                <?= $erroCampo('email') ?>

            </div>

            <!-- CPF -->

            <div class="campo">

                <label for="cpf">CPF</label>

                <input
                    id="cpf"
                    type="text"
                    name="cpf"
                    value="<?= e(formatarCpf($old['cpf'])) ?>"
                    inputmode="numeric"
                    maxlength="14"
                    placeholder="000.000.000-00"
                    data-mascara="cpf"
                    required<?= $descrito('cpf') ?>
                >

                <?= $erroCampo('cpf') ?>

            </div>

            <!-- TELEFONE -->

            <div class="campo">

                <label for="telefone">
                    Telefone
                    <span class="campo__opcional">(opcional)</span>
                </label>

                <input
                    id="telefone"
                    type="text"
                    name="telefone"
                    value="<?= e(formatarTelefone($old['telefone'])) ?>"
                    inputmode="tel"
                    maxlength="15"
                    placeholder="(21) 99999-9999"
                    data-mascara="telefone"
                    autocomplete="tel"<?= $descrito('telefone') ?>
                >

                <?= $erroCampo('telefone') ?>

            </div>

            <!-- SENHA -->

            <div class="campo">

                <label for="senha">Senha</label>

                <input
                    id="senha"
                    type="password"
                    name="senha"
                    minlength="8"
                    maxlength="72"
                    autocomplete="new-password"
                    required<?= $descrito('senha') ?>
                >

                <span class="campo__ajuda">
                    Mínimo de 8 caracteres.
                </span>

                <?= $erroCampo('senha') ?>

            </div>

            <!-- CONFIRMAR SENHA -->

            <div class="campo">

                <label for="senha_confirmacao">
                    Confirmar senha
                </label>

                <input
                    id="senha_confirmacao"
                    type="password"
                    name="senha_confirmacao"
                    maxlength="72"
                    autocomplete="new-password"
                    required<?= $descrito('senha_confirmacao') ?>
                >

                <?= $erroCampo('senha_confirmacao') ?>

            </div>

            <!-- BOTÃO CADASTRAR -->

            <button
                type="submit"
                class="botao botao--primario botao--cheio"
            >
                Criar conta
            </button>

        </form>

        <!-- LINK PARA LOGIN -->

        <p class="formulario__rodape">
            Já tem conta?
            <a href="<?= e(url('auth', 'form')) ?>">
                Entrar
            </a>
        </p>

    </section>

</main>

<script src="public/assets/js/loja.js"></script>

</body>
</html>
