
<?php

if (empty($nota) || empty($venda)) {
    http_response_code(404);
    exit('Nota fiscal ou pedido não encontrado.');
}

$pagamento = $venda['pagamento'] ?? null;
$pagamento = is_array($pagamento) ? $pagamento : [];

$numeroNota = (string) ($nota['numero'] ?? '');
$serieNota = (string) ($nota['serie'] ?? '1');
$idPedido = (int) ($venda['id_pedido'] ?? $venda['id'] ?? 0);

$dataEmissao = $nota['data_emissao'] ?? null;
$timestampEmissao = $dataEmissao
    ? strtotime($dataEmissao)
    : false;

$dataEmissaoFormatada = $timestampEmissao
    ? date('d/m/Y', $timestampEmissao)
    : '—';

$dataVenda = $pagamento['data_pagamento']
    ?? $venda['data']
    ?? null;

$timestampVenda = $dataVenda
    ? strtotime($dataVenda)
    : false;

$dataVendaFormatada = $timestampVenda
    ? date('d/m/Y', $timestampVenda)
    : '—';

$horaVendaFormatada = $timestampVenda
    ? date('H:i:s', $timestampVenda)
    : '—';

$clienteNome = $venda['cliente_nome'] ?? '—';
$clienteEmail = $venda['cliente_email'] ?? '—';

$clienteCpf = preg_replace(
    '/\D+/',
    '',
    (string) ($venda['cliente_cpf'] ?? '')
);

$cpfFormatado = strlen($clienteCpf) === 11
    ? substr($clienteCpf, 0, 3) . '.'
        . substr($clienteCpf, 3, 3) . '.'
        . substr($clienteCpf, 6, 3) . '-'
        . substr($clienteCpf, 9, 2)
    : $clienteCpf;

$formasPagamento = [
    'cartao' => 'Cartão',
    'pix' => 'PIX',
    'boleto' => 'Boleto',
    'outro' => 'Outro'
];

$statusPagamento = [
    'aprovado' => 'Aprovado',
    'pendente' => 'Pendente',
    'cancelado' => 'Cancelado'
];

$forma = $pagamento['forma_pagamento']
    ?? $venda['forma_pagamento']
    ?? '';

$status = $pagamento['status'] ?? '';

$formaFormatada = $formasPagamento[$forma]
    ?? 'Não informada';

$statusFormatado = $statusPagamento[$status]
    ?? 'Não informado';

$valorTotalNota = (float) (
    $nota['valor_total']
    ?? $venda['valor_total']
    ?? 0
);

$itens = $venda['itens'] ?? [];
$itens = is_array($itens) ? $itens : [];

$esc = static function ($valor): string {
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES,
        'UTF-8'
    );
};

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Nota Fiscal Fictícia Nº <?= $esc($numeroNota) ?> — NexGames
    </title>

    <link rel="stylesheet"
          href="public/assets/css/nota.css">

    <link rel="icon"
          type="image/png"
          href="public/assets/img/dashboard.png">
</head>

<body>

<div class="nf-container">

    <header class="nf-cabecalho">

        <div class="nf-emitente">
            <h1 class="nf-emitente-nome">
                NEX GAMES
            </h1>

            <p class="nf-emitente-endereco">
                Onde sua próxima aventura começa.
            </p>
        </div>

        <div class="nf-documento-info">
            <h2 class="nf-documento-titulo">
                NOTA FISCAL
            </h2>

            <div class="nf-documento-dados">

                <p class="nf-dado-linha">
                    <strong>NÚMERO:</strong>
                    <?= $esc($numeroNota) ?>
                </p>

                <p class="nf-dado-linha">
                    <strong>SÉRIE:</strong>
                    <?= $esc($serieNota) ?>
                </p>

                <p class="nf-dado-linha">
                    <strong>EMISSÃO:</strong>
                    <?= $esc($dataEmissaoFormatada) ?>
                </p>

            </div>
        </div>
    </header>

    <section class="nf-emissao">

        <div class="nf-emissao-bloco">
            <span class="nf-emissao-label">
                DATA DA VENDA
            </span>
            <span class="nf-emissao-valor">
                <?= $esc($dataVendaFormatada) ?>
            </span>
        </div>

        <div class="nf-emissao-bloco">
            <span class="nf-emissao-label">
                HORA DA VENDA
            </span>
            <span class="nf-emissao-valor">
                <?= $esc($horaVendaFormatada) ?>
            </span>
        </div>

        <div class="nf-emissao-bloco">
            <span class="nf-emissao-label">
                REFERÊNCIA PEDIDO
            </span>
            <span class="nf-emissao-valor">
                #<?= $idPedido ?>
            </span>
        </div>

    </section>

    <section class="nf-emissao">

        <div class="nf-emissao-bloco">
            <span class="nf-emissao-label">
                CLIENTE
            </span>

            <span class="nf-emissao-valor">
                <?= $esc($clienteNome) ?>
            </span>

            <span class="nf-emissao-valor">
                CPF: <?= $esc($cpfFormatado) ?>
            </span>

            <span class="nf-emissao-valor">
                <?= $esc($clienteEmail) ?>
            </span>
        </div>

        <div class="nf-emissao-bloco">
            <span class="nf-emissao-label">
                FORMA DE PAGAMENTO
            </span>

            <span class="nf-emissao-valor">
                <?= $esc($formaFormatada) ?>
            </span>
        </div>

        <div class="nf-emissao-bloco">
            <span class="nf-emissao-label">
                STATUS DO PAGAMENTO
            </span>

            <span class="nf-emissao-valor">
                <?= $esc($statusFormatado) ?>
            </span>
        </div>

    </section>

    <main class="nf-conteudo">

        <table class="nf-tabela-produtos">

            <thead>
                <tr>
                    <th class="nf-th-codigo">
                        CÓDIGO
                    </th>
                    <th class="nf-th-descricao">
                        DESCRIÇÃO DO PRODUTO
                    </th>
                    <th class="nf-th-qtd">
                        QTD
                    </th>
                    <th class="nf-th-valor-uni">
                        V. UNITÁRIO
                    </th>
                    <th class="nf-th-valor-tot">
                        V. TOTAL
                    </th>
                </tr>
            </thead>

            <tbody>

            <?php if (!empty($itens)): ?>

                <?php foreach ($itens as $item): ?>

                    <?php
                    $produtoId = (int) (
                        $item['id_produto']
                        ?? $item['produto_id']
                        ?? 0
                    );

                    $produtoNome = $item['produto_nome']
                        ?? $item['nome']
                        ?? 'Jogo não identificado';

                    $precoUnitario = (float) (
                        $item['preco_unitario'] ?? 0
                    );

                    $subtotal = (float) (
                        $item['subtotal']
                        ?? $precoUnitario
                    );
                    ?>

                    <tr>

                        <td class="nf-td-codigo">
                            #<?= $produtoId ?>
                        </td>

                        <td class="nf-td-descricao">
                            <?= $esc($produtoNome) ?>
                        </td>

                        <td class="nf-td-qtd">
                            1
                        </td>

                        <td class="nf-td-valor-uni">
                            R$ <?= number_format(
                                $precoUnitario,
                                2,
                                ',',
                                '.'
                            ) ?>
                        </td>

                        <td class="nf-td-valor-tot">
                            R$ <?= number_format(
                                $subtotal,
                                2,
                                ',',
                                '.'
                            ) ?>
                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="5" class="nf-td-descricao">
                        Nenhum jogo encontrado neste pedido.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>
        </table>

    </main>

    <footer class="nf-rodape">

        <div class="nf-total-bloco">

            <span class="nf-total-label">
                VALOR TOTAL DA NOTA
            </span>

            <span class="nf-total-valor">
                R$ <?= number_format(
                    $valorTotalNota,
                    2,
                    ',',
                    '.'
                ) ?>
            </span>

        </div>

    </footer>

    <div class="nf-botoes no-print">

        <button
            type="button"
            class="nf-btn-imprimir"
            onclick="window.print()">
            Imprimir Nota Fiscal
        </button>

        <a
            href="index.php?controller=pedido&amp;action=meusPedidos"
            class="nf-btn-voltar">
            Voltar aos pedidos
        </a>

    </div>

</div>

</body>
</html>
