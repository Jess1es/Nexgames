
<?php

$titulo = $titulo ?? 'NexGames';

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$qtdCarrinho = (int) ($qtdCarrinho ?? 0);

$flashes = isset($flashes) && is_array($flashes)
    ? $flashes
    : [];

$buscaAtual = (string) ($buscaAtual ?? '');
$categoriaAtual = (int) ($categoriaAtual ?? 0);

$clienteLogado = !empty($_SESSION['cliente_id']);
$clienteNome = $_SESSION['cliente_nome'] ?? null;

$ehAdmin = (
    !empty($_SESSION['usuario_id']) &&
    ($_SESSION['perfil'] ?? '') === 'admin'
);

$controllerAtual = (string) ($_GET['controller'] ?? 'loja');
$actionAtual = (string) ($_GET['action'] ?? 'index');

$paginaInicial = (
    $controllerAtual === 'loja' &&
    $actionAtual === 'index' &&
    $buscaAtual === '' &&
    $categoriaAtual === 0
);

$paginaCatalogo = (
    $controllerAtual === 'loja' &&
    $actionAtual === 'catalogo'
);

$paginaOfertas = (
    $controllerAtual === 'loja' &&
    $actionAtual === 'ofertas'
);

$paginaCarrinho = $controllerAtual === 'carrinho';

$view = $view ?? '';
$carregarHomeCss = $view === 'home';

$tituloPagina = $titulo === 'NexGames'
    ? 'NexGames'
    : $titulo . ' — NexGames';
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title><?= e($tituloPagina) ?></title>

    <link
        rel="icon"
        type="image/png"
        href="/nex/public/assets/img/favicon-nex.png"
    >

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&family=Roboto+Mono:wght@400;500;700&display=swap"
    >

    <?php if (!$carregarHomeCss): ?>

        <link
            rel="stylesheet"
            href="/nex/public/assets/css/loja.css?v=4"
        >

    <?php endif; ?>

    <link
        rel="stylesheet"
        href="/nex/public/assets/css/nex-base.css?v=4"
    >

    <?php if ($carregarHomeCss): ?>

        <link
            rel="stylesheet"
            href="/nex/public/assets/css/home.css?v=4"
        >

    <?php endif; ?>

    <style>
        .nx-pular {
            position: fixed;
            top: -100px;
            left: 10px;
            z-index: 99999;
            padding: 10px 15px;
            background: #7027bd;
            color: #ffffff;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 13px;
        }

        .nx-pular:focus {
            top: 10px;
        }

        .nx-sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            clip-path: inset(50%);
            white-space: nowrap;
            border: 0;
        }

        .nx-marca img {
            display: block;
            width: 85px;
            max-width: 100%;
            height: auto;
            object-fit: contain;
        }
    </style>
</head>

<body class="<?= $carregarHomeCss ? 'nx-site' : '' ?>">

    <a class="nx-pular" href="#conteudo">
        Ir para o conteúdo
    </a>

    <header class="nx-topo">

        <div class="nx-topo__interno">

            <!-- Logo -->

            <a
                class="nx-marca"
                href="<?= e(url('loja', 'index')) ?>"
                aria-label="NexGames — Página inicial"
            >
                <img
                    src="/nex/public/assets/img/logo-nex.jpeg"
                    alt="NEX Gaming Store"
                    width="85"
                >
            </a>

            <!-- Menu principal -->

            <nav
                class="nx-nav"
                aria-label="Menu principal"
            >

                <a
                    class="nx-nav__link<?= $paginaInicial ? ' ativo' : '' ?>"
                    href="<?= e(url('loja', 'index')) ?>"
                    <?= $paginaInicial ? 'aria-current="page"' : '' ?>
                >
                    Início
                </a>

                <a
                    class="nx-nav__link<?= $paginaCatalogo ? ' ativo' : '' ?>"
                    href="<?= e(url('loja', 'catalogo')) ?>"
                    <?= $paginaCatalogo ? 'aria-current="page"' : '' ?>
                >
                    Produto
                </a>

                <!-- Categorias -->

                <details class="nx-menu">

                    <summary
                        class="nx-nav__link<?= $categoriaAtual > 0 ? ' ativo' : '' ?>"
                    >
                        Categorias
                    </summary>

                    <div class="nx-menu__painel">

                        <?php if (!empty($categorias)): ?>

                            <ul class="nx-menu__lista">

                                <?php foreach ($categorias as $cat): ?>

                                    <?php
                                    if (
                                        !is_array($cat) ||
                                        !isset($cat['id_categoria'], $cat['nome'])
                                    ) {
                                        continue;
                                    }

                                    $categoriaId = (int) $cat['id_categoria'];
                                    $categoriaAtiva = $categoriaId === $categoriaAtual;
                                    ?>

                                    <li>
                                        <a
                                            class="nx-menu__item<?= $categoriaAtiva ? ' ativo' : '' ?>"
                                            href="<?= e(url(
                                                'loja',
                                                'catalogo',
                                                ['categoria_id' => $categoriaId]
                                            )) ?>"
                                        >
                                            <?= e($cat['nome']) ?>
                                        </a>
                                    </li>

                                <?php endforeach; ?>

                            </ul>

                        <?php else: ?>

                            <p class="nx-menu__vazio">
                                Nenhuma categoria disponível.
                            </p>

                        <?php endif; ?>

                    </div>

                </details>

                <!-- Ofertas -->

                <a
                    class="nx-nav__link<?= $paginaOfertas ? ' ativo' : '' ?>"
                    href="<?= e(url('loja', 'ofertas')) ?>"
                    <?= $paginaOfertas ? 'aria-current="page"' : '' ?>
                >
                    Ofertas
                </a>

            </nav>

            <!-- Pesquisa de jogos -->

            <form
                class="nx-busca"
                action="index.php"
                method="get"
                role="search"
            >

                <input
                    type="hidden"
                    name="controller"
                    value="loja"
                >

                <input
                    type="hidden"
                    name="action"
                    value="catalogo"
                >

                <label
                    class="nx-sr-only"
                    for="nx-busca-q"
                >
                    Pesquisar jogos
                </label>

                <input
                    id="nx-busca-q"
                    type="search"
                    name="q"
                    value="<?= e($buscaAtual) ?>"
                    placeholder="Pesquisar jogos"
                    maxlength="100"
                >

                <button
                    type="submit"
                    aria-label="Pesquisar"
                >
                    <svg
                        viewBox="0 0 24 24"
                        width="18"
                        height="18"
                        aria-hidden="true"
                    >
                        <circle
                            cx="10"
                            cy="10"
                            r="6.5"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2.4"
                        />

                        <path
                            d="M15 15l6 6"
                            stroke="currentColor"
                            stroke-width="2.8"
                            stroke-linecap="round"
                        />
                    </svg>
                </button>

            </form>

            <!-- Carrinho e conta -->

            <div class="nx-conta">

                <!-- Carrinho -->

                <a
                    class="nx-carrinho<?= $paginaCarrinho ? ' ativo' : '' ?>"
                    href="<?= e(url('carrinho', 'index')) ?>"
                    aria-label="Carrinho, <?= $qtdCarrinho ?> item(ns)"
                >
                    <svg
                        viewBox="0 0 24 24"
                        width="22"
                        height="22"
                        aria-hidden="true"
                    >
                        <path
                            d="M3 4h2l2.4 10.2a1 1 0 0 0 1 .8h8.9a1 1 0 0 0 1-.8L20 8H6.2"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.9"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />

                        <circle
                            cx="9.5"
                            cy="19"
                            r="1.5"
                            fill="currentColor"
                        />

                        <circle
                            cx="17"
                            cy="19"
                            r="1.5"
                            fill="currentColor"
                        />
                    </svg>

                    <span class="nx-carrinho__texto">
                        Carrinho
                    </span>

                    <?php if ($qtdCarrinho > 0): ?>

                        <span
                            class="nx-carrinho__qtd"
                            data-carrinho-qtd
                        >
                            <?= $qtdCarrinho ?>
                        </span>

                    <?php endif; ?>

                </a>

                <!-- Divisória -->

                <span
                    class="nx-conta__sep"
                    aria-hidden="true"
                ></span>

                <?php if ($clienteLogado): ?>

                    <!-- Cliente logado -->

                    <a
                        class="nx-usuario"
                        href="<?= e(url('cliente', 'meusDados')) ?>"
                    >
                        <span>Minha conta</span>
                    </a>

                    <form
                        class="nx-conta__sair"
                        action="<?= e(url('cliente', 'logout')) ?>"
                        method="post"
                    >
                        <?= csrfCampo() ?>

                        <button type="submit">
                            Sair
                        </button>
                    </form>

                <?php elseif ($ehAdmin): ?>

                    <!-- Administrador -->

                    <a
                        class="nx-usuario"
                        href="<?= e(url('auth', 'dashboard')) ?>"
                    >
                        Painel
                    </a>

                    <form
                        class="nx-conta__sair"
                        action="<?= e(url('auth', 'logout')) ?>"
                        method="post"
                    >
                        <?= csrfCampo() ?>

                        <button type="submit">
                            Sair
                        </button>
                    </form>

                <?php else: ?>

                    <!-- Visitante -->

                    <a
                        class="nx-usuario"
                        href="<?= e(url('cliente', 'login')) ?>"
                    >
                        <svg
                            viewBox="0 0 24 28"
                            width="22"
                            height="26"
                            aria-hidden="true"
                        >
                            <circle
                                cx="12"
                                cy="6.5"
                                r="5.5"
                                fill="currentColor"
                            />

                            <path
                                d="M2 16h20v6.5c0 2-2 3.5-4.5 3.5h-11C4 26 2 24.5 2 22.5z"
                                fill="currentColor"
                            />
                        </svg>

                        <span>Login</span>
                    </a>

                <?php endif; ?>

            </div>

        </div>

    </header>

    <!-- Conteúdo principal -->

    <main
        id="conteudo"
        class="<?= $carregarHomeCss ? 'nx-main' : 'pagina' ?>"
    >

        <!-- Mensagens do sistema -->

        <?php foreach ($flashes as $f): ?>

            <?php
            if (
                !is_array($f) ||
                !isset($f['tipo'], $f['msg'])
            ) {
                continue;
            }

            $tipoFlash = (string) $f['tipo'];
            $mensagemFlash = (string) $f['msg'];
            ?>

            <div
                class="<?= $carregarHomeCss
                    ? 'nx-aviso nx-aviso--'
                    : 'aviso aviso--' ?><?= e($tipoFlash) ?>"
                role="<?= $tipoFlash === 'erro' ? 'alert' : 'status' ?>"
            >
                <?= e($mensagemFlash) ?>
            </div>

        <?php endforeach; ?>
