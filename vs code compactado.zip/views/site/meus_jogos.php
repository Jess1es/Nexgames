
<?php
/**
 * NexGames — Minha conta / Meus jogos.
 *
 * @var array $jogos
 */

$jogos = $jogos ?? [];
?>

<!-- BANNER SUPERIOR -->

<section class="banner-conta">
    <h1>Meus jogos</h1>

    <p>
        Aqui você encontra todos os jogos que comprou
        e pode baixá-los sempre que quiser.
    </p>
</section>

<!-- ÁREA DA CONTA -->

<div class="conta-layout">

    <!-- MENU LATERAL -->

    <aside class="conta-menu" aria-label="Menu da minha conta">
        <nav class="conta-menu__nav">

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'meusDados')) ?>"
            >
                Meu perfil
            </a>

            <a
                class="conta-menu__link ativo"
                href="<?= e(url('pedido', 'meusJogos')) ?>"
                aria-current="page"
            >
                Meus jogos
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'metodosPagamento')) ?>"
            >
                Método de pagamento
            </a>
            
            <a
                    class="conta-menu__link"
                    href="<?= e(url('cliente', 'suporte')) ?>"
                >
                    Suporte
                </a>

        </nav>
    </aside>

    <!-- CONTEÚDO -->

    <section class="conta-conteudo meus-jogos">

        <h2 class="meus-jogos__titulo">
            <span aria-hidden="true"></span>
            JOGOS COMPRADOS
        </h2>

        <p class="meus-jogos__descricao">
            Seus jogos adquiridos estão listados abaixo.
            Clique em "baixar jogo" para ter acesso ao seu conteúdo.
        </p>

        <?php if (empty($jogos)): ?>

            <div class="meus-jogos__vazio">
                <h3>Você ainda não possui jogos na biblioteca.</h3>

                <p>
                    Depois de concluir uma compra,
                    seus jogos aparecerão aqui.
                </p>

                <a
                    href="<?= e(url('loja', 'index', ['catalogo' => 1])) ?>"
                    class="meus-jogos__botao"
                >
                    Explorar jogos
                </a>
            </div>

        <?php else: ?>

            <div class="meus-jogos__lista">

                <?php foreach ($jogos as $jogo): ?>

                    <article class="meus-jogos__item">

                        <img
                            class="meus-jogos__imagem"
                            src="<?= e($jogo['imagem']) ?>"
                            alt="Capa de <?= e($jogo['nome']) ?>"
                            loading="lazy"
                        >

                        <div class="meus-jogos__informacoes">

                            <h3>
                                <?= e($jogo['nome']) ?>
                            </h3>

                            <p>
                                <?= e(
                                    $jogo['categorias'] !== ''
                                        ? $jogo['categorias']
                                        : 'Categorias não informadas'
                                ) ?>
                            </p>

                            <p>
                                Comprado em:
                                <?php
                                $data = $jogo['data_compra'];
                                $timestamp = $data
                                    ? strtotime($data)
                                    : false;
                                ?>

                                <?= $timestamp
                                    ? e(date('d/m/Y', $timestamp))
                                    : 'Data não informada'
                                ?>
                            </p>

                        </div>

                        <!-- Download simulado:
                             abre a imagem cadastrada do jogo. -->

                        <a
                            class="meus-jogos__botao"
                            href="<?= e($jogo['imagem']) ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label="Baixar jogo <?= e($jogo['nome']) ?>"
                        >
                            Baixar jogo
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>

</div>
