
<?php
/**
 * NexGames — Aguardando pagamento simulado.
 * Arquivo: views/site/aguardando_pagamento.php
 */

$idPedido = (int) (
    $pedido['id']
    ?? $pedido['id_pedido']
    ?? 0
);

$total = (float) (
    $pedido['valor_total']
    ?? $pedido['total']
    ?? 0
);

$forma = (string) (
    $pedido['forma_pagamento'] ?? ''
);

$segundosRestantes = max(
    1,
    min(5, (int) ($segundosRestantes ?? 5))
);

$destino = url(
    'pedido',
    'concluirPagamentoSimulado',
    ['id' => $idPedido]
);
?>

<meta
    http-equiv="refresh"
    content="<?= $segundosRestantes ?>;url=<?= e($destino) ?>"
>

<div class="nx-espera">

    <header class="nx-espera__cabecalho">
        <h1>PAGAMENTO</h1>
        <p>Acompanhe a situação da sua compra.</p>
    </header>

    <section class="nx-espera__fundo">

        <div class="nx-espera__cartao">

            <div class="nx-espera__indicador"
                 aria-hidden="true"></div>

            <h2>
                AGUARDANDO<br>
                PAGAMENTO...
            </h2>

            <p class="nx-espera__detalhes">
                Pedido #<?= $idPedido ?>
            </p>

            <p class="nx-espera__detalhes">
                Total: <?= e(moeda($total)) ?>
            </p>

            <p class="nx-espera__detalhes">
                Forma de pagamento:
                <?= $forma === 'pix' ? 'Pix' : 'Cartão' ?>
            </p>

            <p class="nx-espera__aviso" role="status">
                Processando seu pagamento.
                Você será direcionado automaticamente.
            </p>

        </div>

    </section>

</div>

<style>
.nx-espera {
    min-height: 650px;
    background: #050509;
    color: #fff;
}

.nx-espera__cabecalho {
    padding: 28px max(24px, 5%);
    background: #050509;
}

.nx-espera__cabecalho h1 {
    margin: 0 0 12px;
    font-family: Arial, sans-serif;
    font-size: clamp(34px, 5vw, 52px);
    font-weight: 900;
}

.nx-espera__cabecalho p {
    margin: 0;
    font-size: 14px;
}

.nx-espera__fundo {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 500px;
    padding: 35px 20px;
    background:
        linear-gradient(
            rgba(5, 3, 12, .78),
            rgba(5, 3, 12, .85)
        ),
        #10091b;
}

.nx-espera__cartao {
    width: min(100%, 390px);
    padding: 48px 26px;
    background: #050509;
    border: 2px solid #852bff;
    border-radius: 30px;
    text-align: center;
    box-shadow: 0 15px 45px rgba(0, 0, 0, .35);
}

.nx-espera__indicador {
    width: 38px;
    height: 38px;
    margin: 0 auto 25px;
    border: 4px solid #392050;
    border-top-color: #9346ff;
    border-radius: 50%;
    animation: nx-espera-girar 1s linear infinite;
}

@keyframes nx-espera-girar {
    to { transform: rotate(360deg); }
}

.nx-espera__cartao h2 {
    margin: 0 0 25px;
    font-family: Arial, sans-serif;
    font-size: clamp(25px, 4vw, 33px);
    line-height: 1.45;
}

.nx-espera__detalhes {
    margin: 8px 0;
    color: #ded4ed;
    font-size: 14px;
}

.nx-espera__aviso {
    margin: 28px 0 12px;
    color: #bb8dff;
    font-size: 14px;
    line-height: 1.6;
}

.nx-espera__academico {
    margin: 18px 0 0;
    color: #a99db6;
    font-size: 12px;
    line-height: 1.6;
}

@media (prefers-reduced-motion: reduce) {
    .nx-espera__indicador {
        animation: none;
    }
}
</style>
