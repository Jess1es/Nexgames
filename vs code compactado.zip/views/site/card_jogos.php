
<?php
/**
 * NexGames - Card de jogos
 * Arquivo: views/site/card_jogos.php
 */

$p = isset($p) && is_array($p) ? $p : [];

$p = array_merge([
    'id_produto' => 0,
    'nome' => '',
    'preco' => 0,
    'preco_promocional' => null,
    'em_oferta' => 0,
    'imagem' => '',
    'categorias_nomes' => ''
], $p);

$precoNow = precoAtual($p);
$desc = descontoPercentual($p);
?>

<li class="card card--jogo">
    <a
        class="card__link"
        href="<?= e(url('loja', 'produto', ['id' => $p['id_produto']])) ?>"
    >
        <div class="card__foto">
            <img
                src="<?= e($p['imagem']) ?>"
                alt="Capa de <?= e($p['nome']) ?>"
                loading="lazy"
                width="400"
                height="500"
            >

            <?php if ($desc > 0): ?>
                <span class="selo selo--oferta">
                    -<?= (int) $desc ?>%
                </span>
            <?php endif; ?>
        </div>

        <div class="card__corpo">
            <span class="card__categoria">
                <?= e($p['categorias_nomes']) ?>
            </span>

            <h3 class="card__nome">
                <?= e($p['nome']) ?>
            </h3>

            <p class="card__preco">
                <?php if ($desc > 0): ?>
                    <s class="preco-antigo">
                        <?= e(moeda($p['preco'])) ?>
                    </s>
                <?php endif; ?>

                <strong>
                    <?= e(moeda($precoNow)) ?>
                </strong>
            </p>
        </div>
    </a>
</li>
