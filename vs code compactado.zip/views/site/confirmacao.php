
<?php

$idPedido = (int) (
    $pedido['id']
    ?? $pedido['id_pedido']
    ?? 0
);

$status = (string) (
    $pedido['status'] ?? ''
);

$statusPagamento = (string) (
    $pedido['pagamento']['status'] ?? ''
);

$pagamentoAprovado =
    $status === 'pago' &&
    $statusPagamento === 'aprovado';

$pagamentoPendente =
    $status === 'aguardando_pagamento' &&
    $statusPagamento === 'pendente';

$cancelado =
    $status === 'cancelado' ||
    $statusPagamento === 'cancelado';

$total = (float) (
    $pedido['total']
    ?? $pedido['valor_total']
    ?? 0
);

$formaPagamento = (string) (
    $pedido['forma_pagamento'] ?? ''
);
?>

<div class="nx-status-pagamento">

    <header class="nx-status-pagamento__cabecalho">
        <h1>PAGAMENTO</h1>

        <p>
            Acompanhe a situação da sua compra.
        </p>
    </header>

    <section class="nx-status-pagamento__cenario">

        <div class="nx-status-pagamento__cartao">

            <?php if ($pagamentoAprovado): ?>

                <!-- PAGAMENTO EFETUADO -->

                <h2>
                    PAGAMENTO<br>
                    EFETUADO!
                </h2>

                <p class="nx-status-pagamento__sucesso">
                    O download do seu jogo já está
                    disponível em “Meus Jogos / Downloads”.
                </p>

                <a
                    class="nx-status-pagamento__destaque"
                    href="<?= e(url('pedido', 'meusJogos')) ?>"
                >
                    Divirta-se!
                </a>

            <?php elseif ($pagamentoPendente): ?>

                <!-- AGUARDANDO PAGAMENTO -->

                <h2>
                    AGUARDANDO<br>
                    PAGAMENTO...
                </h2>

                <p class="nx-status-pagamento__informacao">
                    Pedido #<?= $idPedido ?>
                </p>

                <p class="nx-status-pagamento__informacao">
                    Total: <?= e(moeda($total)) ?>
                </p>

                <p class="nx-status-pagamento__informacao">
                    Forma de pagamento:
                    <?= $formaPagamento === 'pix'
                        ? 'Pix'
                        : 'Cartão' ?>
                </p>

                <form
                    class="nx-status-pagamento__form"
                    action="<?= e(url('pedido', 'aprovarPagamento')) ?>"
                    method="post"
                >
                    <?= csrfCampo() ?>

                    <input
                        type="hidden"
                        name="id_pedido"
                        value="<?= $idPedido ?>"
                    >

                    <button
                        type="submit"
                        class="nx-status-pagamento__botao"
                    >
                        Confirmar pagamento simulado
                    </button>
                </form>

                <small class="nx-status-pagamento__observacao">
                    Demonstração acadêmica.
                    Nenhum pagamento real será realizado.
                </small>

            <?php elseif ($cancelado): ?>

                <!-- PEDIDO CANCELADO -->

                <h2>
                    PEDIDO<br>
                    CANCELADO
                </h2>

                <p class="nx-status-pagamento__informacao">
                    O pedido #<?= $idPedido ?> foi cancelado.
                </p>

                <a
                    class="nx-status-pagamento__destaque"
                    href="<?= e(url('loja', 'index')) ?>"
                >
                    Voltar à loja
                </a>

            <?php else: ?>

                <!-- OUTRO STATUS -->

                <h2>
                    STATUS DO<br>
                    PAGAMENTO
                </h2>

                <p class="nx-status-pagamento__informacao">
                    Não foi possível confirmar
                    a situação deste pedido.
                </p>

                <a
                    class="nx-status-pagamento__destaque"
                    href="<?= e(url('pedido', 'meusPedidos')) ?>"
                >
                    Ver meus pedidos
                </a>

            <?php endif; ?>

        </div>

    </section>

    <nav
        class="nx-status-pagamento__rodape"
        aria-label="Navegação do pedido"
    >
        <a href="<?= e(url('loja', 'index')) ?>">
            Voltar à loja
        </a>

        <a href="<?= e(url('pedido', 'meusPedidos')) ?>">
            Meus pedidos
        </a>

        <?php if ($pagamentoAprovado): ?>
            <a
                href="<?= e(url('pedido', 'verNota', [
                    'id' => $idPedido
                ])) ?>"
            >
                Ver nota fiscal
            </a>
        <?php endif; ?>
    </nav>

</div>
