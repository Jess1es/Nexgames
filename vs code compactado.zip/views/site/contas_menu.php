
<?php

$secao = $secao ?? 'perfil';
?>

<aside class="conta-menu" aria-label="Menu da minha conta">

    <nav class="conta-menu__nav">

        <a
            href="<?= e(url('cliente', 'meusDados')) ?>"
            class="conta-menu__link<?= $secao === 'perfil' ? ' ativo' : '' ?>"
            <?= $secao === 'perfil' ? 'aria-current="page"' : '' ?>
        >
            Meu perfil
        </a>

        <span class="conta-menu__link conta-menu__link--indisponivel">
            Meus jogos
        </span>

        <span class="conta-menu__link conta-menu__link--indisponivel">
            Método de pagamento
        </span>

        <span class="conta-menu__link conta-menu__link--indisponivel">
            Suporte
        </span>

    </nav>

</aside>
