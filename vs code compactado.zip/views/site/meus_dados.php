
<?php

$secao = 'perfil';

$old = ($old ?? []) + [
    'nome' => '',
    'email' => '',
    'cpf' => '',
    'telefone' => '',
    'data_cadastro' => null,
];

$erros = $erros ?? [];
$errosSenha = $errosSenha ?? [];

/* EXIBIÇÃO DOS ERROS */

$erroCampo = fn(array $lista, string $campo) =>
    isset($lista[$campo])
        ? '<span class="campo__erro" id="erro-' .
          $campo . '">' .
          e($lista[$campo]) .
          '</span>'
        : '';

$descrito = fn(array $lista, string $campo) =>
    isset($lista[$campo])
        ? ' aria-invalid="true" aria-describedby="erro-' .
          $campo . '"'
        : '';

?>

<!-- BANNER SUPERIOR -->

<section class="banner-conta">

    <h1>Minha conta</h1>

    <p>
        Gerencie sua conta, seus jogos, pedidos e
        preferências na NEX Games.
    </p>

</section>


<!-- CONTEÚDO DA CONTA -->

<div class="conta-layout">

    <!-- MENU LATERAL -->

    <aside class="conta-menu" aria-label="Menu da minha conta">

        <nav class="conta-menu__nav">

            <a
                href="<?= e(url('cliente', 'meusDados')) ?>"
                class="conta-menu__link ativo"
                aria-current="page"
            >
                Meu perfil
            </a>

            <!-- Demais páginas ainda não vinculadas -->

           <a
                href="<?= e(url('pedido', 'meusJogos')) ?>"
                class="conta-menu__link"
            >
               Meus jogos
          </a>

            <a
              class="conta-menu__link"
              href="<?= e(url('cliente', 'metodosPagamento')) ?>"
          >
              Método de pagamento
           </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'suporte')) ?>"
            >
                Suporte
            </a>

        </nav>

    </aside>


    <!-- CONTEÚDO PRINCIPAL -->

    <div class="conta-conteudo">

        <h2 class="secao__titulo">
            MEU <span class="destaque">PERFIL</span>
        </h2>

        <p class="formulario__intro">

            Confira e mantenha seus dados sempre atualizados.

            <?php if (!empty($old['data_cadastro'])): ?>

                Membro desde
                <?= e(date(
                    'd/m/Y',
                    strtotime($old['data_cadastro'])
                )) ?>.

            <?php endif; ?>

        </p>


        <!-- DADOS DO CADASTRO -->

        <section class="formulario">

            <h2>Dados do cadastro</h2>

            <?php if (isset($erros['geral'])): ?>

                <div
                    class="aviso aviso--erro"
                    role="alert"
                >
                    <?= e($erros['geral']) ?>
                </div>

            <?php endif; ?>

            <form
                action="<?= e(url('cliente', 'meusDados')) ?>"
                method="post"
                novalidate
            >

                <?= csrfCampo() ?>

                <!-- NOME -->

                <div class="campo">

                    <label for="nome">
                        Nome completo
                    </label>

                    <input
                        id="nome"
                        type="text"
                        name="nome"
                        value="<?= e($old['nome']) ?>"
                        maxlength="150"
                        required
                        <?= $descrito($erros, 'nome') ?>
                    >

                    <?= $erroCampo($erros, 'nome') ?>

                </div>


                <!-- EMAIL -->

                <div class="campo">

                    <label for="email">
                        E-mail
                    </label>

                    <input
                        id="email"
                        type="email"
                        name="email"
                        value="<?= e($old['email']) ?>"
                        maxlength="150"
                        required
                        <?= $descrito($erros, 'email') ?>
                    >

                    <?= $erroCampo($erros, 'email') ?>

                </div>


                <!-- CPF -->

                <div class="campo">

                    <label for="cpf">
                        CPF
                    </label>

                    <input
                        id="cpf"
                        type="text"
                        value="<?= e(formatarCpf($old['cpf'])) ?>"
                        readonly
                        aria-describedby="ajuda-cpf"
                    >

                    <span
                        class="campo__ajuda"
                        id="ajuda-cpf"
                    >
                        O CPF identifica seu cadastro
                        e não pode ser alterado.
                    </span>

                </div>


                <!-- TELEFONE -->

                <div class="campo">

                    <label for="telefone">

                        Telefone

                        <span class="campo__opcional">
                            (opcional)
                        </span>

                    </label>

                    <input
                        id="telefone"
                        type="text"
                        name="telefone"
                        value="<?= e(formatarTelefone($old['telefone'])) ?>"
                        inputmode="tel"
                        maxlength="15"
                        data-mascara="telefone"
                        <?= $descrito($erros, 'telefone') ?>
                    >

                    <?= $erroCampo($erros, 'telefone') ?>

                </div>


                <!-- SALVAR -->

                <button
                    type="submit"
                    class="botao botao--primario"
                >
                    Salvar alterações
                </button>

            </form>

        </section>


        <!-- ALTERAR SENHA -->

        <section class="formulario">

            <h2>Alterar senha</h2>

            <form
                action="<?= e(url('cliente', 'alterarSenha')) ?>"
                method="post"
                novalidate
            >

                <?= csrfCampo() ?>

                <!-- SENHA ATUAL -->

                <div class="campo">

                    <label for="senha_atual">
                        Senha atual
                    </label>

                    <input
                        id="senha_atual"
                        type="password"
                        name="senha_atual"
                        autocomplete="current-password"
                        required
                        <?= $descrito($errosSenha, 'senha_atual') ?>
                    >

                    <?= $erroCampo($errosSenha, 'senha_atual') ?>

                </div>


                <!-- NOVA SENHA -->

                <div class="campo">

                    <label for="senha">
                        Nova senha
                    </label>

                    <input
                        id="senha"
                        type="password"
                        name="senha"
                        minlength="8"
                        maxlength="72"
                        autocomplete="new-password"
                        required
                        <?= $descrito($errosSenha, 'senha') ?>
                    >

                    <span class="campo__ajuda">
                        Mínimo de 8 caracteres.
                    </span>

                    <?= $erroCampo($errosSenha, 'senha') ?>

                </div>


                <!-- CONFIRMAR SENHA -->

                <div class="campo">

                    <label for="senha_confirmacao">
                        Confirmar nova senha
                    </label>

                    <input
                        id="senha_confirmacao"
                        type="password"
                        name="senha_confirmacao"
                        maxlength="72"
                        autocomplete="new-password"
                        required
                        <?= $descrito($errosSenha, 'senha_confirmacao') ?>
                    >

                    <?= $erroCampo($errosSenha, 'senha_confirmacao') ?>

                </div>


                <button
                    type="submit"
                    class="botao botao--secundario"
                >
                    Alterar senha
                </button>

            </form>

        </section>


        <!-- EXCLUIR CONTA -->

        <section class="formulario">

            <h2>Excluir conta</h2>

            <form
                method="post"
                action="<?= e(url('cliente', 'excluirConta')) ?>"
                onsubmit="return confirm('Tem certeza que deseja excluir sua conta? Essa ação não pode ser desfeita.');"
            >

                <?= csrfCampo() ?>

                <div class="campo">

                    <label for="senha_exclusao">
                        Confirme sua senha para excluir a conta
                    </label>

                    <input
                        type="password"
                        id="senha_exclusao"
                        name="senha"
                        autocomplete="current-password"
                        required
                    >

                </div>

                <button
                    type="submit"
                    class="botao botao--secundario link--perigo"
                >
                    Excluir minha conta
                </button>

            </form>

        </section>

    </div>

</div>
