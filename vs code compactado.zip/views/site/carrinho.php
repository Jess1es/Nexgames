<?php
/**
 * NexGames — Carrinho de compras
 *
 * @var Carrinho $carrinho
 */

// Lista de jogos
$itens = $carrinho->itens();

// Valores iniciais
$subtotalBruto = 0.0;
$descontoTotal = 0.0;

// Calcula subtotal e descontos
foreach ($itens as $item) {

    $precoAtual = (float) (
        $item['preco_unitario'] ?? 0
    );

    $precoOriginal = (float) (
        $item['preco_original'] ?? $precoAtual
    );

    $subtotalBruto += $precoOriginal;

    $descontoTotal += max(
        0,
        $precoOriginal - $precoAtual
    );
}

// Total final
$totalCarrinho = $carrinho->total();
?>

<!-- BANNER SUPERIOR -->

<section class="nx-carrinho-banner">

    <div class="nx-carrinho-banner__conteudo">

        <h1>Carrinho</h1>

        <p>
            Confira seus itens antes de finalizar a compra.
        </p>

    </div>

</section>


<?php if (empty($itens)): ?>

    <!-- CARRINHO VAZIO -->

    <section class="nx-carrinho-vazio">

        <h2>Seu carrinho está vazio.</h2>

        <p>
            Escolha um jogo na loja e ele aparecerá aqui.
        </p>

        <a
            class="nx-carrinho-botao nx-carrinho-botao--primario"
            href="<?= e(url(
                'loja',
                'index',
                ['catalogo' => 1]
            )) ?>"
        >
            Ver jogos
        </a>

    </section>

<?php else: ?>

    <!-- CARRINHO COM PRODUTOS -->

    <section class="nx-carrinho-layout">

        <div class="nx-carrinho-produtos">

            <table class="nx-carrinho-tabela">

                <thead>
                    <tr>
                        <th scope="col">Produto</th>
                        <th scope="col">Preço</th>
                        <th scope="col">Quantidade</th>
                        <th scope="col">Total</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach ($itens as $item): ?>

                        <?php
                        // Variáveis do produto
                        $produtoId = (int) (
                            $item['produto_id'] ?? 0
                        );

                        $produtoNome = (string) (
                            $item['produto_nome'] ?? ''
                        );

                        $imagem = (string) (
                            $item['imagem'] ?? ''
                        );

                        $categorias = (string) (
                            $item['categorias_nomes'] ?? ''
                        );

                        $preco = (float) (
                            $item['preco_unitario'] ?? 0
                        );

                        $precoOriginal = (float) (
                            $item['preco_original'] ?? $preco
                        );

                        $quantidade = 1;

                        $subtotalItem = $carrinho->subtotal($item);
                        ?>

                        <tr>

                            <td>

                                <div class="nx-carrinho-produto">

                                    <a href="<?= e(url(
                                        'loja',
                                        'produto',
                                        ['id' => $produtoId]
                                    )) ?>">

                                        <img
                                            src="<?= e($imagem) ?>"
                                            alt="Capa de <?= e($produtoNome) ?>"
                                            width="72"
                                            height="90"
                                            loading="lazy"
                                        >

                                    </a>

                                    <div class="nx-carrinho-produto__info">

                                        <a
                                            class="nx-carrinho-produto__nome"
                                            href="<?= e(url(
                                                'loja',
                                                'produto',
                                                ['id' => $produtoId]
                                            )) ?>"
                                        >
                                            <?= e($produtoNome) ?>
                                        </a>

                                        <?php if ($categorias !== ''): ?>

                                            <p class="nx-carrinho-produto__categoria">
                                                <?= e($categorias) ?>
                                            </p>

                                        <?php endif; ?>

                                        <form
                                            action="<?= e(url(
                                                'carrinho',
                                                'remover'
                                            )) ?>"
                                            method="post"
                                        >

                                            <?= csrfCampo() ?>

                                            <input
                                                type="hidden"
                                                name="produto_id"
                                                value="<?= $produtoId ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="nx-carrinho-remover"
                                            >
                                                Remover
                                            </button>

                                        </form>

                                    </div>

                                </div>

                            </td>

                            <td>

                                <?php if ($precoOriginal > $preco): ?>

                                    <del class="nx-carrinho-preco-antigo">
                                        <?= e(moeda($precoOriginal)) ?>
                                    </del>

                                <?php endif; ?>

                                <strong>
                                    <?= e(moeda($preco)) ?>
                                </strong>

                            </td>

                            <td>
                                <?= $quantidade ?>
                            </td>

                            <td>
                                <strong>
                                    <?= e(moeda($subtotalItem)) ?>
                                </strong>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

            <a
                class="nx-carrinho-continuar"
                href="<?= e(url(
                    'loja',
                    'index',
                    ['catalogo' => 1]
                )) ?>"
            >
                ← Continuar comprando
            </a>

        </div>


        <!-- RESUMO DO PEDIDO -->

        <aside class="nx-carrinho-resumo">

            <h2>Resumo do pedido</h2>

            <div class="nx-carrinho-resumo__linha">

                <span>Subtotal</span>

                <span>
                    <?= e(moeda($subtotalBruto)) ?>
                </span>

            </div>

            <?php if ($descontoTotal > 0.004): ?>

                <div class="nx-carrinho-resumo__linha">

                    <span>Desconto</span>

                    <span>
                        − <?= e(moeda($descontoTotal)) ?>
                    </span>

                </div>

            <?php endif; ?>

            <div class="nx-carrinho-resumo__linha">

                <span>Frete</span>

                <span>Grátis (digital)</span>

            </div>

            <div class="nx-carrinho-resumo__total">

                <strong>TOTAL</strong>

                <strong>
                    <?= e(moeda($totalCarrinho)) ?>
                </strong>

            </div>

            <a
                class="nx-carrinho-botao nx-carrinho-botao--primario"
                href="<?= e(url(
                    'pedido',
                    'checkout'
                )) ?>"
            >
                Finalizar compra
            </a>

            <form
                action="<?= e(url(
                    'carrinho',
                    'limpar'
                )) ?>"
                method="post"
            >

                <?= csrfCampo() ?>

                <button
                    type="submit"
                    class="nx-carrinho-botao nx-carrinho-botao--secundario"
                >
                    Limpar carrinho
                </button>

            </form>

        </aside>

    </section>

<?php endif; ?>
