
<?php

$produtos = isset($produtos) && is_array($produtos)
    ? $produtos
    : [];

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$editar = isset($editar) && is_array($editar)
    ? $editar
    : null;

$editando = $editar !== null;

$idEdicao = (int) (
    $editar['id_produto']
    ?? $editar['id']
    ?? 0
);

$nomeEdicao = (string) ($editar['nome'] ?? '');
$descricaoEdicao = (string) ($editar['descricao'] ?? '');
$precoEdicao = $editar['preco'] ?? '';
$promoEdicao = $editar['preco_promocional'] ?? '';
$ofertaEdicao = !empty($editar['em_oferta']);
$arquivoEdicao = (string) ($editar['arquivo_download'] ?? '');

/**
 * Categorias do jogo em edição.
 */
$categoriasEdicao = [];

if ($editar) {
    foreach ((array) ($editar['categorias'] ?? []) as $cat) {
        if (is_array($cat)) {
            $id = (int) ($cat['id_categoria'] ?? $cat['id'] ?? 0);
        } else {
            $id = (int) $cat;
        }

        if ($id > 0) {
            $categoriasEdicao[] = $id;
        }
    }

    if (!$categoriasEdicao && !empty($editar['categorias_ids'])) {
        $categoriasEdicao = array_map(
            'intval',
            explode(',', (string) $editar['categorias_ids'])
        );
    }
}

$categoriasEdicao = array_unique($categoriasEdicao);

/**
 * Normaliza os dados recebidos do Model.
 */
$listaJogos = [];

foreach ($produtos as $p) {
    if (!is_array($p)) {
        continue;
    }

    $id = (int) ($p['id_produto'] ?? $p['id'] ?? 0);

    $preco = (float) ($p['preco'] ?? 0);
    $promo = $p['preco_promocional'] ?? null;
    $oferta = !empty($p['em_oferta']);

    $precoFinal = $oferta && $promo !== null
        ? (float) $promo
        : $preco;

    $categoriasTexto = (string) (
        $p['categorias_nome']
        ?? $p['categoria_nome']
        ?? ''
    );

    if ($categoriasTexto === '' && !empty($p['categorias'])) {
        $nomes = [];

        foreach ((array) $p['categorias'] as $c) {
            if (is_array($c)) {
                $nomes[] = (string) ($c['nome'] ?? '');
            } elseif (is_string($c)) {
                $nomes[] = $c;
            }
        }

        $categoriasTexto = implode(', ', array_filter($nomes));
    }

    $imagem = trim((string) ($p['imagem'] ?? ''));

    if ($imagem !== '') {
        if (
            !preg_match('~^(https?://|/)~i', $imagem)
        ) {
            $imagem = '/nex/' . ltrim($imagem, '/');
        }
    }

    $listaJogos[] = [
        'id' => $id,
        'nome' => (string) ($p['nome'] ?? ''),
        'categorias' => $categoriasTexto,
        'preco' => $precoFinal,
        'imagem' => $imagem,
        'ativo' => (int) ($p['ativo'] ?? 1),
        'oferta' => $oferta,
    ];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Produtos/Jogos — NexGames</title>

    <link
        rel="icon"
        href="/nex/public/assets/img/favicon-nex.png"
    >

    <link
        rel="stylesheet"
        href="/nex/public/assets/css/admin-produtos.css?v=1"
    >
</head>

<body class="nx-admin-produtos">

    <!-- CABEÇALHO -->

    <header class="nx-admin-header">

        <a
            href="<?= e(url('auth', 'dashboard')) ?>"
            class="nx-admin-logo"
            aria-label="Voltar ao dashboard"
        >
            <img
                src="/nex/public/assets/img/logo-nex.jpeg"
                alt="NexGames"
            >
        </a>

        <div class="nx-admin-header-right">

            <span class="nx-admin-avatar">
                <svg
                    viewBox="0 0 24 24"
                    width="21"
                    height="21"
                    aria-hidden="true"
                >
                    <circle
                        cx="12"
                        cy="8"
                        r="4"
                        fill="currentColor"
                    />
                    <path
                        d="M4 21c0-5 3-8 8-8s8 3 8 8"
                        fill="currentColor"
                    />
                </svg>
            </span>

            <span>Administrador</span>

        </div>

    </header>

    <main class="nx-admin-main">

        <!-- NAVEGAÇÃO -->

        <div class="nx-admin-breadcrumb">

            <a href="<?= e(url('auth', 'dashboard')) ?>">
                Dashboard
            </a>

            <span>/</span>

            <span>Produtos/Jogos</span>

        </div>

        <div class="nx-admin-tag">
            Produtos/Jogos
        </div>

        <!-- CONTEÚDO PRINCIPAL -->

        <div class="nx-admin-grid">

            <!-- FORMULÁRIO -->

            <section class="nx-admin-form-panel">

                <h1>
                    <?= $editando ? 'Editar jogo' : 'Cadastrar jogo' ?>
                </h1>

                <?php if ($editando): ?>

                    <p class="nx-admin-editando">
                        Editando jogo #<?= $idEdicao ?>
                    </p>

                <?php endif; ?>

                <form
                    action="<?= e(url('produto', 'salvar')) ?>"
                    method="post"
                    enctype="multipart/form-data"
                    class="nx-admin-form"
                >

                    <?= csrfCampo() ?>

                    <input
                        type="hidden"
                        name="id_produto"
                        value="<?= $idEdicao ?>"
                    >

                    <!-- NOME -->

                    <div class="nx-admin-field">

                        <label for="nome">
                            Nome do jogo
                        </label>

                        <input
                            type="text"
                            id="nome"
                            name="nome"
                            value="<?= e($nomeEdicao) ?>"
                            placeholder="Digite o nome do jogo..."
                            maxlength="150"
                            required
                        >

                    </div>

                    <!-- DESCRIÇÃO -->

                    <div class="nx-admin-field">

                        <label for="descricao">
                            Descrição
                        </label>

                        <textarea
                            id="descricao"
                            name="descricao"
                            rows="4"
                            placeholder="Digite a descrição do jogo..."
                        ><?= e($descricaoEdicao) ?></textarea>

                    </div>

                    <!-- PREÇOS -->

                    <div class="nx-admin-price-grid">

                        <div class="nx-admin-field">

                            <label for="preco">
                                Preço (R$)
                            </label>

                            <input
                                type="number"
                                id="preco"
                                name="preco"
                                value="<?= e((string) $precoEdicao) ?>"
                                min="0.01"
                                step="0.01"
                                placeholder="0,00"
                                required
                            >

                        </div>

                        <div class="nx-admin-field">

                            <label for="preco_promocional">
                                Preço promocional (R$)
                            </label>

                            <input
                                type="number"
                                id="preco_promocional"
                                name="preco_promocional"
                                value="<?= e((string) $promoEdicao) ?>"
                                min="0.01"
                                step="0.01"
                                placeholder="0,00"
                            >

                        </div>

                    </div>

                    <!-- CATEGORIAS -->

                    <div class="nx-admin-field">

                        <label for="categorias">
                            Categoria(s)
                        </label>

                        <select
                            id="categorias"
                            name="categorias[]"
                            multiple
                            size="5"
                            required
                        >

                            <?php foreach ($categorias as $categoria): ?>

                                <?php
                                $categoriaId = (int) (
                                    $categoria['id_categoria']
                                    ?? $categoria['id']
                                    ?? 0
                                );

                                $categoriaNome = (string) (
                                    $categoria['nome'] ?? ''
                                );
                                ?>

                                <option
                                    value="<?= $categoriaId ?>"
                                    <?= in_array(
                                        $categoriaId,
                                        $categoriasEdicao,
                                        true
                                    ) ? 'selected' : '' ?>
                                >
                                    <?= e($categoriaNome) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <small>
                            Segure Ctrl para selecionar várias categorias.
                        </small>

                    </div>

                    <!-- IMAGEM -->

                    <div class="nx-admin-field">

                        <label for="imagem">
                            Imagem do jogo
                        </label>

                        <input
                            type="file"
                            id="imagem"
                            name="imagem"
                            accept="image/jpeg,image/png,image/webp"
                        >

                        <small>
                            JPG, PNG ou WEBP. Máximo de 2 MB.
                        </small>

                    </div>

                    <!-- DOWNLOAD -->

                    <div class="nx-admin-field">

                        <label for="arquivo_download">
                            Arquivo para download
                        </label>

                        <input
                            type="text"
                            id="arquivo_download"
                            name="arquivo_download"
                            value="<?= e($arquivoEdicao) ?>"
                            placeholder="Ex.: downloads/jogo.png"
                        >

                        <small>
                            Nesta etapa, informe o caminho do arquivo.
                            O upload direto será implementado depois.
                        </small>

                    </div>

                    <!-- OFERTA -->

                    <label class="nx-admin-checkbox">

                        <input
                            type="checkbox"
                            name="em_oferta"
                            value="1"
                            <?= $ofertaEdicao ? 'checked' : '' ?>
                        >

                        <span>Em oferta</span>

                    </label>

                    <!-- BOTÕES -->

                    <div class="nx-admin-form-actions">

                        <button
                            type="submit"
                            class="nx-admin-btn nx-admin-btn-primary"
                        >
                            <?= $editando ? 'Salvar alterações' : 'Salvar jogo' ?>
                        </button>

                        <a
                            href="<?= e(url('produto', 'index')) ?>"
                            class="nx-admin-btn nx-admin-btn-outline"
                        >
                            <?= $editando ? 'Cancelar' : 'Limpar' ?>
                        </a>

                    </div>

                </form>

            </section>

            <!-- LISTAGEM -->

            <section class="nx-admin-list-panel">

                <div class="nx-admin-list-top">

                    <div>

                        <h2>Jogos cadastrados</h2>

                        <p>
                            <?= count($listaJogos) ?>
                            jogo(s) encontrado(s)
                        </p>

                    </div>

                </div>

                <!-- PESQUISA E FILTROS -->

                <div class="nx-admin-filters">

                    <input
                        type="search"
                        id="nx-pesquisar-jogo"
                        placeholder="Pesquisar jogos..."
                        aria-label="Pesquisar jogos cadastrados"
                    >

                    <select
                        id="nx-filtrar-status"
                        aria-label="Filtrar por status"
                    >
                        <option value="todos">
                            Todos
                        </option>
                        <option value="ativo">
                            Ativos
                        </option>
                        <option value="inativo">
                            Inativos
                        </option>
                    </select>

                    <select
                        id="nx-filtrar-oferta"
                        aria-label="Filtrar ofertas"
                    >
                        <option value="todos">
                            Todas ofertas
                        </option>
                        <option value="oferta">
                            Em oferta
                        </option>
                        <option value="normal">
                            Sem oferta
                        </option>
                    </select>

                </div>

                <!-- TABELA -->

                <div class="nx-admin-table-wrap">

                    <table class="nx-admin-table">

                        <thead>
                            <tr>
                                <th>Imagem</th>
                                <th>Nome</th>
                                <th>Categoria(s)</th>
                                <th>Preço</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody id="nx-tabela-jogos">

                            <?php foreach ($listaJogos as $jogo): ?>

                                <tr
                                    class="nx-admin-game-row"
                                    data-nome="<?= e(mb_strtolower($jogo['nome'])) ?>"
                                    data-categorias="<?= e(mb_strtolower($jogo['categorias'])) ?>"
                                    data-status="<?= $jogo['ativo'] ? 'ativo' : 'inativo' ?>"
                                    data-oferta="<?= $jogo['oferta'] ? 'oferta' : 'normal' ?>"
                                >

                                    <!-- IMAGEM -->

                                    <td>

                                        <div class="nx-admin-game-image">

                                            <?php if ($jogo['imagem'] !== ''): ?>

                                                <img
                                                    src="<?= e($jogo['imagem']) ?>"
                                                    alt="<?= e($jogo['nome']) ?>"
                                                    loading="lazy"
                                                >

                                            <?php else: ?>

                                                <span aria-hidden="true">
                                                    🎮
                                                </span>

                                            <?php endif; ?>

                                        </div>

                                    </td>

                                    <!-- NOME -->

                                    <td class="nx-admin-game-name">
                                        <?= e($jogo['nome']) ?>
                                    </td>

                                    <!-- CATEGORIAS -->

                                    <td class="nx-admin-game-categories">
                                        <?= e(
                                            $jogo['categorias'] !== ''
                                                ? $jogo['categorias']
                                                : 'Sem categoria'
                                        ) ?>
                                    </td>

                                    <!-- PREÇO -->

                                    <td class="nx-admin-game-price">
                                        R$ <?= number_format(
                                            $jogo['preco'],
                                            2,
                                            ',',
                                            '.'
                                        ) ?>
                                    </td>

                                    <!-- STATUS -->

                                    <td>

                                        <span class="nx-admin-status <?= $jogo['ativo'] ? 'ativo' : 'inativo' ?>">
                                            <?= $jogo['ativo'] ? 'Ativo' : 'Inativo' ?>
                                        </span>

                                    </td>

                                    <!-- AÇÕES -->

                                    <td>

                                        <div class="nx-admin-row-actions">

                                            <!-- EDITAR -->

                                            <a
                                                class="nx-admin-action-edit"
                                                href="<?= e(url(
                                                    'produto',
                                                    'index',
                                                    ['id' => $jogo['id']]
                                                )) ?>"
                                                title="Editar jogo"
                                            >
                                                Editar
                                            </a>

                                            <!-- ATIVAR / DESATIVAR -->

                                            <form
                                                action="<?= e(url('produto', 'toggle')) ?>"
                                                method="post"
                                            >

                                                <?= csrfCampo() ?>

                                                <input
                                                    type="hidden"
                                                    name="id_produto"
                                                    value="<?= $jogo['id'] ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="ativo"
                                                    value="<?= $jogo['ativo'] ? 0 : 1 ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="nx-admin-action-toggle"
                                                    title="<?= $jogo['ativo'] ? 'Desativar' : 'Ativar' ?>"
                                                >
                                                    <?= $jogo['ativo'] ? 'Desativar' : 'Ativar' ?>
                                                </button>

                                            </form>

                                            <!-- EXCLUIR -->

                                            <form
                                                action="<?= e(url('produto', 'deletar')) ?>"
                                                method="post"
                                                onsubmit="return confirm('Tem certeza que deseja excluir este jogo? Essa ação não poderá ser desfeita.');"
                                            >

                                                <?= csrfCampo() ?>

                                                <input
                                                    type="hidden"
                                                    name="id_produto"
                                                    value="<?= $jogo['id'] ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="nx-admin-action-delete"
                                                    title="Excluir jogo"
                                                    aria-label="Excluir <?= e($jogo['nome']) ?>"
                                                >
                                                    <svg
                                                        viewBox="0 0 24 24"
                                                        width="17"
                                                        height="17"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        stroke-width="1.8"
                                                        aria-hidden="true"
                                                    >
                                                        <path d="M4 7h16"/>
                                                        <path d="M10 4h4"/>
                                                        <path d="M6 7l1 13h10l1-13"/>
                                                        <path d="M10 11v6M14 11v6"/>
                                                    </svg>
                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                    <p
                        class="nx-admin-empty"
                        id="nx-sem-resultados"
                        hidden
                    >
                        Nenhum jogo encontrado com esses filtros.
                    </p>

                    <?php if (!$listaJogos): ?>

                        <p class="nx-admin-empty">
                            Nenhum jogo cadastrado ainda.
                        </p>

                    <?php endif; ?>

                </div>

            </section>

        </div>

    </main>

    <!-- PESQUISA E FILTROS -->

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const pesquisa = document.getElementById('nx-pesquisar-jogo');
        const status = document.getElementById('nx-filtrar-status');
        const oferta = document.getElementById('nx-filtrar-oferta');
        const linhas = Array.from(
            document.querySelectorAll('.nx-admin-game-row')
        );
        const mensagem = document.getElementById('nx-sem-resultados');

        function filtrarJogos() {
            const termo = pesquisa.value.trim().toLowerCase();
            const statusEscolhido = status.value;
            const ofertaEscolhida = oferta.value;

            let visiveis = 0;

            linhas.forEach(function (linha) {
                const nome = linha.dataset.nome || '';
                const categorias = linha.dataset.categorias || '';

                const correspondeTexto =
                    nome.includes(termo) ||
                    categorias.includes(termo);

                const correspondeStatus =
                    statusEscolhido === 'todos' ||
                    linha.dataset.status === statusEscolhido;

                const correspondeOferta =
                    ofertaEscolhida === 'todos' ||
                    linha.dataset.oferta === ofertaEscolhida;

                const mostrar =
                    correspondeTexto &&
                    correspondeStatus &&
                    correspondeOferta;

                linha.hidden = !mostrar;

                if (mostrar) {
                    visiveis++;
                }
            });

            if (mensagem) {
                mensagem.hidden =
                    visiveis > 0 || linhas.length === 0;
            }
        }

        pesquisa.addEventListener('input', filtrarJogos);
        status.addEventListener('change', filtrarJogos);
        oferta.addEventListener('change', filtrarJogos);
    });
    </script>

</body>
</html>
