
<?php

$erro = (string) ($erro ?? '');
$email = (string) ($email ?? '');
?>

<!-- Formulário de login -->

<section class="formulario formulario--estreito">

    <h1>Entrar</h1>

    <!-- Mensagem de erro -->

    <?php if ($erro !== ''): ?>

        <div
            class="aviso aviso--erro"
            role="alert"
        >
            <?= e($erro) ?>
        </div>

    <?php endif; ?>

    <!-- Formulário -->

    <form
        action="<?= e(url('cliente', 'login')) ?>"
        method="post"
        novalidate
    >

        <?= csrfCampo() ?>

        <!-- E-mail -->

        <div class="campo">

            <label for="email">
                E-mail
            </label>

            <input
                id="email"
                type="email"
                name="email"
                value="<?= e($email) ?>"
                maxlength="255"
                autocomplete="email"
                required
                autofocus
            >

        </div>

        <!-- Senha -->

        <div class="campo">

            <label for="senha">
                Senha
            </label>

            <input
                id="senha"
                type="password"
                name="senha"
                autocomplete="current-password"
                required
            >

        </div>

        <!-- Botão entrar -->

        <button
            type="submit"
            class="botao botao--primario botao--cheio"
        >
            Entrar
        </button>

    </form>

    <!-- Link para cadastro -->

    <p class="formulario__rodape">
        Ainda não tem conta?

        <a href="<?= e(url('cliente', 'cadastro')) ?>">
            Criar conta
        </a>
    </p>

</section>
