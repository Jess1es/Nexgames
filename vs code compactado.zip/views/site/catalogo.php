
<?php

$produtos = isset($produtos) && is_array($produtos)
    ? $produtos
    : [];

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$total = (int) ($total ?? 0);

$pagina = max(1, (int) ($pagina ?? 1));

$paginas = max(1, (int) ($paginas ?? 1));

$categoriaNome = $categoriaNome ?? null;

/* Filtros do catálogo */

$filtros = isset($filtros) && is_array($filtros)
    ? $filtros
    : [];

$filtros = array_merge([
    'categoria_id' => 0,
    'busca' => ''
], $filtros);

$filtros['categoria_id'] = (int) $filtros['categoria_id'];
$filtros['busca'] = (string) $filtros['busca'];

/* Título do catálogo */

$titulo_lista = $filtros['busca'] !== ''
    ? 'Resultados para “' . $filtros['busca'] . '”'
    : ($categoriaNome ?? 'Todos os jogos');

/* Mantém os filtros ao trocar de página */

$paramsPagina = array_filter([
    'categoria_id' => $filtros['categoria_id'] ?: null,
    'q' => $filtros['busca'] !== ''
        ? $filtros['busca']
        : null
]);
?>

<!-- Cabeçalho do catálogo -->

<section class="lista-cabecalho">

    <h1>
        <?= e($titulo_lista) ?>
    </h1>

    <p class="lista-cabecalho__total">
        <?= $total ?>
        <?= $total === 1 ? 'jogo' : 'jogos' ?>
    </p>

</section>

<!-- Filtros por categoria -->

<nav
    class="pilulas pilulas--filtro"
    aria-label="Filtrar por categoria"
>

    <a
        class="pilula<?= !$filtros['categoria_id'] ? ' ativa' : '' ?>"
        href="<?= e(url('loja', 'catalogo')) ?>"
    >
        Todas
    </a>

    <?php foreach ($categorias as $cat): ?>

        <?php
        if (
            !is_array($cat) ||
            !isset($cat['id_categoria'], $cat['nome'])
        ) {
            continue;
        }

        $categoriaId = (int) $cat['id_categoria'];
        $categoriaAtiva = $categoriaId === $filtros['categoria_id'];
        ?>

        <a
            class="pilula<?= $categoriaAtiva ? ' ativa' : '' ?>"
            href="<?= e(url(
                'loja',
                'catalogo',
                ['categoria_id' => $categoriaId]
            )) ?>"
        >
            <?= e($cat['nome']) ?>
        </a>

    <?php endforeach; ?>

</nav>

<!-- Lista de jogos -->

<?php if (empty($produtos)): ?>

    <div class="vazio">

        <p>
            Nenhum jogo encontrado.
        </p>

        <p>
            Tente outro termo de busca ou volte para o catálogo completo.
        </p>

        <a
            class="botao botao--secundario"
            href="<?= e(url('loja', 'catalogo')) ?>"
        >
            Ver todos os jogos
        </a>

    </div>

<?php else: ?>

    <ul class="grade">

        <?php foreach ($produtos as $p): ?>

            <?php
            if (!is_array($p)) {
                continue;
            }

            require __DIR__ . '/_card_jogo.php';
            ?>

        <?php endforeach; ?>

    </ul>

    <!-- Paginação -->

    <?php if ($paginas > 1): ?>

        <nav
            class="paginacao"
            aria-label="Páginas de jogos"
        >

            <!-- Página anterior -->

            <?php if ($pagina > 1): ?>

                <a
                    href="<?= e(url(
                        'loja',
                        'catalogo',
                        $paramsPagina + [
                            'pagina' => $pagina - 1
                        ]
                    )) ?>"
                >
                    Anterior
                </a>

            <?php endif; ?>

            <!-- Números das páginas -->

            <?php for ($i = 1; $i <= $paginas; $i++): ?>

                <a
                    href="<?= e(url(
                        'loja',
                        'catalogo',
                        $paramsPagina + [
                            'pagina' => $i
                        ]
                    )) ?>"
                    class="<?= $i === $pagina ? 'ativa' : '' ?>"
                    <?= $i === $pagina
                        ? 'aria-current="page"'
                        : '' ?>
                >
                    <?= $i ?>
                </a>

            <?php endfor; ?>

            <!-- Próxima página -->

            <?php if ($pagina < $paginas): ?>

                <a
                    href="<?= e(url(
                        'loja',
                        'catalogo',
                        $paramsPagina + [
                            'pagina' => $pagina + 1
                        ]
                    )) ?>"
                >
                    Próxima
                </a>

            <?php endif; ?>

        </nav>

    <?php endif; ?>

<?php endif; ?>
