
<?php

$old = ($old ?? []) + [
    'nome' => '',
    'email' => '',
    'cpf' => '',
    'telefone' => ''
];

$erros = $erros ?? [];

$erroCampo = fn(string $campo) =>
    isset($erros[$campo])
        ? '<span class="campo__erro" id="erro-' . $campo . '">'
          . e($erros[$campo]) . '</span>'
        : '';

$descrito = fn(string $campo) =>
    isset($erros[$campo])
        ? ' aria-invalid="true" aria-describedby="erro-' . $campo . '"'
        : '';
?>

<style>
/* Configurações gerais */
:root {
    --cad-roxo: #7c29d9;
    --cad-roxo-claro: #a44cff;
    --cad-fundo: #050409;
    --cad-texto: #ffffff;
}

/* Cabeçalho */
body:has(.nx-cadastro) .nx-topo {
    position: relative !important;
    z-index: 20 !important;
    width: 100% !important;
    min-height: 66px !important;
    background: #050409 !important;
    border-bottom: 1px solid #77717f !important;
    box-shadow: none !important;
}

body:has(.nx-cadastro) .nx-topo__interno {
    width: 100% !important;
    max-width: 1450px !important;
    min-height: 65px !important;
    margin: 0 auto !important;
    padding: 7px 40px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    gap: 24px !important;
}

/* Logo do cabeçalho */
body:has(.nx-cadastro) .nx-marca {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex: 0 0 85px !important;
    width: 85px !important;
    min-width: 85px !important;
    max-width: 85px !important;
    height: 50px !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
}

body:has(.nx-cadastro) .nx-marca img {
    display: block !important;
    width: 85px !important;
    min-width: 85px !important;
    max-width: 85px !important;
    height: auto !important;
    max-height: 49px !important;
    object-fit: contain !important;
}

/* Menu de navegação */
body:has(.nx-cadastro) .nx-nav {
    display: flex !important;
    flex: 1 1 auto !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 31px !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
}

body:has(.nx-cadastro) .nx-nav__link {
    display: inline-flex !important;
    align-items: center !important;
    margin: 0 !important;
    padding: 0 !important;
    color: #ffffff !important;
    background: transparent !important;
    border: none !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    font-family: "Roboto Mono", monospace !important;
    font-size: 11px !important;
    font-weight: 400;
    line-height: 1.5 !important;
    text-decoration: none !important;
    white-space: nowrap !important;
}

body:has(.nx-cadastro) .nx-nav__link:hover {
    color: #bb78ff !important;
}

/* Categorias */
body:has(.nx-cadastro) .nx-menu {
    position: relative !important;
    margin: 0 !important;
    padding: 0 !important;
}

body:has(.nx-cadastro) .nx-menu summary {
    list-style: none !important;
    cursor: pointer !important;
}

body:has(.nx-cadastro) .nx-menu summary::-webkit-details-marker {
    display: none !important;
}

body:has(.nx-cadastro) .nx-menu__painel {
    position: absolute !important;
    top: calc(100% + 18px) !important;
    left: 0 !important;
    z-index: 100 !important;
    min-width: 200px !important;
    max-height: 320px !important;
    overflow-y: auto !important;
    padding: 10px !important;
    background: #0d0a16 !important;
    border: 1px solid #7c2bd6 !important;
    border-radius: 8px !important;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.4) !important;
}

body:has(.nx-cadastro) .nx-menu__item {
    color: #ffffff !important;
}

body:has(.nx-cadastro) .nx-menu__item:hover {
    color: #c99cff !important;
}

/* Barra de pesquisa */
body:has(.nx-cadastro) .nx-busca {
    display: flex !important;
    align-items: center !important;
    flex: 0 0 125px !important;
    width: 125px !important;
    min-width: 125px !important;
    max-width: 125px !important;
    height: 25px !important;
    min-height: 25px !important;
    margin: 0 !important;
    padding: 0 5px 0 8px !important;
    background: #151421 !important;
    border: none !important;
    border-radius: 0 !important;
    box-shadow: none !important;
}

/* Label acessível da pesquisa */
body:has(.nx-cadastro) .nx-busca .nx-sr-only {
    position: absolute !important;
    width: 1px !important;
    height: 1px !important;
    padding: 0 !important;
    margin: -1px !important;
    overflow: hidden !important;
    clip: rect(0, 0, 0, 0) !important;
    clip-path: inset(50%) !important;
    white-space: nowrap !important;
    border: 0 !important;
}

/* Campo de pesquisa */
body:has(.nx-cadastro) .nx-busca input[type="search"] {
    flex: 1 1 auto !important;
    width: 100% !important;
    min-width: 0 !important;
    height: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
    color: #ffffff !important;
    border: none !important;
    border-radius: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    font-family: "Roboto Mono", monospace !important;
    font-size: 8px !important;
}

body:has(.nx-cadastro) .nx-busca input::placeholder {
    color: #85818e !important;
    opacity: 1 !important;
}

body:has(.nx-cadastro) .nx-busca button {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex: 0 0 22px !important;
    width: 22px !important;
    height: 22px !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
    color: #ffffff !important;
    border: none !important;
    box-shadow: none !important;
    cursor: pointer !important;
}

body:has(.nx-cadastro) .nx-busca button svg {
    color: #ffffff !important;
}

/* Carrinho e login */
body:has(.nx-cadastro) .nx-conta {
    display: flex !important;
    align-items: center !important;
    justify-content: flex-end !important;
    gap: 17px !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
}

body:has(.nx-cadastro) .nx-carrinho {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
    border: none !important;
    color: #ffffff !important;
    font-family: Merriweather, Georgia, serif !important;
    font-size: 12px !important;
    text-decoration: none !important;
    white-space: nowrap !important;
}

body:has(.nx-cadastro) .nx-carrinho svg {
    width: 21px !important;
    height: 21px !important;
    color: #8e36dc !important;
}

body:has(.nx-cadastro) .nx-carrinho__qtd {
    background: #7c29d9 !important;
    color: #ffffff !important;
}

body:has(.nx-cadastro) .nx-conta__sep {
    display: block !important;
    flex: 0 0 1px !important;
    width: 1px !important;
    height: 33px !important;
    background: #9993a0 !important;
}

body:has(.nx-cadastro) .nx-usuario {
    display: inline-flex !important;
    align-items: center !important;
    gap: 7px !important;
    margin: 0 !important;
    padding: 0 !important;
    background: transparent !important;
    border: none !important;
    color: #ffffff !important;
    font-family: Merriweather, Georgia, serif !important;
    font-size: 12px !important;
    text-decoration: none !important;
    white-space: nowrap !important;
}

body:has(.nx-cadastro) .nx-usuario svg {
    width: 24px !important;
    height: 27px !important;
    color: #7027bd !important;
}

body:has(.nx-cadastro) .nx-carrinho:hover,
body:has(.nx-cadastro) .nx-usuario:hover {
    color: #c69aff !important;
}

/* Área principal */
body:has(.nx-cadastro) {
    background: #050409 !important;
}

body:has(.nx-cadastro) #conteudo {
    display: block !important;
    width: 100% !important;
    max-width: none !important;
    min-height: calc(100vh - 66px) !important;
    margin: 0 !important;
    padding: 0 !important;
    background: #050409 !important;
}

/* Fundo com jogos */
.nx-cadastro {
    position: relative;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    width: 100%;
    min-height: calc(100vh - 66px);
    margin: 0;
    padding: 55px 20px 75px;
    background-color: #080610;
    background-image:
        linear-gradient(
            rgba(0, 0, 0, 0.48),
            rgba(0, 0, 0, 0.68)
        ),
        url("/public/assets/img/fundo-login.png");
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
}

/* Cartão central */
.nx-cadastro__card {
    width: 100%;
    max-width: 405px;
    margin: 0 auto;
    padding: 25px 32px 28px;
    background: rgba(3, 3, 7, 0.97);
    border: 2px solid #8026e8;
    border-radius: 35px;
    box-shadow: 0 0 25px rgba(91, 25, 180, 0.14);
    color: #ffffff;
}

/* Logo central */
.nx-cadastro__logo {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 22px;
}

.nx-cadastro__logo img {
    display: block;
    width: 200px !important;
    max-width: 100% !important;
    height: auto !important;
    max-height: 95px !important;
    object-fit: contain;
}

.nx-cadastro__titulo {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
}

/* Formulário */
.nx-cadastro__form {
    display: flex;
    flex-direction: column;
    gap: 17px;
    width: 100%;
}

.nx-cadastro .campo {
    display: flex;
    flex-direction: column;
    gap: 6px;
    width: 100%;
    margin: 0;
}

.nx-cadastro .campo label {
    display: block;
    margin: 0;
    color: #ffffff;
    font-family: "Roboto Mono", "Courier New", monospace;
    font-size: 12px;
    font-weight: 400;
    line-height: 1.5;
}

.nx-cadastro .campo__opcional {
    color: #a6a0af;
    font-size: 10px;
}

/* Campos do cadastro */
.nx-cadastro .campo input {
    display: block;
    width: 100%;
    height: 35px;
    min-height: 35px;
    margin: 0;
    padding: 6px 13px;
    background: #09090e !important;
    color: #ffffff !important;
    border: 2px solid #77737e !important;
    border-radius: 20px !important;
    outline: none;
    font-family: Arial, sans-serif;
    font-size: 13px;
    box-shadow: none !important;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.nx-cadastro .campo input::placeholder {
    color: #77717d;
    font-size: 11px;
}

.nx-cadastro .campo input:hover {
    border-color: #a49bac !important;
}

.nx-cadastro .campo input:focus {
    border-color: #a64cff !important;
    box-shadow: 0 0 0 2px rgba(166, 76, 255, 0.15) !important;
}

/* Erros e mensagens */
.nx-cadastro .campo input[aria-invalid="true"] {
    border-color: #f07591 !important;
}

.nx-cadastro .campo__erro {
    display: block;
    color: #ff9ab0;
    font-family: Arial, sans-serif;
    font-size: 11px;
    line-height: 1.4;
}

.nx-cadastro .campo__ajuda {
    display: block;
    color: #aaa4b1;
    font-family: Arial, sans-serif;
    font-size: 10px;
}

.nx-cadastro__erro-geral {
    margin-bottom: 18px;
    padding: 12px;
    background: #35131f;
    color: #ffd2dd;
    border: 1px solid #d85c7d;
    border-radius: 10px;
    font-family: Arial, sans-serif;
    font-size: 12px;
    line-height: 1.5;
}

/* Botão cadastrar */
.nx-cadastro__acoes {
    display: flex;
    justify-content: center;
    margin-top: 6px;
}

.nx-cadastro__botao {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 145px;
    min-height: 36px;
    padding: 7px 22px;
    background: #7429bd !important;
    color: #ffffff !important;
    border: 2px solid #a46acd !important;
    border-radius: 5px !important;
    font-family: Arial, sans-serif;
    font-size: 17px;
    font-weight: 400;
    cursor: pointer;
    transition: background 0.2s, transform 0.2s;
}

.nx-cadastro__botao:hover {
    background: #9039df !important;
    transform: translateY(-1px);
}

.nx-cadastro__botao:active {
    transform: translateY(0);
}

/* Link para login */
.nx-cadastro__rodape {
    margin: 18px 0 0;
    color: #bdb7c7;
    font-family: Arial, sans-serif;
    font-size: 12px;
    text-align: center;
}

.nx-cadastro__rodape a {
    color: #c18aff;
    font-weight: 600;
    text-decoration: none;
}

.nx-cadastro__rodape a:hover {
    text-decoration: underline;
}

/* Responsividade */
@media (max-width: 1050px) {
    body:has(.nx-cadastro) .nx-topo__interno {
        gap: 14px !important;
        padding: 8px 18px !important;
    }

    body:has(.nx-cadastro) .nx-nav {
        gap: 18px !important;
    }

    body:has(.nx-cadastro) .nx-conta {
        gap: 10px !important;
    }
}

@media (max-width: 760px) {
    body:has(.nx-cadastro) .nx-topo__interno {
        flex-wrap: wrap !important;
        justify-content: space-between !important;
    }

    body:has(.nx-cadastro) .nx-nav {
        order: 4 !important;
        flex: 0 0 100% !important;
        justify-content: center !important;
        flex-wrap: wrap !important;
        gap: 20px !important;
        padding: 8px 0 !important;
    }

    body:has(.nx-cadastro) .nx-busca {
        flex-basis: 110px !important;
        width: 110px !important;
        min-width: 110px !important;
        max-width: 110px !important;
    }
}

@media (max-width: 600px) {
    .nx-cadastro {
        padding: 30px 12px 50px;
    }

    .nx-cadastro__card {
        max-width: 405px;
        padding: 24px 22px;
        border-radius: 27px;
    }

    .nx-cadastro__logo img {
        width: 175px !important;
    }

    .nx-cadastro__form {
        gap: 16px;
    }
}

@media (max-width: 480px) {
    body:has(.nx-cadastro) .nx-topo__interno {
        padding: 10px 12px !important;
    }

    body:has(.nx-cadastro) .nx-marca,
    body:has(.nx-cadastro) .nx-marca img {
        width: 72px !important;
        min-width: 72px !important;
        max-width: 72px !important;
    }

    body:has(.nx-cadastro) .nx-busca {
        display: none !important;
    }

    body:has(.nx-cadastro) .nx-nav {
        gap: 14px !important;
    }

    body:has(.nx-cadastro) .nx-nav__link {
        font-size: 10px !important;
    }
}

/* Link de acessibilidade */
body:has(.nx-cadastro) .nx-pular {
    position: fixed !important;
    top: -100px !important;
    left: 10px !important;
    z-index: 9999 !important;
    padding: 10px 15px !important;
    background: #7027bd !important;
    color: #ffffff !important;
    text-decoration: none !important;
}

body:has(.nx-cadastro) .nx-pular:focus {
    top: 10px !important;
}
</style>

<!-- Cadastro de cliente -->
<section class="nx-cadastro">
    <div class="nx-cadastro__card">

        <!-- Logo central -->
        <div class="nx-cadastro__logo">
            <img
                src="/public/assets/img/logo-nex.jpeg?v=20261122"
                alt="NEX Gaming Store"
                width="200"
            >
        </div>

        <h1 class="nx-cadastro__titulo">
            Criar conta
        </h1>

        <!-- Erro geral -->
        <?php if (isset($erros['geral'])): ?>
            <div class="nx-cadastro__erro-geral" role="alert">
                <?= e($erros['geral']) ?>
            </div>
        <?php endif; ?>

        <!-- Formulário -->
        <form
            class="nx-cadastro__form"
            action="<?= e(url('cliente', 'cadastro')) ?>"
            method="post"
            novalidate
        >
            <?= csrfCampo() ?>

            <!-- Nome -->
            <div class="campo">
                <label for="nome">Nome</label>

                <input
                    id="nome"
                    type="text"
                    name="nome"
                    value="<?= e($old['nome']) ?>"
                    maxlength="100"
                    autocomplete="name"
                    required
                    <?= $descrito('nome') ?>
                >

                <?= $erroCampo('nome') ?>
            </div>

            <!-- E-mail -->
            <div class="campo">
                <label for="email">E-mail</label>

                <input
                    id="email"
                    type="email"
                    name="email"
                    value="<?= e($old['email']) ?>"
                    maxlength="100"
                    autocomplete="email"
                    required
                    <?= $descrito('email') ?>
                >

                <?= $erroCampo('email') ?>
            </div>

            <!-- CPF -->
            <div class="campo">
                <label for="cpf">CPF</label>

                <input
                    id="cpf"
                    type="text"
                    name="cpf"
                    value="<?= e(formatarCpf($old['cpf'])) ?>"
                    inputmode="numeric"
                    maxlength="14"
                    placeholder="000.000.000-00"
                    data-mascara="cpf"
                    required
                    <?= $descrito('cpf') ?>
                >

                <?= $erroCampo('cpf') ?>
            </div>

            <!-- Telefone -->
            <div class="campo">
                <label for="telefone">
                    Telefone
                    <span class="campo__opcional">(opcional)</span>
                </label>

                <input
                    id="telefone"
                    type="text"
                    name="telefone"
                    value="<?= e(formatarTelefone($old['telefone'])) ?>"
                    inputmode="tel"
                    maxlength="15"
                    placeholder="(21) 99999-9999"
                    data-mascara="telefone"
                    autocomplete="tel"
                    <?= $descrito('telefone') ?>
                >

                <?= $erroCampo('telefone') ?>
            </div>

            <!-- Senha -->
            <div class="campo">
                <label for="senha">Senha</label>

                <input
                    id="senha"
                    type="password"
                    name="senha"
                    minlength="8"
                    maxlength="72"
                    autocomplete="new-password"
                    required
                    <?= $descrito('senha') ?>
                >

                <span class="campo__ajuda">
                    Mínimo de 8 caracteres.
                </span>

                <?= $erroCampo('senha') ?>
            </div>

            <!-- Confirmar senha -->
            <div class="campo">
                <label for="senha_confirmacao">
                    Confirme sua senha
                </label>

                <input
                    id="senha_confirmacao"
                    type="password"
                    name="senha_confirmacao"
                    maxlength="72"
                    autocomplete="new-password"
                    required
                    <?= $descrito('senha_confirmacao') ?>
                >

                <?= $erroCampo('senha_confirmacao') ?>
            </div>

            <!-- Botão cadastrar -->
            <div class="nx-cadastro__acoes">
                <button
                    type="submit"
                    class="nx-cadastro__botao"
                >
                    Cadastrar
                </button>
            </div>

        </form>

        <!-- Link para login -->
        <p class="nx-cadastro__rodape">
            Já possui uma conta?

            <a href="<?= e(url('cliente', 'login')) ?>">
                Entrar
            </a>
        </p>

    </div>
</section>
