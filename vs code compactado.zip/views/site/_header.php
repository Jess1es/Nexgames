
<?php
/**
 * NexGames - Cabeçalho da loja
 * Arquivo: views/site/_header.php
 * Carregado pelo SiteBaseController::render()
 */

/* Configuração das páginas */

$view = $view ?? '';

if ($view === '') {
    $view = basename(
        (string) ($_SERVER['SCRIPT_NAME'] ?? ''),
        '.php'
    );
}

/* CSS específico de cada página */

$cssPaginas = [
    'home' => 'home.css',
    'login' => 'login.css',
    'cadastro' => 'cadastro.css',
    'carrinho' => 'carrinho.css',
    'meus_dados' => 'minha-conta.css',
    'meus_jogos' => 'minha-conta.css',
    'meus_pedidos' => 'minha-conta.css',
    'metodos_pagamento' => 'minha-conta.css',
    'formulario_pagamento' => 'minha-conta.css',
    'produtos' => 'produto.css',
    'produto' => 'produto.css',
    'pagamento' => 'pagamento.css',
    'aguardando_pagamento' => 'pagamento.css',
    'confirmacao' => 'confirmacao.css',
    'suporte' => 'minha-conta.css',
];

$paginaNex = isset($cssPaginas[$view]);

/* Variáveis do layout */

$modoLista = $modoLista ?? false;

$filtros = isset($filtros) && is_array($filtros)
    ? $filtros
    : [];

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$qtdCarrinho = (int) ($qtdCarrinho ?? 0);

$clienteNome = $clienteNome ?? null;

$flashes = isset($flashes) && is_array($flashes)
    ? $flashes
    : [];

$buscaAtual = (string) ($buscaAtual ?? '');

$categoriaAtual = $categoriaAtual ?? 0;

$emOfertas = !empty($filtros['oferta']);

$catAtiva = is_array($categoriaAtual)
    ? (int) ($categoriaAtual['id'] ?? 0)
    : (int) $categoriaAtual;

/* Navegação ativa */

$navInicio = (
    $view === 'home' &&
    !$modoLista
);

$navProduto = (
    $view === 'home' &&
    $modoLista &&
    !$emOfertas &&
    $catAtiva === 0
);

$navCategoria = $catAtiva > 0;

$navOfertas = $emOfertas;

$carrinhoAtivo = $view === 'carrinho';

$contaAtiva = in_array(
    $view,
    [
        'meus_dados',
        'meus_jogos',
        'meus_pedidos',
        'metodos_pagamento',
        'formulario_pagamento',
        'suporte'
    ],
    true
);

/* Título da página */

$titulo = $titulo ?? 'NexGames';

$tituloPagina = $titulo === 'NexGames'
    ? 'NexGames'
    : $titulo . ' — NexGames';

/* Caminhos dos arquivos CSS */

$cssBaseUrl = '/public/assets/css/';

$cssBaseArquivo = dirname(__DIR__, 2)
    . '/public/assets/css/';

$cssPagina = $cssPaginas[$view] ?? null;

$cssPaginaExiste = $cssPagina !== null
    && is_file($cssBaseArquivo . $cssPagina);

/* Versão dos arquivos para atualizar o cache */

$versaoCss = '20261120';

/* Favicon */

$favicon = '/public/assets/img/favicon-nex.png?v=2';

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title><?= e($tituloPagina) ?></title>

    <!-- Favicon -->

    <link
        rel="icon"
        type="image/png"
        href="<?= e($favicon) ?>"
    >

    <link
        rel="shortcut icon"
        type="image/png"
        href="<?= e($favicon) ?>"
    >

    <!-- Fontes -->

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&family=Roboto+Mono:wght@400;500;700&display=swap"
    >

    <!-- CSS antigo para páginas não adaptadas -->

    <?php if (!$cssPaginaExiste): ?>

        <link
            rel="stylesheet"
            href="<?= e($cssBaseUrl . 'loja.css') ?>"
        >

    <?php endif; ?>

    <!-- CSS base da NexGames -->

    <link
        rel="stylesheet"
        href="<?= e($cssBaseUrl . 'nexbase.css') ?>?v=<?= e($versaoCss) ?>"
    >

    <!-- CSS específico da página -->

    <?php if ($cssPaginaExiste): ?>

        <link
            rel="stylesheet"
            href="<?= e($cssBaseUrl . $cssPagina) ?>?v=<?= e($versaoCss) ?>"
        >

    <?php endif; ?>

    <!-- CSS exclusivo do suporte -->

    <?php if (
        $view === 'suporte' &&
        is_file($cssBaseArquivo . 'suporte.css')
    ): ?>

        <link
            rel="stylesheet"
            href="<?= e($cssBaseUrl . 'suporte.css') ?>?v=<?= e($versaoCss) ?>"
        >

    <?php endif; ?>

    <!-- Ajustes do cabeçalho -->

    <style>
        .nx-pular {
            position: fixed !important;
            top: -100px !important;
            left: 10px !important;
            z-index: 99999 !important;

            padding: 10px 15px !important;

            background: #7027bd !important;
            color: #ffffff !important;

            font-family: Arial, sans-serif !important;
            font-size: 13px !important;

            text-decoration: none !important;
        }

        .nx-pular:focus {
            top: 10px !important;
        }

        .nx-busca .nx-sr-only {
            position: absolute !important;

            width: 1px !important;
            height: 1px !important;

            padding: 0 !important;
            margin: -1px !important;

            overflow: hidden !important;

            clip: rect(0, 0, 0, 0) !important;
            clip-path: inset(50%) !important;

            white-space: nowrap !important;
            border: 0 !important;
        }

        .nx-marca img {
            display: block;
            width: 85px;
            max-width: 100%;
            height: auto;
            object-fit: contain;
        }
    </style>

</head>

<body class="<?= $paginaNex ? 'nx-site' : '' ?>">

    <!-- Acessibilidade -->

    <a
        class="nx-pular"
        href="#conteudo"
    >
        Ir para o conteúdo
    </a>

    <!-- Cabeçalho principal -->

    <header class="nx-topo">

        <div class="nx-topo__interno">

            <!-- Logo -->

            <a
                class="nx-marca"
                href="<?= e(url('loja', 'index')) ?>"
                aria-label="NexGames — página inicial"
            >
                <img
                    src="/public/assets/img/logo-nex.jpeg?v=20261116"
                    alt="NexGames"
                    width="85"
                >
            </a>

            <!-- Navegação -->

            <nav
                class="nx-nav"
                aria-label="Principal"
            >

                <!-- Início -->

                <a
                    class="nx-nav__link<?= $navInicio ? ' ativo' : '' ?>"
                    href="<?= e(url('loja', 'index')) ?>"
                    <?= $navInicio ? 'aria-current="page"' : '' ?>
                >
                    Início
                </a>

                <!-- Produtos -->

                <a
                    class="nx-nav__link<?= $navProduto ? ' ativo' : '' ?>"
                    href="<?= e(url('loja', 'index', ['catalogo' => 1])) ?>"
                    <?= $navProduto ? 'aria-current="page"' : '' ?>
                >
                    Produto
                </a>

                <!-- Categorias -->

                <details class="nx-menu">

                    <summary
                        class="nx-nav__link<?= $navCategoria ? ' ativo' : '' ?>"
                    >
                        Categorias
                    </summary>

                    <div class="nx-menu__painel">

                        <?php if (!empty($categorias)): ?>

                            <ul class="nx-menu__lista">

                                <?php foreach ($categorias as $cat): ?>

                                    <?php
                                    if (
                                        !is_array($cat) ||
                                        !isset(
                                            $cat['id'],
                                            $cat['nome']
                                        )
                                    ) {
                                        continue;
                                    }

                                    $categoriaId = (int) $cat['id'];

                                    $categoriaNome = (string) $cat['nome'];
                                    ?>

                                    <li>
                                        <a
                                            class="nx-menu__item<?= $categoriaId === $catAtiva ? ' ativo' : '' ?>"
                                            href="<?= e(url(
                                                'loja',
                                                'index',
                                                [
                                                    'categoria_id' =>
                                                        $categoriaId
                                                ]
                                            )) ?>"
                                        >
                                            <?= e($categoriaNome) ?>
                                        </a>
                                    </li>

                                <?php endforeach; ?>

                            </ul>

                        <?php else: ?>

                            <p class="nx-menu__vazio">
                                Nenhuma categoria disponível.
                            </p>

                        <?php endif; ?>

                    </div>

                </details>

                <!-- Ofertas -->

                <a
                    class="nx-nav__link<?= $navOfertas ? ' ativo' : '' ?>"
                    href="<?= e(url('loja', 'index', ['oferta' => 1])) ?>"
                    <?= $navOfertas ? 'aria-current="page"' : '' ?>
                >
                    Ofertas
                </a>

            </nav>

            <!-- Pesquisa de jogos -->

            <form
                class="nx-busca"
                action="index.php"
                method="get"
                role="search"
            >

                <input
                    type="hidden"
                    name="controller"
                    value="loja"
                >

                <input
                    type="hidden"
                    name="action"
                    value="index"
                >

                <?php if ($catAtiva > 0): ?>

                    <input
                        type="hidden"
                        name="categoria_id"
                        value="<?= $catAtiva ?>"
                    >

                <?php endif; ?>

                <label
                    class="nx-sr-only"
                    for="nx-busca-q"
                >
                    Pesquisar jogos
                </label>

                <input
                    id="nx-busca-q"
                    type="search"
                    name="q"
                    value="<?= e($buscaAtual) ?>"
                    placeholder="Pesquisar jogos"
                    maxlength="100"
                >

                <button
                    type="submit"
                    aria-label="Pesquisar"
                >
                    <svg
                        viewBox="0 0 24 24"
                        width="18"
                        height="18"
                        aria-hidden="true"
                    >
                        <circle
                            cx="10"
                            cy="10"
                            r="6.5"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2.4"
                        />

                        <path
                            d="M15 15l6 6"
                            stroke="currentColor"
                            stroke-width="2.8"
                            stroke-linecap="round"
                        />
                    </svg>
                </button>

            </form>

            <!-- Área do cliente -->

            <div class="nx-conta">

                <!-- Carrinho -->

                <a
                    class="nx-carrinho<?= $carrinhoAtivo ? ' ativo' : '' ?>"
                    href="<?= e(url('carrinho', 'index')) ?>"
                    aria-label="Carrinho, <?= $qtdCarrinho ?> item(ns)"
                >
                    <svg
                        viewBox="0 0 24 24"
                        width="22"
                        height="22"
                        aria-hidden="true"
                    >
                        <path
                            d="M3 4h2l2.4 10.2a1 1 0 0 0 1 .8h8.9a1 1 0 0 0 1-.8L20 8H6.2"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.9"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />

                        <circle
                            cx="9.5"
                            cy="19"
                            r="1.5"
                            fill="currentColor"
                        />

                        <circle
                            cx="17"
                            cy="19"
                            r="1.5"
                            fill="currentColor"
                        />
                    </svg>

                    <span class="nx-carrinho__texto">
                        Carrinho
                    </span>

                    <?php if ($qtdCarrinho > 0): ?>

                        <span
                            class="nx-carrinho__qtd"
                            data-carrinho-qtd
                        >
                            <?= $qtdCarrinho ?>
                        </span>

                    <?php endif; ?>

                </a>

                <!-- Divisória -->

                <span
                    class="nx-conta__sep"
                    aria-hidden="true"
                ></span>

                <?php if ($clienteNome): ?>

                    <!-- Cliente logado -->

                    <a
                        class="nx-usuario<?= $contaAtiva ? ' ativo' : '' ?>"
                        href="<?= e(url('cliente', 'meusDados')) ?>"
                    >
                        <svg
                            viewBox="0 0 24 28"
                            width="22"
                            height="26"
                            aria-hidden="true"
                        >
                            <circle
                                cx="12"
                                cy="6.5"
                                r="5.5"
                                fill="currentColor"
                            />

                            <path
                                d="M2 16h20v6.5c0 2-2 3.5-4.5 3.5h-11C4 26 2 24.5 2 22.5z"
                                fill="currentColor"
                            />
                        </svg>

                        <span>Minha conta</span>
                    </a>

                    <!-- Sair -->

                    <form
                        class="nx-conta__sair"
                        action="<?= e(url('cliente', 'logout')) ?>"
                        method="post"
                    >
                        <?= csrfCampo() ?>

                        <button type="submit">
                            Sair
                        </button>
                    </form>

                <?php else: ?>

                    <!-- Cliente não logado -->

                    <a
                        class="nx-usuario"
                        href="<?= e(url('auth', 'form')) ?>"
                    >
                        <svg
                            viewBox="0 0 24 28"
                            width="22"
                            height="26"
                            aria-hidden="true"
                        >
                            <circle
                                cx="12"
                                cy="6.5"
                                r="5.5"
                                fill="currentColor"
                            />

                            <path
                                d="M2 16h20v6.5c0 2-2 3.5-4.5 3.5h-11C4 26 2 24.5 2 22.5z"
                                fill="currentColor"
                            />
                        </svg>

                        <span>Login</span>
                    </a>

                <?php endif; ?>

            </div>

        </div>

    </header>

    <!-- Conteúdo principal -->

    <main
        id="conteudo"
        class="<?= $paginaNex ? 'nx-main' : 'pagina' ?>"
    >

        <!-- Mensagens do sistema -->

        <?php foreach ($flashes as $f): ?>

            <?php
            if (
                !is_array($f) ||
                !isset($f['tipo'], $f['msg'])
            ) {
                continue;
            }
            ?>

            <div
                class="<?= $paginaNex
                    ? 'nx-aviso nx-aviso--'
                    : 'aviso aviso--' ?><?= e($f['tipo']) ?>"
                role="<?= $f['tipo'] === 'erro'
                    ? 'alert'
                    : 'status' ?>"
            >
                <?= e($f['msg']) ?>
            </div>

        <?php endforeach; ?>
