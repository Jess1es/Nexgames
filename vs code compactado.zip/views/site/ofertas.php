
<?php

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$produtos = isset($produtos) && is_array($produtos)
    ? $produtos
    : [];

$filtros = isset($filtros) && is_array($filtros)
    ? $filtros
    : [];

$filtros = array_merge([
    'categorias' => [],
    'desconto' => 0
], $filtros);

$marcadas = array_map(
    'intval',
    (array) $filtros['categorias']
);

$descontoSelecionado = (int) $filtros['desconto'];
?>

<!-- Banner de ofertas -->

<section class="banner-ofertas">
    <div>
        <h1>OFERTAS <span>IMPERDÍVEIS</span></h1>

        <p>
            Aproveite os melhores jogos por preços especiais.
        </p>

        <a
            class="botao botao--primario"
            href="#ofertas-semana"
        >
            VER JOGOS →
        </a>
    </div>
</section>

<div class="ofertas-layout">

    <!-- Filtros -->

    <form
        class="filtros"
        method="get"
        action="index.php"
        aria-label="Filtrar ofertas"
    >

        <input
            type="hidden"
            name="controller"
            value="loja"
        >

        <input
            type="hidden"
            name="action"
            value="ofertas"
        >

        <h2>Filtrar ofertas</h2>

        <!-- Categorias -->

        <fieldset>
            <legend>Categoria</legend>

            <?php foreach ($categorias as $cat): ?>

                <?php
                if (
                    !is_array($cat) ||
                    !isset($cat['id_categoria'], $cat['nome'])
                ) {
                    continue;
                }

                $categoriaId = (int) $cat['id_categoria'];

                $selecionada = in_array(
                    $categoriaId,
                    $marcadas,
                    true
                );
                ?>

                <label class="filtros__opcao">

                    <input
                        type="checkbox"
                        name="categoria[]"
                        value="<?= $categoriaId ?>"
                        <?= $selecionada ? 'checked' : '' ?>
                    >

                    <?= e($cat['nome']) ?>

                </label>

            <?php endforeach; ?>

        </fieldset>

        <!-- Faixa de desconto -->

        <fieldset>
            <legend>Faixa de desconto</legend>

            <label class="filtros__opcao">
                <input
                    type="radio"
                    name="desconto"
                    value="0"
                    <?= $descontoSelecionado === 0 ? 'checked' : '' ?>
                >
                Todas
            </label>

            <?php foreach ([20, 40, 50] as $faixa): ?>

                <label class="filtros__opcao">

                    <input
                        type="radio"
                        name="desconto"
                        value="<?= $faixa ?>"
                        <?= $descontoSelecionado === $faixa ? 'checked' : '' ?>
                    >

                    A partir de <?= $faixa ?>%

                </label>

            <?php endforeach; ?>

        </fieldset>

        <!-- Botões -->

        <button
            type="submit"
            class="botao botao--primario botao--cheio"
        >
            Aplicar filtros
        </button>

        <a
            class="link"
            href="<?= e(url('loja', 'ofertas')) ?>"
        >
            Limpar filtros
        </a>

    </form>

    <!-- Jogos em oferta -->

    <section
        id="ofertas-semana"
        aria-labelledby="t-semana"
    >

        <h2
            class="secao__titulo"
            id="t-semana"
        >
            Ofertas da semana
        </h2>

        <?php if (empty($produtos)): ?>

            <div class="vazio">

                <p>
                    Nenhuma oferta encontrada com esses filtros.
                </p>

                <a
                    class="botao botao--secundario"
                    href="<?= e(url('loja', 'ofertas')) ?>"
                >
                    Ver todas as ofertas
                </a>

            </div>

        <?php else: ?>

            <ul class="grade grade--3">

                <?php foreach ($produtos as $p): ?>

                    <?php
                    if (!is_array($p)) {
                        continue;
                    }

                    require __DIR__ . '/_card_jogo.php';
                    ?>

                <?php endforeach; ?>

            </ul>

        <?php endif; ?>

        <!-- Oferta relâmpago -->

        <aside
            class="faixa-relampago"
            aria-label="Oferta relâmpago"
        >

            <strong>
                ⚡ Oferta relâmpago
            </strong>

            <span>
                Termina em
                <time id="contagem" data-fim="hoje">
                    --:--:--
                </time>
            </span>

        </aside>

    </section>

</div>

<script>
/**
 * Contagem regressiva demonstrativa.
 * Reinicia diariamente e não depende do banco de dados.
 */

(function () {
    'use strict';

    const elemento = document.getElementById('contagem');

    if (!elemento) {
        return;
    }

    function doisDigitos(numero) {
        return String(numero).padStart(2, '0');
    }

    function atualizarContagem() {
        const agora = new Date();
        const fim = new Date(agora);

        fim.setHours(23, 59, 59, 999);

        const segundos = Math.max(
            0,
            Math.floor((fim - agora) / 1000)
        );

        const horas = Math.floor(segundos / 3600);
        const minutos = Math.floor((segundos % 3600) / 60);
        const segundosRestantes = segundos % 60;

        elemento.textContent = [
            doisDigitos(horas),
            doisDigitos(minutos),
            doisDigitos(segundosRestantes)
        ].join(':');
    }

    atualizarContagem();
    setInterval(atualizarContagem, 1000);
})();
</script>
