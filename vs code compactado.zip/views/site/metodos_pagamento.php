
<?php
$metodos = $metodos ?? [];

$nomesTipos = [
    'credito' => 'Cartão de crédito',
    'debito' => 'Cartão de débito',
    'pix' => 'Pix'
];
?>

<section class="banner-conta">
    <h1>Minha conta</h1>
    <p>
        Gerencie sua conta, seus jogos, pedidos e
        preferências na NEX Games.
    </p>
</section>

<div class="conta-layout">

    <aside class="conta-menu">
        <nav class="conta-menu__nav">

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'meusDados')) ?>"
            >
                Meu perfil
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('pedido', 'meusJogos')) ?>"
            >
                Meus jogos
            </a>

            <a
                class="conta-menu__link ativo"
                href="<?= e(url('cliente', 'metodosPagamento')) ?>"
                aria-current="page"
            >
                Método de pagamento
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'suporte')) ?>"
            >
                Suporte
            </a>

        </nav>
    </aside>

    <main class="conta-conteudo nx-metodos">

        <h2>Métodos de pagamento</h2>

        <p class="nx-metodos__descricao">
            Gerencie suas formas de pagamento e facilite
            suas próximas compras.
        </p>

        <div class="nx-metodos__painel">

            <?php if (empty($metodos)): ?>

                <p class="nx-metodos__vazio">
                    Você ainda não cadastrou nenhum
                    método de pagamento.
                </p>

            <?php else: ?>

                <?php foreach ($metodos as $metodo): ?>

                    <article class="nx-metodos__item">

                        <div class="nx-metodos__icone">
                            <?= $metodo['tipo'] === 'pix'
                                ? 'PIX'
                                : 'CARD' ?>
                        </div>

                        <div class="nx-metodos__info">

                            <h3>
                                <?= e(
                                    $nomesTipos[$metodo['tipo']]
                                    ?? 'Método de pagamento'
                                ) ?>
                            </h3>

                            <p>
                                <?= e($metodo['identificacao']) ?>
                            </p>

                            <?php if (
                                !empty($metodo['ultimos_digitos'])
                            ): ?>
                                <p>
                                    Final
                                    <?= e($metodo['ultimos_digitos']) ?>
                                </p>
                            <?php endif; ?>

                        </div>

                        <div class="nx-metodos__acoes">

                            <a href="<?= e(url(
                                'cliente',
                                'formularioPagamento',
                                ['id' => $metodo['id_metodo']]
                            )) ?>">
                                Editar
                            </a>

                            <form
                                method="post"
                                action="<?= e(url(
                                    'cliente',
                                    'excluirMetodoPagamento'
                                )) ?>"
                            >
                                <?= csrfCampo() ?>

                                <input
                                    type="hidden"
                                    name="id_metodo"
                                    value="<?= (int) $metodo['id_metodo'] ?>"
                                >

                                <button
                                    type="submit"
                                    onclick="return confirm('Excluir este método?')"
                                >
                                    Excluir
                                </button>
                            </form>

                        </div>

                    </article>

                <?php endforeach; ?>

            <?php endif; ?>

            <a
                class="nx-metodos__adicionar"
                href="<?= e(url(
                    'cliente',
                    'formularioPagamento'
                )) ?>"
            >
                Adicionar novo método de pagamento
            </a>

        </div>

    </main>

</div>
