
<?php
/**
 * NexGames - Mensagem de página vazia
 */

$mensagem = (string) ($mensagem ?? 'Nenhum jogo encontrado.');
?>

<div class="vazio">

    <p>
        <?= e($mensagem) ?>
    </p>

    <a
        class="botao botao--secundario"
        href="<?= e(url('loja', 'catalogo')) ?>"
    >
        Voltar para os jogos
    </a>

</div>
