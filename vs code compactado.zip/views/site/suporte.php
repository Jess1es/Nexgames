
<?php
?>

<section class="banner-conta">
    <h1>Minha conta</h1>

    <p>
        Gerencie sua conta, seus jogos, pedidos
        e preferências na NEX Games.
    </p>
</section>

<div class="conta-layout">

    <!-- MENU LATERAL -->

    <aside class="conta-menu">
        <nav class="conta-menu__nav">

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'meusDados')) ?>"
            >
                Meu perfil
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('pedido', 'meusJogos')) ?>"
            >
                Meus jogos
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'metodosPagamento')) ?>"
            >
                Método de pagamento
            </a>

            <a
                class="conta-menu__link ativo"
                href="<?= e(url('cliente', 'suporte')) ?>"
                aria-current="page"
            >
                Suporte
            </a>

        </nav>
    </aside>

    <!-- CONTEÚDO -->

    <section class="conta-conteudo nx-suporte">

        <h2>Suporte</h2>

        <p class="nx-suporte__descricao">
            Estamos aqui para ajudar com suas dúvidas
            sobre a NexGames.
        </p>

        <div class="nx-suporte__painel">

            <div class="nx-suporte__cabecalho">
                <h3>Como podemos te ajudar?</h3>

                <p>
                    Confira nossas formas de contato
                    e informações de atendimento.
                </p>
            </div>

            <div class="nx-suporte__grade">

                <!-- COLUNA ESQUERDA -->

                <div class="nx-suporte__topicos">

                    <article class="nx-suporte__topico">

                        <span
                            class="nx-suporte__bolinha"
                            aria-hidden="true"
                        ></span>

                        <div class="nx-suporte__texto">
                            <h4>Envie um e-mail</h4>

                            <p>
                                Descreva sua dúvida ou problema.
                                Nossa equipe responderá assim
                                que possível.
                            </p>
                        </div>

                    </article>

                    <article class="nx-suporte__topico">

                        <span
                            class="nx-suporte__bolinha"
                            aria-hidden="true"
                        ></span>

                        <div class="nx-suporte__texto">
                            <h4>Horário de atendimento</h4>

                            <p>
                                Atendimento de segunda a sexta,
                                das 8h às 22h.
                            </p>
                        </div>

                    </article>

                    <article class="nx-suporte__topico">

                        <span
                            class="nx-suporte__bolinha"
                            aria-hidden="true"
                        ></span>

                        <div class="nx-suporte__texto">
                            <h4>Dúvidas frequentes</h4>

                            <p>
                                Consulte nossa central de ajuda
                                para encontrar respostas às
                                perguntas mais comuns.
                            </p>
                        </div>

                    </article>

                </div>

                <!-- COLUNA DIREITA -->

                <aside class="nx-suporte__contato">

                    <div class="nx-suporte__contato-interno">

                        <div class="nx-suporte__icone">
                            <svg
                                viewBox="0 0 64 48"
                                width="90"
                                height="68"
                                aria-hidden="true"
                            >
                                <rect
                                    x="2"
                                    y="2"
                                    width="60"
                                    height="44"
                                    rx="4"
                                    fill="#21122f"
                                    stroke="#9146ff"
                                    stroke-width="2"
                                />

                                <path
                                    d="M3 6 L32 27 L61 6"
                                    fill="none"
                                    stroke="#9146ff"
                                    stroke-width="2"
                                />
                            </svg>
                        </div>

                        <h4>Nosso e-mail de suporte</h4>

                        <a
                            class="nx-suporte__email"
                            href="mailto:suportenexgames@gmail.com"
                        >
                            suportenexgames@gmail.com
                        </a>

                        <div class="nx-suporte__divisor"></div>

                        <p>
                            Ao enviar seu e-mail, informe
                            o máximo de detalhes possível
                            para que possamos te ajudar
                            mais rápido.
                        </p>

                        <a
                            class="nx-suporte__botao"
                            href="mailto:suportenexgames@gmail.com"
                        >
                            Enviar e-mail
                        </a>

                    </div>

                </aside>

            </div>

        </div>

    </section>

</div>
