
<?php

if (!isset($metodo) || !is_array($metodo)) {
    $metodo = [];
}

$metodo = array_merge([
    'id_metodo' => 0,
    'tipo' => 'credito',
    'identificacao' => '',
    'ultimos_digitos' => ''
], $metodo);

$erros = $erros ?? [];

$editando = (int) $metodo['id_metodo'] > 0;

$tipo = $metodo['tipo'] === 'pix'
    ? 'pix'
    : 'credito';

$identificacao = (string) $metodo['identificacao'];

$ultimosDigitos = (string) (
    $metodo['ultimos_digitos'] ?? ''
);
?>

<!-- BANNER MINHA CONTA -->

<section class="banner-conta">
    <h1>Minha conta</h1>

    <p>
        Gerencie sua conta, seus jogos, pedidos e
        preferências na NEX Games.
    </p>
</section>

<!-- LAYOUT PRINCIPAL -->

<div class="conta-layout">

    <!-- MENU LATERAL -->

    <aside class="conta-menu">
        <nav class="conta-menu__nav">

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'meusDados')) ?>"
            >
                Meu perfil
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('pedido', 'meusJogos')) ?>"
            >
                Meus jogos
            </a>

            <a
                class="conta-menu__link ativo"
                href="<?= e(url('cliente', 'metodosPagamento')) ?>"
            >
                Método de pagamento
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'suporte')) ?>"
            >
                Suporte
            </a>

        </nav>
    </aside>

    <!-- CONTEÚDO -->

    <section class="conta-conteudo nx-forma-pagamento">

        <h2>Métodos de pagamento</h2>

        <p class="nx-forma-pagamento__descricao">
            Confira e mantenha seus dados sempre atualizados.
        </p>

        <!-- FORMULÁRIO -->

        <form
            class="nx-forma-pagamento__form"
            action="<?= e(url(
                'cliente',
                'formularioPagamento',
                $editando
                    ? ['id' => (int) $metodo['id_metodo']]
                    : []
            )) ?>"
            method="post"
        >

            <?= csrfCampo() ?>

            <!-- ERROS -->

            <?php if (!empty($erros)): ?>

                <div class="nx-forma-pagamento__erro">

                    <?php foreach ($erros as $mensagem): ?>

                        <p>
                            <?= e($mensagem) ?>
                        </p>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

            <!-- SELEÇÃO DO MÉTODO -->

            <div class="nx-forma-pagamento__tipos">

                <label class="nx-forma-pagamento__opcao">

                    <input
                        type="radio"
                        name="tipo"
                        value="credito"
                        <?= $tipo === 'credito' ? 'checked' : '' ?>
                    >

                    <span>
                        Cartão de crédito
                    </span>

                </label>

                <label class="nx-forma-pagamento__opcao">

                    <input
                        type="radio"
                        name="tipo"
                        value="pix"
                        <?= $tipo === 'pix' ? 'checked' : '' ?>
                    >

                    <span>
                        Pix
                    </span>

                </label>

            </div>

            <!-- CAMPOS DO CARTÃO -->

            <div class="nx-forma-pagamento__cartao">

                <!-- NOME DO CARTÃO -->

                <div class="nx-forma-pagamento__campo">

                    <label for="identificacao">
                        Nome no cartão
                    </label>

                    <input
                        type="text"
                        id="identificacao"
                        name="identificacao"
                        maxlength="100"
                        value="<?= e($identificacao) ?>"
                        placeholder="Ex.: Meu cartão principal"
                        autocomplete="off"
                    >

                </div>

                <!-- NÚMERO DO CARTÃO -->

                <div class="nx-forma-pagamento__campo">

                    <label for="numero_cartao">
                        Número do cartão
                    </label>

                    <?php if ($editando): ?>

                        <input
                            type="text"
                            id="numero_cartao"
                            value="**** **** **** <?= e($ultimosDigitos) ?>"
                            disabled
                        >

                        <small>
                            Para alterar o número,
                            cadastre um novo cartão.
                        </small>

                    <?php else: ?>

                        <input
                            type="text"
                            id="numero_cartao"
                            name="numero_cartao"
                            placeholder="Ex.: 1234 5678 9012 3456"
                            inputmode="numeric"
                            pattern="[0-9]{16}|[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}"
                            maxlength="19"
                            autocomplete="off"
                            title="Digite 16 números demonstrativos, com ou sem espaços."
                        >

                        <small>
                            Use 16 dígitos.
                        </small>

                    <?php endif; ?>

                </div>

                <!-- PARCELAMENTO -->

                <div class="nx-forma-pagamento__campo">

                    <label for="parcelamento_visual">
                        Parcelamento
                    </label>

                    <select
                        id="parcelamento_visual"
                        disabled
                    >
                        <option>
                            Até 6x sem juros nas compras
                        </option>
                    </select>

                </div>

                <!-- CVV E VALIDADE -->

                <div class="nx-forma-pagamento__linha">

                    <div class="nx-forma-pagamento__campo">

                        <label for="codigo_visual">
                            Código de segurança (CVV)
                        </label>

                        <input
                            type="text"
                            id="codigo_visual"
                            value="Não armazenado"
                            disabled
                        >

                    </div>

                    <div class="nx-forma-pagamento__campo">

                        <label for="validade_visual">
                            Validade
                        </label>

                        <input
                            type="text"
                            id="validade_visual"
                            value="Não armazenada"
                            disabled
                        >

                    </div>

                </div>

            </div>

            <!-- ÁREA DO PIX -->

            <div class="nx-forma-pagamento__pix">

                <div class="nx-forma-pagamento__pix-conteudo">

                    <h3>
                        Pagamento via Pix
                    </h3>

                    <p>
                        Escaneie o QR Code abaixo
                        para visualizar o pagamento demonstrativo.
                    </p>

                    <!-- QR CODE -->

                    <div class="nx-forma-pagamento__qrcode">

                        <img
                            src="/public/assets/img/qrcode-pix.png"
                            alt="QR Code demonstrativo do Pix NexGames"
                            width="210"
                        >

                    </div>

                    <p>
                        O Pix ficará salvo como método
                        de pagamento da sua conta.
                    </p>

                    <p>
                        Você poderá selecioná-lo nas próximas
                        compras da NexGames.
                    </p>

                </div>

            </div>

            <!-- BOTÃO SALVAR -->

            <button
                type="submit"
                class="nx-forma-pagamento__salvar"
            >
                <?= $editando
                    ? 'Salvar alterações'
                    : 'Adicionar novo método de pagamento' ?>
            </button>

            <!-- VOLTAR -->

            <a
                class="nx-forma-pagamento__voltar"
                href="<?= e(url('cliente', 'metodosPagamento')) ?>"
            >
                ← Voltar aos métodos de pagamento
            </a>

        </form>

    </section>

</div>
