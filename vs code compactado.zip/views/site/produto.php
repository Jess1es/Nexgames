
<?php

$produto = isset($produto) && is_array($produto)
    ? $produto
    : [];

$idProduto = (int) (
    $produto['id_produto'] ??
    $produto['id'] ??
    0
);

$nome = (string) ($produto['nome'] ?? 'Jogo');
$descricao = trim((string) ($produto['descricao'] ?? ''));

/* Imagem */

$imagem = isset($imagem) && $imagem !== ''
    ? (string) $imagem
    : imagemProduto($idProduto, $produto['imagem'] ?? null);

/* Preços */

$precoCheio = (float) (
    $precoCheio ??
    $produto['preco'] ??
    0
);

$emOferta = isset($emOferta)
    ? (bool) $emOferta
    : (
        (int) ($produto['em_oferta'] ?? 0) === 1 &&
        ($produto['preco_promocional'] ?? null) !== null
    );

$preco = isset($preco)
    ? (float) $preco
    : (float) (
        $produto['preco_final'] ??
        (
            $emOferta
                ? $produto['preco_promocional']
                : $precoCheio
        )
    );

$precoFormatado = number_format($preco, 2, ',', '.');
$precoCheioFormatado = number_format($precoCheio, 2, ',', '.');

/* Verificar se o cliente já possui o jogo */

$jaPossuiJogo = false;

if (!empty($_SESSION['cliente_id']) && $idProduto > 0) {
    $jaPossuiJogo = (new Carrinho())->jaPossui($idProduto);
}

/* Categorias */

$categoriasJogo = [];

if (!empty($produto['categorias']) && is_array($produto['categorias'])) {
    foreach ($produto['categorias'] as $categoria) {
        if (is_array($categoria) && !empty($categoria['nome'])) {
            $categoriasJogo[] = (string) $categoria['nome'];
        } elseif (is_string($categoria)) {
            $categoriasJogo[] = $categoria;
        }
    }
}

if (empty($categoriasJogo)) {
    $nomesCategorias = (string) (
        $produto['categorias_nomes'] ??
        $produto['categorias_nome'] ??
        ''
    );

    if ($nomesCategorias !== '') {
        $categoriasJogo = array_map(
            'trim',
            explode(',', $nomesCategorias)
        );
    }
}

$categoriasJogo = array_values(
    array_unique(array_filter($categoriasJogo))
);

/* Avaliações */

$avaliacoes = isset($avaliacoes) && is_array($avaliacoes)
    ? $avaliacoes
    : [];

$minhaAvaliacao = $minhaAvaliacao ?? null;

$podeAvaliar = $jaPossuiJogo && $minhaAvaliacao === null;
?>

<style>
    /* Galeria */

    .nx-detalhe .nx-detalhe__galeria {
        width: 100%;
        min-width: 0;
    }

    .nx-detalhe .nx-detalhe__capa {
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 450px;
        max-height: 450px;
        overflow: hidden;
        border: 2px solid #9146ff;
        border-radius: 9px;
        background: #18121f;
    }

    .nx-detalhe .nx-detalhe__capa img {
        display: block;
        width: 100%;
        height: 100%;
        max-width: 100%;
        max-height: 100%;
        min-width: 0;
        min-height: 0;
        object-fit: contain;
        object-position: center;
        margin: 0;
        padding: 0;
    }

    .nx-detalhe .nx-detalhe__miniaturas {
        display: none !important;
    }

    /* Jogo adquirido */

    .nx-detalhe__botao--adquirido {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        min-height: 52px;
        padding: 14px;
        background: #7425e8;
        border: 1px solid #9146ff;
        border-radius: 8px;
        color: #ffffff;
        text-align: center;
        text-decoration: none;
        font-weight: 700;
    }

    .nx-detalhe__botao--adquirido:hover {
        background: #9146ff;
        color: #ffffff;
    }

    /* Avaliações */

    .nx-avaliacao-formulario,
    .nx-avaliacao-card,
    .nx-avaliacao-aviso {
        background: #18121f;
        border: 1px solid #49325d;
        border-radius: 10px;
        padding: 20px;
        margin: 18px 0;
    }

    .nx-avaliacao-formulario form {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .nx-avaliacao-formulario h3 {
        margin-top: 0;
    }

    .nx-avaliacao-notas {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        border: 0;
        padding: 0;
        margin: 0;
    }

    .nx-avaliacao-notas legend {
        font-weight: 700;
        margin-bottom: 10px;
    }

    .nx-avaliacao-notas label {
        color: #f4c542;
        cursor: pointer;
    }

    .nx-avaliacao-notas input {
        accent-color: #9146ff;
    }

    .nx-avaliacao-formulario textarea {
        box-sizing: border-box;
        width: 100%;
        background: #100c16;
        color: #ffffff;
        border: 1px solid #6a4a88;
        border-radius: 8px;
        padding: 12px;
        font: inherit;
        resize: vertical;
    }

    .nx-avaliacao-enviar {
        background: #7825e8;
        border: 0;
        border-radius: 8px;
        color: #ffffff;
        padding: 14px 20px;
        font: inherit;
        font-weight: 700;
        cursor: pointer;
    }

    .nx-avaliacao-enviar:hover {
        background: #9146ff;
    }

    .nx-avaliacoes-lista {
        margin-top: 30px;
    }

    .nx-avaliacao-card__topo {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
    }

    .nx-avaliacao-card__topo span {
        color: #b7a8c7;
        font-size: 0.9rem;
    }

    .nx-avaliacao-card__estrelas {
        color: #f4c542;
        font-size: 24px;
        margin: 12px 0;
        letter-spacing: 2px;
    }

    .nx-avaliacao-card p {
        overflow-wrap: anywhere;
    }

    /* Responsividade */

    @media (max-width: 768px) {
        .nx-detalhe .nx-detalhe__capa {
            height: 320px;
            max-height: 320px;
        }
    }

    @media (max-width: 480px) {
        .nx-detalhe .nx-detalhe__capa {
            height: 260px;
            max-height: 260px;
        }
    }
</style>

<div class="nx-detalhe">

    <!-- Voltar ao catálogo -->

    <div class="nx-detalhe__voltar">
        <a href="<?= e(url('loja', 'catalogo')) ?>">
            &larr; Voltar aos jogos
        </a>
    </div>

    <!-- Cabeçalho -->

    <div class="nx-detalhe__cabecalho">

        <h1><?= e($nome) ?></h1>

        <?php if ($emOferta): ?>
            <span class="nx-detalhe__oferta">
                EM OFERTA
            </span>
        <?php endif; ?>

    </div>

    <!-- Imagem e compra -->

    <section class="nx-detalhe__principal nx-detalhe__principal--simples">

        <div class="nx-detalhe__galeria">

            <div class="nx-detalhe__capa">
                <img
                    src="<?= e($imagem) ?>"
                    alt="Capa do jogo <?= e($nome) ?>"
                >
            </div>

        </div>

        <aside class="nx-detalhe__compra">

            <div class="nx-detalhe__precos">

                <span class="nx-detalhe__preco-label">
                    Valor do jogo
                </span>

                <?php if ($emOferta): ?>
                    <del class="nx-detalhe__preco-antigo">
                        R$ <?= $precoCheioFormatado ?>
                    </del>
                <?php endif; ?>

                <strong class="nx-detalhe__preco-atual">
                    R$ <?= $precoFormatado ?>
                </strong>

            </div>

            <!-- Disponibilidade -->

            <p class="nx-detalhe__disponibilidade">

                <span class="nx-detalhe__status-ponto"></span>

                <?= $jaPossuiJogo
                    ? 'Você já possui este jogo'
                    : 'Disponível para comprar' ?>

            </p>

            <?php if ($jaPossuiJogo): ?>

                <!-- Jogo adquirido -->

                <a
                    href="<?= e(url('pedido', 'meusJogos')) ?>"
                    class="nx-detalhe__botao nx-detalhe__botao--adquirido"
                >
                    Acessar meus jogos
                </a>

            <?php else: ?>

                <!-- Adicionar ao carrinho -->

                <form
                    action="<?= e(url('carrinho', 'adicionar')) ?>"
                    method="post"
                >

                    <?= csrfCampo() ?>

                    <input
                        type="hidden"
                        name="produto_id"
                        value="<?= $idProduto ?>"
                    >

                    <button
                        type="submit"
                        class="nx-detalhe__botao nx-detalhe__botao--principal"
                    >
                        Adicionar ao carrinho
                    </button>

                </form>

                <!-- Comprar agora -->

                <form
                    action="<?= e(url('carrinho', 'adicionar')) ?>"
                    method="post"
                >

                    <?= csrfCampo() ?>

                    <input
                        type="hidden"
                        name="produto_id"
                        value="<?= $idProduto ?>"
                    >

                    <input
                        type="hidden"
                        name="comprar_agora"
                        value="1"
                    >

                    <button
                        type="submit"
                        class="nx-detalhe__botao nx-detalhe__botao--secundario"
                    >
                        Compre agora
                    </button>

                </form>

            <?php endif; ?>

        </aside>

    </section>

    <!-- Informações do jogo -->

    <section class="nx-detalhe__informacoes">

        <nav
            class="nx-detalhe__abas"
            aria-label="Informações do jogo"
        >
            <a href="#descricao" class="ativo">
                Descrição
            </a>

            <a href="#avaliacoes">
                Avaliações
            </a>
        </nav>

        <!-- Descrição -->

        <div id="descricao" class="nx-detalhe__secao">

            <div class="nx-detalhe__descricao-grid nx-detalhe__descricao-grid--simples">

                <div class="nx-detalhe__sobre">

                    <h2>Sobre o jogo</h2>

                    <p>
                        <?= nl2br(e(
                            $descricao !== ''
                                ? $descricao
                                : 'Descrição ainda não disponível.'
                        )) ?>
                    </p>

                </div>

                <!-- Categorias -->

                <div class="nx-detalhe__categorias">

                    <h2>Categorias</h2>

                    <?php if (!empty($categoriasJogo)): ?>

                        <div class="nx-detalhe__lista-categorias">

                            <?php foreach ($categoriasJogo as $categoria): ?>

                                <span>
                                    <?= e($categoria) ?>
                                </span>

                            <?php endforeach; ?>

                        </div>

                    <?php else: ?>

                        <p>Nenhuma categoria informada.</p>

                    <?php endif; ?>

                </div>

            </div>

        </div>

        <!-- Avaliações -->

        <div id="avaliacoes" class="nx-detalhe__secao">

            <h2>Avaliações dos jogadores</h2>

            <?php if ($podeAvaliar): ?>

                <!-- Formulário de avaliação -->

                <div class="nx-avaliacao-formulario">

                    <h3>Avalie este jogo</h3>

                    <p>
                        Você já possui este jogo!
                        Conte o que achou.
                    </p>

                    <form
                        action="<?= e(url('avaliacao', 'salvar')) ?>"
                        method="post"
                    >

                        <?= csrfCampo() ?>

                        <input
                            type="hidden"
                            name="produto_id"
                            value="<?= $idProduto ?>"
                        >

                        <fieldset class="nx-avaliacao-notas">

                            <legend>Sua nota</legend>

                            <?php for ($estrela = 1; $estrela <= 5; $estrela++): ?>

                                <label>
                                    <input
                                        type="radio"
                                        name="nota"
                                        value="<?= $estrela ?>"
                                        required
                                    >
                                    <?= $estrela ?> ★
                                </label>

                            <?php endfor; ?>

                        </fieldset>

                        <label for="comentario-avaliacao">
                            Comentário (opcional)
                        </label>

                        <textarea
                            id="comentario-avaliacao"
                            name="comentario"
                            maxlength="1000"
                            rows="5"
                            placeholder="O que você achou deste jogo?"
                        ></textarea>

                        <button
                            type="submit"
                            class="nx-avaliacao-enviar"
                        >
                            Publicar avaliação
                        </button>

                    </form>

                </div>

            <?php elseif ($minhaAvaliacao !== null): ?>

                <p class="nx-avaliacao-aviso">
                    Você já avaliou este jogo.
                    Obrigado por compartilhar sua opinião!
                </p>

            <?php elseif (empty($_SESSION['cliente_id'])): ?>

                <p class="nx-avaliacao-aviso">
                    Entre na sua conta para avaliar
                    os jogos que você já comprou.
                </p>

            <?php else: ?>

                <p class="nx-avaliacao-aviso">
                    Somente clientes que já possuem
                    este jogo, com pagamento aprovado,
                    podem avaliá-lo.
                </p>

            <?php endif; ?>

            <!-- Lista de avaliações -->

            <div class="nx-avaliacoes-lista">

                <h3>
                    Opiniões dos jogadores
                    (<?= count($avaliacoes) ?>)
                </h3>

                <?php if (empty($avaliacoes)): ?>

                    <p>
                        Este jogo ainda não recebeu avaliações.
                    </p>

                <?php else: ?>

                    <?php foreach ($avaliacoes as $avaliacao): ?>

                        <?php
                        if (!is_array($avaliacao)) {
                            continue;
                        }

                        $notaAvaliacao = (int) (
                            $avaliacao['nota'] ?? 0
                        );

                        $comentarioAvaliacao = trim(
                            (string) ($avaliacao['comentario'] ?? '')
                        );

                        $nomeAvaliador = (string) (
                            $avaliacao['cliente_nome'] ?? 'Jogador'
                        );

                        $timestampAvaliacao = strtotime(
                            (string) ($avaliacao['data_avaliacao'] ?? '')
                        );

                        $dataAvaliacao = $timestampAvaliacao
                            ? date('d/m/Y', $timestampAvaliacao)
                            : '';
                        ?>

                        <article class="nx-avaliacao-card">

                            <div class="nx-avaliacao-card__topo">

                                <strong>
                                    <?= e($nomeAvaliador) ?>
                                </strong>

                                <span>
                                    <?= e($dataAvaliacao) ?>
                                </span>

                            </div>

                            <!-- Estrelas -->

                            <div
                                class="nx-avaliacao-card__estrelas"
                                aria-label="<?= $notaAvaliacao ?> de 5 estrelas"
                            >

                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?= $i <= $notaAvaliacao ? '★' : '☆' ?>
                                <?php endfor; ?>

                            </div>

                            <!-- Comentário -->

                            <?php if ($comentarioAvaliacao !== ''): ?>

                                <p>
                                    <?= nl2br(e($comentarioAvaliacao)) ?>
                                </p>

                            <?php endif; ?>

                        </article>

                    <?php endforeach; ?>

                <?php endif; ?>

            </div>

        </div>

    </section>

</div>
