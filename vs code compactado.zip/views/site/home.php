
<?php

$modoLista = (bool) ($modoLista ?? false);

$produtos = isset($produtos) && is_array($produtos)
    ? $produtos
    : [];

$destaques = isset($destaques) && is_array($destaques)
    ? $destaques
    : [];

$ofertas = isset($ofertas) && is_array($ofertas)
    ? $ofertas
    : [];

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$filtros = isset($filtros) && is_array($filtros)
    ? $filtros
    : [];

$filtros = array_merge([
    'oferta' => 0,
    'busca' => '',
    'categoria_id' => 0
], $filtros);

$total = (int) ($total ?? 0);
$pagina = max(1, (int) ($pagina ?? 1));
$paginas = max(1, (int) ($paginas ?? 1));

$emOfertas = !empty($filtros['oferta']);
$busca = trim((string) $filtros['busca']);

$categoriaNome = $categoriaNome ?? null;

/**
 * Renderiza o card de um jogo.
 */

$renderizarJogo = static function (array $p): void {

    $id = (int) (
        $p['id'] ??
        $p['id_produto'] ??
        0
    );

    $nome = (string) ($p['nome'] ?? 'Jogo sem nome');
    $imagem = (string) ($p['imagem'] ?? '');

    $preco = (float) ($p['preco'] ?? 0);

    $precoFinal = (float) (
        $p['preco_final'] ??
        (
            !empty($p['em_oferta']) &&
            isset($p['preco_promocional'])
                ? $p['preco_promocional']
                : $preco
        )
    );

    $temDesconto = (
        $preco > 0 &&
        $precoFinal >= 0 &&
        $precoFinal < $preco
    );

    $desconto = $temDesconto
        ? (int) round((1 - $precoFinal / $preco) * 100)
        : 0;

    $categoriasJogo = (string) (
        $p['categorias_nome'] ??
        $p['categorias_nomes'] ??
        ''
    );
    ?>

    <li class="nx-card">

        <a
            class="nx-card__link"
            href="<?= e(url('loja', 'produto', ['id' => $id])) ?>"
        >

            <div class="nx-card__imagem">

                <?php if ($imagem !== ''): ?>

                    <img
                        src="<?= e($imagem) ?>"
                        alt="Capa de <?= e($nome) ?>"
                        loading="lazy"
                    >

                <?php endif; ?>

                <?php if ($temDesconto): ?>

                    <span class="nx-card__desconto">
                        -<?= $desconto ?>%
                    </span>

                <?php endif; ?>

            </div>

            <div class="nx-card__conteudo">

                <h3 class="nx-card__nome">
                    <?= e($nome) ?>
                </h3>

                <?php if ($categoriasJogo !== ''): ?>

                    <p class="nx-card__categorias">
                        <?= e($categoriasJogo) ?>
                    </p>

                <?php endif; ?>

                <div class="nx-card__precos">

                    <?php if ($temDesconto): ?>

                        <span class="nx-card__preco-antigo">
                            <?= e(moeda($preco)) ?>
                        </span>

                    <?php endif; ?>

                    <strong class="nx-card__preco">
                        <?= e(moeda($precoFinal)) ?>
                    </strong>

                </div>

            </div>

        </a>

    </li>

<?php
};
?>

<?php if (!$modoLista): ?>

    <!-- Banner principal -->

    <section
        class="nx-banner-principal"
        aria-label="Anúncios de jogos"
    >

        <div class="nx-banner-principal__carrossel">

            <div class="nx-banner-principal__slide">
                <img
                    src="public/assets/img/banner-gta6.png"
                    alt="Grand Theft Auto VI em destaque"
                >
            </div>

            <div class="nx-banner-principal__slide">
                <img
                    src="public/assets/img/fnaf-banner.png"
                    alt="Five Nights at Freddy's"
                >
            </div>

            <div class="nx-banner-principal__slide">
                <img
                    src="public/assets/img/Naruto e Sasuke-banner.png"
                    alt="Naruto Ultimate Ninja Storm"
                >
            </div>

        </div>

        <div
            class="nx-banner-principal__indicadores"
            aria-hidden="true"
        >
            <span></span>
            <span></span>
            <span></span>
        </div>

    </section>

    <!-- Categorias -->

    <section
        class="nx-secao"
        aria-labelledby="t-categorias"
    >

        <div class="nx-secao__topo">

            <h2
                class="nx-secao__titulo"
                id="t-categorias"
            >
                Explore por categoria
            </h2>

            <a
                class="nx-secao__ver"
                href="<?= e(url('loja', 'catalogo')) ?>"
            >
                Ver todas →
            </a>

        </div>

        <?php if (!empty($categorias)): ?>

            <ul class="nx-categorias">

                <?php foreach (array_slice($categorias, 0, 5) as $cat): ?>

                    <?php
                    if (
                        !is_array($cat) ||
                        !isset($cat['nome'])
                    ) {
                        continue;
                    }

                    $categoriaId = (int) (
                        $cat['id_categoria'] ??
                        $cat['id'] ??
                        0
                    );

                    if ($categoriaId <= 0) {
                        continue;
                    }
                    ?>

                    <li>
                        <a
                            class="nx-categoria"
                            href="<?= e(url(
                                'loja',
                                'catalogo',
                                ['categoria_id' => $categoriaId]
                            )) ?>"
                        >
                            <?= e($cat['nome']) ?>
                        </a>
                    </li>

                <?php endforeach; ?>

            </ul>

        <?php else: ?>

            <p class="nx-vazio">
                Nenhuma categoria disponível.
            </p>

        <?php endif; ?>

    </section>

    <!-- Jogos em destaque -->

    <section
        class="nx-secao"
        aria-labelledby="t-destaques"
    >

        <div class="nx-secao__topo">

            <h2
                class="nx-secao__titulo"
                id="t-destaques"
            >
                Jogos em destaque
            </h2>

        </div>

        <?php if (!empty($destaques)): ?>

            <ul class="nx-grade nx-grade--destaques">

                <?php foreach ($destaques as $p): ?>

                    <?php
                    if (is_array($p)) {
                        $renderizarJogo($p);
                    }
                    ?>

                <?php endforeach; ?>

            </ul>

        <?php else: ?>

            <div class="nx-vazio nx-vazio--caixa">
                <p>Ainda não há jogos cadastrados.</p>
            </div>

        <?php endif; ?>

    </section>

    <!-- Ofertas especiais -->

    <section
        class="nx-secao nx-secao--ofertas"
        aria-labelledby="t-ofertas"
    >

        <div class="nx-secao__topo">

            <h2
                class="nx-secao__titulo"
                id="t-ofertas"
            >
                Ofertas especiais
            </h2>

            <a
                class="nx-secao__ver"
                href="<?= e(url('loja', 'ofertas')) ?>"
            >
                Ver ofertas →
            </a>

        </div>

        <!-- Banners de ofertas -->

        <div class="nx-banner-ofertas">

            <div class="nx-banner-ofertas__carrossel">

                <!-- Minecraft -->

                <div class="nx-banner-ofertas__slide">

                    <a href="<?= e(url('loja', 'ofertas')) ?>">

                        <img
                            src="public/assets/img/banner-Ofertas-mine.png"
                            alt="Minecraft — Ofertas especiais"
                        >

                    </a>

                </div>

                <!-- The Last of Us Part II -->

                <div class="nx-banner-ofertas__slide">

                    <a href="<?= e(url('loja', 'ofertas')) ?>">

                        <img
                            src="public/assets/img/banner-Ofertas-the.png"
                            alt="The Last of Us Part II em oferta"
                        >

                    </a>

                </div>

            </div>

            <div
                class="nx-banner-ofertas__indicadores"
                aria-hidden="true"
            >
                <span></span>
                <span></span>
            </div>

        </div>

        <!-- Jogos em oferta cadastrados no banco -->

        <?php if (!empty($ofertas)): ?>

            <div class="nx-ofertas-jogos">

                <h3>Jogos com desconto</h3>

                <ul class="nx-ofertas-jogos__lista">

                    <?php foreach ($ofertas as $o): ?>

                        <?php
                        if (!is_array($o)) {
                            continue;
                        }

                        $idOferta = (int) (
                            $o['id_produto'] ??
                            $o['id'] ??
                            0
                        );

                        $nomeOferta = (string) (
                            $o['nome'] ?? 'Jogo sem nome'
                        );

                        $precoNormal = (float) (
                            $o['preco'] ?? 0
                        );

                        $precoOferta = (float) (
                            $o['preco_final'] ??
                            (
                                !empty($o['em_oferta']) &&
                                isset($o['preco_promocional'])
                                    ? $o['preco_promocional']
                                    : $precoNormal
                            )
                        );

                        $desconto = (
                            $precoNormal > 0 &&
                            $precoOferta >= 0 &&
                            $precoOferta < $precoNormal
                        )
                            ? (int) round(
                                (1 - $precoOferta / $precoNormal) * 100
                            )
                            : 0;
                        ?>

                        <li>

                            <a
                                href="<?= e(url(
                                    'loja',
                                    'produto',
                                    ['id' => $idOferta]
                                )) ?>"
                            >

                                <span class="nx-ofertas-jogos__nome">
                                    <?= e($nomeOferta) ?>
                                </span>

                                <strong class="nx-ofertas-jogos__preco">
                                    <?= e(moeda($precoOferta)) ?>
                                </strong>

                                <?php if ($desconto > 0): ?>

                                    <span class="nx-ofertas-jogos__desconto">
                                        -<?= $desconto ?>%
                                    </span>

                                <?php endif; ?>

                            </a>

                        </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php endif; ?>

    </section>

<?php else: ?>

    <!-- Catálogo de jogos -->

    <section
        class="nx-secao nx-secao--catalogo"
        aria-labelledby="t-catalogo"
    >

        <div class="nx-secao__topo">

            <h1
                class="nx-secao__titulo"
                id="t-catalogo"
            >

                <?php if ($emOfertas): ?>

                    Jogos em oferta

                <?php elseif (!empty($filtros['categoria_id'])): ?>

                    <?= e(
                        $categoriaNome ??
                        'Categoria não encontrada'
                    ) ?>

                <?php elseif ($busca !== ''): ?>

                    Resultados da pesquisa

                <?php else: ?>

                    Todos os jogos

                <?php endif; ?>

            </h1>

        </div>

        <?php if ($busca !== ''): ?>

            <p class="nx-catalogo__busca">
                Pesquisa por: <?= e($busca) ?>
            </p>

        <?php endif; ?>

        <p class="nx-catalogo__total">
            <?= $total ?>
            <?= $total === 1
                ? 'jogo encontrado.'
                : 'jogos encontrados.' ?>
        </p>

        <!-- Lista de produtos -->

        <?php if (!empty($produtos)): ?>

            <ul class="nx-grade nx-grade--catalogo">

                <?php foreach ($produtos as $p): ?>

                    <?php
                    if (is_array($p)) {
                        $renderizarJogo($p);
                    }
                    ?>

                <?php endforeach; ?>

            </ul>

        <?php else: ?>

            <div class="nx-vazio nx-vazio--caixa">
                <p>Nenhum jogo encontrado.</p>
            </div>

        <?php endif; ?>

        <!-- Paginação -->

        <?php if ($paginas > 1): ?>

            <nav
                class="nx-paginacao"
                aria-label="Paginação do catálogo"
            >

                <?php for ($numero = 1; $numero <= $paginas; $numero++): ?>

                    <?php
                    $parametros = array_filter([
                        'categoria_id' => !empty($filtros['categoria_id'])
                            ? (int) $filtros['categoria_id']
                            : null,
                        'q' => $busca !== '' ? $busca : null,
                        'oferta' => $emOfertas ? 1 : null,
                        'pagina' => $numero
                    ], static fn($valor) => $valor !== null);
                    ?>

                    <a
                        class="<?= $numero === $pagina ? 'ativo' : '' ?>"
                        href="<?= e(url(
                            'loja',
                            'catalogo',
                            $parametros
                        )) ?>"
                        <?= $numero === $pagina
                            ? 'aria-current="page"'
                            : '' ?>
                    >
                        <?= $numero ?>
                    </a>

                <?php endfor; ?>

            </nav>

        <?php endif; ?>

    </section>

<?php endif; ?>
