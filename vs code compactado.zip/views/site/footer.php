</main>


<footer class="rodape">
  <div class="rodape__colunas">
    <div class="rodape__marca">
      <span class="marca__logo">NE<b>X</b></span>
      <span class="marca__sub">Gaming Store</span>
      <p class="rodape__slogan">Onde sua próxima aventura começa.</p>
    </div>


    <nav aria-label="Links">
      <h2>Links</h2>
      <a href="<?= e(url('loja', 'index')) ?>">Início</a>
      <a href="<?= e(url('loja', 'catalogo')) ?>">Todos os jogos</a>
      <a href="<?= e(url('loja', 'ofertas')) ?>">Ofertas</a>
      <a href="<?= e(url('carrinho', 'index')) ?>">Carrinho</a>
    </nav>


    <nav aria-label="Suporte">
      <h2>Suporte</h2>
      <a href="<?= e(url('cliente', 'suporte')) ?>">Central de ajuda</a>
      <a href="mailto:suportenexgames@gmail.com">suportenexgames@gmail.com</a>
      <span>Seg. a sex., das 8h às 22h</span>
    </nav>


    <nav aria-label="Siga-nos">
      <h2>Siga-nos</h2>
      <!-- troque o # pelos links reais das redes -->
      <a href="#">Instagram</a>
      <a href="#">Discord</a>
      <a href="#">YouTube</a>
    </nav>
  </div>
  <p class="rodape__nota">Projeto acadêmico — imagens e preços de demonstração.</p>
</footer>


<script src="public/assets/js/loja.js"></script>
</body>
</html>


