
</main>

<footer
    class="nx-rodape"
    style="
        width: 100%;
        background: #100b19;
        border-top: 2px solid #9146ff;
        padding: 35px 20px 20px;
        text-align: center;
        font-family: 'Roboto Mono', monospace;
        box-sizing: border-box;
    "
>
    <h2
        style="
            color: #c084fc;
            font-size: 20px;
            letter-spacing: 3px;
            margin: 0 0 10px;
        "
    >
        NEXGAMES
    </h2>

    <p
        style="
            color: #f3eaff;
            font-size: 13px;
            margin: 0;
        "
    >
        Onde sua próxima aventura começa.
    </p>

    <div
        style="
            height: 1px;
            background: #39244d;
            margin: 25px 0 15px;
        "
    ></div>

    <p
        style="
            color: #a99ab9;
            font-size: 11px;
            margin: 0;
        "
    >
        © 2026 NexGames
    </p>
</footer>

</body>
</html>
