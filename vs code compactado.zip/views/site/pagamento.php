
<?php

if (!isset($carrinho) || !($carrinho instanceof Carrinho)) {
    $carrinho = new Carrinho();
}

$metodosSalvos = isset($metodosSalvos) && is_array($metodosSalvos)
    ? $metodosSalvos
    : [];

$erro = (string) ($erro ?? '');

$itensCarrinho = $carrinho->itens();
$total = (float) $carrinho->total();

$subtotalBruto = 0.0;
$descontoTotal = 0.0;

/* Cálculo dos valores */

foreach ($itensCarrinho as $item) {
    $precoOriginal = (float) (
        $item['preco_original'] ??
        $item['preco_unitario'] ??
        0
    );

    $precoAtual = (float) ($item['preco_unitario'] ?? 0);
    $quantidade = (int) ($item['quantidade'] ?? 1);

    $subtotalBruto += $precoOriginal * $quantidade;

    $descontoTotal += max(
        0,
        $precoOriginal - $precoAtual
    ) * $quantidade;
}

/* Nomes dos métodos de pagamento */

$nomesTipos = [
    'credito' => 'Cartão de crédito',
    'debito' => 'Cartão de débito',
    'pix' => 'Pix'
];

/* Primeiro método salvo */

$primeiroSalvo = 0;

foreach ($metodosSalvos as $metodo) {
    if (is_array($metodo) && !empty($metodo['id_metodo'])) {
        $primeiroSalvo = (int) $metodo['id_metodo'];
        break;
    }
}
?>

<div class="nx-checkout">

    <!-- Cabeçalho -->

    <header class="nx-checkout__cabecalho">
        <h1>PAGAMENTO</h1>
        <p>Escolha a forma de pagamento e finalize sua compra.</p>
    </header>

    <div class="nx-checkout__layout">

        <!-- Formulário de pagamento -->

        <form
            class="nx-checkout__form"
            action="<?= e(url('pedido', 'finalizar')) ?>"
            method="post"
        >

            <?= csrfCampo() ?>

            <h2>1. FORMA DE PAGAMENTO</h2>

            <!-- Mensagem de erro -->

            <?php if ($erro !== ''): ?>

                <div class="nx-checkout__erro" role="alert">
                    <?= e($erro) ?>
                </div>

            <?php endif; ?>

            <!-- Métodos salvos -->

            <?php if (!empty($metodosSalvos)): ?>

                <section class="nx-checkout__salvos">

                    <h3>MEUS MÉTODOS SALVOS</h3>

                    <p>
                        Selecione um método já cadastrado
                        para não preencher os dados novamente.
                    </p>

                    <div class="nx-checkout__metodos">

                        <?php foreach ($metodosSalvos as $salvo): ?>

                            <?php
                            if (
                                !is_array($salvo) ||
                                !isset($salvo['id_metodo'], $salvo['tipo'])
                            ) {
                                continue;
                            }

                            $idSalvo = (int) $salvo['id_metodo'];
                            $tipoSalvo = (string) $salvo['tipo'];

                            $nomeSalvo = $nomesTipos[$tipoSalvo]
                                ?? 'Método de pagamento';

                            $identificacao = (string) (
                                $salvo['identificacao'] ?? ''
                            );

                            $digitosSalvos = (string) (
                                $salvo['ultimos_digitos'] ?? ''
                            );
                            ?>

                            <label class="nx-checkout__metodo">

                                <input
                                    type="radio"
                                    name="metodo"
                                    value="salvo:<?= $idSalvo ?>"
                                    <?= $idSalvo === $primeiroSalvo
                                        ? 'checked'
                                        : '' ?>
                                >

                                <span class="nx-checkout__metodo-card">

                                    <strong>
                                        <?= e($nomeSalvo) ?>
                                    </strong>

                                    <small>
                                        <?= e($identificacao) ?>

                                        <?php if ($digitosSalvos !== ''): ?>
                                            — Final <?= e($digitosSalvos) ?>
                                        <?php endif; ?>
                                    </small>

                                </span>

                            </label>

                        <?php endforeach; ?>

                    </div>

                </section>

                <h3>OU UTILIZE OUTRO MÉTODO</h3>

            <?php endif; ?>

            <!-- Novos métodos -->

            <div class="nx-checkout__metodos">

                <!-- Cartão -->

                <label class="nx-checkout__metodo">

                    <input
                        type="radio"
                        name="metodo"
                        value="cartao"
                        <?= $primeiroSalvo === 0 ? 'checked' : '' ?>
                    >

                    <span class="nx-checkout__metodo-card">

                        <svg
                            width="34"
                            height="34"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.6"
                            aria-hidden="true"
                        >
                            <rect
                                x="2"
                                y="5"
                                width="20"
                                height="14"
                                rx="2"
                            />
                            <path d="M2 10h20 M6 15h4" />
                        </svg>

                        <strong>Cartão de crédito</strong>
                        <small>Usar outro cartão</small>

                    </span>

                </label>

                <!-- Pix -->

                <label class="nx-checkout__metodo">

                    <input
                        type="radio"
                        name="metodo"
                        value="pix"
                    >

                    <span class="nx-checkout__metodo-card">

                        <svg
                            width="34"
                            height="34"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.6"
                            aria-hidden="true"
                        >
                            <path d="M12 2 22 12 12 22 2 12 12 2Z" />
                            <path d="m7 12 5-5 5 5-5 5-5-5Z" />
                        </svg>

                        <strong>Pix</strong>
                        <small>Usar Pix</small>

                    </span>

                </label>

            </div>

            <!-- Dados do cartão -->

            <section class="nx-checkout__painel nx-checkout__cartao">

                <h2>2. DADOS DO CARTÃO</h2>

                <p>
                    Utilize apenas dados demonstrativos.
                    Não informe dados de um cartão real.
                </p>

                <div class="nx-checkout__campos">

                    <div class="nx-checkout__campo">

                        <label for="nome_cartao">
                            Nome no cartão
                        </label>

                        <input
                            type="text"
                            id="nome_cartao"
                            name="nome_cartao"
                            maxlength="100"
                            autocomplete="off"
                            placeholder="Nome demonstrativo"
                        >

                    </div>

                    <div class="nx-checkout__campo">

                        <label for="numero_cartao">
                            Número do cartão
                        </label>

                        <input
                            type="text"
                            id="numero_cartao"
                            name="numero_cartao"
                            maxlength="19"
                            inputmode="numeric"
                            autocomplete="off"
                            placeholder="0000 0000 0000 0000"
                        >

                    </div>

                    <div class="nx-checkout__campo">

                        <label for="validade_cartao">
                            Validade
                        </label>

                        <input
                            type="text"
                            id="validade_cartao"
                            name="validade_cartao"
                            maxlength="5"
                            autocomplete="off"
                            placeholder="MM/AA"
                        >

                    </div>

                    <div class="nx-checkout__campo">

                        <label for="cvv_cartao">
                            Código de segurança
                        </label>

                        <input
                            type="text"
                            id="cvv_cartao"
                            name="cvv_cartao"
                            maxlength="4"
                            inputmode="numeric"
                            autocomplete="off"
                            placeholder="000"
                        >

                    </div>

                    <!-- Parcelamento -->

                    <div
                        class="nx-checkout__campo nx-checkout__campo--inteiro"
                    >

                        <label for="parcelas">
                            Parcelamento
                        </label>

                        <select id="parcelas" name="parcelas">

                            <?php for ($n = 1; $n <= 6; $n++): ?>

                                <option value="<?= $n ?>">
                                    <?= $n ?>x de
                                    <?= e(moeda($total / $n)) ?>
                                    sem juros
                                </option>

                            <?php endfor; ?>

                        </select>

                    </div>

                </div>

            </section>

            <!-- Pagamento via Pix -->

            <section class="nx-checkout__painel nx-checkout__pix">

                <h2>2. PAGAMENTO VIA PIX</h2>

                <p>
                    QR Code demonstrativo da NexGames.
                </p>

                <div class="nx-checkout__pix-conteudo">

                    <div class="nx-checkout__qr">

                        <img
                            src="public/assets/img/qrcode-pix.png"
                            alt="QR Code demonstrativo do Pix"
                        >

                    </div>

                    <strong>
                        <?= e(moeda($total)) ?>
                    </strong>

                </div>

            </section>

            <!-- Finalizar pagamento -->

            <button
                type="submit"
                class="nx-checkout__finalizar"
            >
                Finalizar pagamento
                <span aria-hidden="true">→</span>
            </button>

            <a
                class="nx-checkout__voltar"
                href="<?= e(url('carrinho', 'index')) ?>"
            >
                ← Voltar para o carrinho
            </a>

        </form>

        <!-- Resumo do pedido -->

        <aside class="nx-checkout__resumo">

            <h2>RESUMO DO PEDIDO</h2>

            <div class="nx-checkout__lista">

                <?php foreach ($itensCarrinho as $item): ?>

                    <?php
                    $nomeJogo = (string) (
                        $item['produto_nome'] ?? 'Jogo'
                    );

                    $imagemJogo = (string) (
                        $item['imagem'] ?? ''
                    );

                    $categoriasJogo = (string) (
                        $item['categorias_nomes'] ?? ''
                    );

                    $subtotalItem = (float) $carrinho->subtotal($item);
                    ?>

                    <article class="nx-checkout__jogo">

                        <?php if ($imagemJogo !== ''): ?>

                            <img
                                src="<?= e($imagemJogo) ?>"
                                alt="<?= e($nomeJogo) ?>"
                                loading="lazy"
                            >

                        <?php else: ?>

                            <div class="nx-checkout__sem-imagem">
                                🎮
                            </div>

                        <?php endif; ?>

                        <div class="nx-checkout__jogo-info">

                            <h3>
                                <?= e($nomeJogo) ?>
                            </h3>

                            <?php if ($categoriasJogo !== ''): ?>

                                <p>
                                    <?= e($categoriasJogo) ?>
                                </p>

                            <?php endif; ?>

                            <strong>
                                <?= e(moeda($subtotalItem)) ?>
                            </strong>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

            <!-- Valores -->

            <div class="nx-checkout__valores">

                <div>
                    <span>Subtotal</span>

                    <span>
                        <?= e(moeda($subtotalBruto)) ?>
                    </span>
                </div>

                <div>
                    <span>Desconto</span>

                    <span>
                        <?= $descontoTotal > 0.004
                            ? '− ' . e(moeda($descontoTotal))
                            : e(moeda(0)) ?>
                    </span>
                </div>

                <div class="nx-checkout__total">

                    <strong>TOTAL</strong>

                    <strong>
                        <?= e(moeda($total)) ?>
                    </strong>

                </div>

            </div>

        </aside>

    </div>

</div>

<!-- Exibição dos painéis de pagamento -->

<style>
    .nx-checkout__form:has(
        input[name="metodo"][value^="salvo:"]:checked
    ) .nx-checkout__cartao,
    .nx-checkout__form:has(
        input[name="metodo"][value^="salvo:"]:checked
    ) .nx-checkout__pix {
        display: none !important;
    }

    .nx-checkout__form:has(
        input[name="metodo"][value="cartao"]:checked
    ) .nx-checkout__cartao {
        display: block !important;
    }

    .nx-checkout__form:has(
        input[name="metodo"][value="cartao"]:checked
    ) .nx-checkout__pix {
        display: none !important;
    }

    .nx-checkout__form:has(
        input[name="metodo"][value="pix"]:checked
    ) .nx-checkout__cartao {
        display: none !important;
    }

    .nx-checkout__form:has(
        input[name="metodo"][value="pix"]:checked
    ) .nx-checkout__pix {
        display: block !important;
    }

    .nx-checkout__metodo input:checked
    + .nx-checkout__metodo-card {
        border-color: #9146ff;
        background: #20112f;
        box-shadow: 0 0 0 1px #9146ff;
    }

    .nx-checkout__metodo-card small {
        display: block;
        margin-top: 8px;
        color: #c3b2d9;
        line-height: 1.5;
    }
</style>
