
<?php

$pedidos = isset($pedidos) && is_array($pedidos)
    ? $pedidos
    : [];

$statusNomes = [
    'pago' => 'Pagamento aprovado',
    'aguardando_pagamento' => 'Aguardando pagamento',
    'cancelado' => 'Pedido cancelado',
];
?>

<section class="banner-conta">
    <h1>Minha conta</h1>

    <p>
        Gerencie sua conta, seus jogos, pedidos
        e preferências na NEX Games.
    </p>
</section>

<div class="conta-layout">

    <!-- MENU LATERAL -->

    <aside class="conta-menu">

        <nav class="conta-menu__nav">

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'meusDados')) ?>"
            >
                Meu perfil
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('pedido', 'meusJogos')) ?>"
            >
                Meus jogos
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'metodosPagamento')) ?>"
            >
                Método de pagamento
            </a>

            <a
                class="conta-menu__link"
                href="<?= e(url('cliente', 'suporte')) ?>"
            >
                Suporte
            </a>

        </nav>

    </aside>

    <!-- CONTEÚDO -->

    <section class="conta-conteudo nx-pedidos">

        <div class="nx-pedidos__cabecalho">

            <h2>Meus pedidos</h2>

            <p>
                Consulte suas compras realizadas
                na NexGames.
            </p>

        </div>

        <?php if (empty($pedidos)): ?>

            <!-- NENHUM PEDIDO -->

            <div class="nx-pedidos__vazio">

                <h3>Nenhum pedido encontrado</h3>

                <p>
                    Você ainda não realizou
                    nenhuma compra.
                </p>

                <a
                    class="nx-pedidos__botao"
                    href="<?= e(url('loja', 'index')) ?>"
                >
                    Explorar jogos
                </a>

            </div>

        <?php else: ?>

            <div class="nx-pedidos__lista">

                <?php foreach ($pedidos as $pedido): ?>

                    <?php
                    $idPedido = (int) (
                        $pedido['id']
                        ?? $pedido['id_pedido']
                        ?? 0
                    );

                    $status = (string) (
                        $pedido['status']
                        ?? $pedido['STATUS']
                        ?? 'aguardando_pagamento'
                    );

                    $statusTexto = $statusNomes[$status]
                        ?? $status;

                    $dataOriginal = (string) (
                        $pedido['data'] ?? ''
                    );

                    $timestamp = $dataOriginal !== ''
                        ? strtotime($dataOriginal)
                        : false;

                    $dataFormatada = $timestamp !== false
                        ? date('d/m/Y H:i', $timestamp)
                        : 'Data não informada';

                    $total = (float) (
                        $pedido['valor_total'] ?? 0
                    );

                    $itens = isset($pedido['itens'])
                        && is_array($pedido['itens'])
                        ? $pedido['itens']
                        : [];

                    $forma = (string) (
                        $pedido['forma_pagamento'] ?? ''
                    );

                    $formaTexto = match ($forma) {
                        'pix' => 'Pix',
                        'cartao' => 'Cartão',
                        default => 'Não informada',
                    };
                    ?>

                    <article class="nx-pedidos__pedido">

                        <!-- CABEÇALHO DO PEDIDO -->

                        <header class="nx-pedidos__topo">

                            <div>

                                <h3>
                                    Pedido #<?= $idPedido ?>
                                </h3>

                                <span class="nx-pedidos__data">
                                    <?= e($dataFormatada) ?>
                                </span>

                            </div>

                            <span class="nx-pedidos__status nx-pedidos__status--<?= e($status) ?>">
                                <?= e($statusTexto) ?>
                            </span>

                        </header>

                        <!-- JOGOS COMPRADOS -->

                        <div class="nx-pedidos__jogos">

                            <?php foreach ($itens as $item): ?>

                                <?php
                                $produtoId = (int) (
                                    $item['produto_id'] ?? 0
                                );

                                $nome = (string) (
                                    $item['produto_nome']
                                    ?? 'Jogo'
                                );

                                $subtotal = (float) (
                                    $item['subtotal']
                                    ?? $item['preco_unitario']
                                    ?? 0
                                );
                                ?>

                                <div class="nx-pedidos__jogo">

                                    <div class="nx-pedidos__jogo-info">

                                        <strong>
                                            <?= e($nome) ?>
                                        </strong>

                                        <small>
                                            Jogo digital
                                        </small>

                                    </div>

                                    <span>
                                        <?= e(moeda($subtotal)) ?>
                                    </span>

                                </div>

                            <?php endforeach; ?>

                        </div>

                        <!-- INFORMAÇÕES DO PAGAMENTO -->

                        <div class="nx-pedidos__informacoes">

                            <div>
                                <span>Forma de pagamento</span>

                                <strong>
                                    <?= e($formaTexto) ?>
                                </strong>
                            </div>

                            <div>
                                <span>Tipo de entrega</span>

                                <strong>
                                    Digital
                                </strong>
                            </div>

                        </div>

                        <!-- RODAPÉ -->

                        <footer class="nx-pedidos__rodape">

                            <div class="nx-pedidos__total">

                                <span>Total do pedido</span>

                                <strong>
                                    <?= e(moeda($total)) ?>
                                </strong>

                            </div>

                            <div class="nx-pedidos__acoes">

                                <a
                                    href="<?= e(url(
                                        'pedido',
                                        'confirmacao',
                                        ['id' => $idPedido]
                                    )) ?>"
                                >
                                    Ver detalhes
                                </a>

                                <?php if ($status === 'pago'): ?>

                                    <a
                                        href="<?= e(url(
                                            'pedido',
                                            'meusJogos'
                                        )) ?>"
                                    >
                                        Meus jogos
                                    </a>

                                    <a
                                        href="<?= e(url(
                                            'pedido',
                                            'verNota',
                                            ['id' => $idPedido]
                                        )) ?>"
                                    >
                                        Ver nota fiscal
                                    </a>

                                <?php endif; ?>

                            </div>

                        </footer>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>

</div>
