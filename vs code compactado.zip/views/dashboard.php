<?php

$nome = $_SESSION['nome'] ?? 'Administrador';
$perfil = $_SESSION['perfil'] ?? 'admin';

$kpiVendasMes = $kpiVendasMes ?? 0;
$kpiEntradasMes = $kpiEntradasMes ?? 0.0;
$kpiTotalProdutos = $kpiTotalProdutos ?? 0;
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard — NexGames</title>

    <link
        rel="icon"
        type="image/png"
        href="public/assets/img/dashboard.png"
    >

    <link
        rel="stylesheet"
        href="public/assets/css/style.css"
    >

    <link
        rel="stylesheet"
        href="public/assets/css/nex.css"
    >

    <!-- CSS do Dashboard -->
    <link
        rel="stylesheet"
        href="public/assets/css/dashboard.css"
    >
</head>

<body class="painel dashboard-nex">

    <main class="dashboard-container">

        <!-- CABEÇALHO -->
        <header class="dashboard-header">

            <div class="dashboard-brand">
                <h1>Loja Nex Games</h1>
                <span>Painel do sistema</span>
            </div>

            <div class="dashboard-user">

                <span>
                    Logado como:
                    <strong><?= e($nome) ?></strong>
                    (<?= e($perfil) ?>)
                </span>

                <span class="dashboard-separador">•</span>

                <a href="<?= e(url('auth', 'logout')) ?>">
                    sair
                </a>

            </div>

        </header>

        <!-- PAINEL PRINCIPAL -->
        <section class="dashboard-card">

            <div class="dashboard-welcome">

                <h2>
                    Bem-vindo(a), <?= e($nome) ?>!
                </h2>

                <p>
                    Escolha um módulo para continuar.
                </p>

            </div>

            <!-- MENU DE NAVEGAÇÃO -->
            <nav class="dashboard-nav" aria-label="Módulos administrativos">

                <a href="<?= e(url('produto', 'index')) ?>">
                    Produtos / Categoria
                </a>

                <a href="<?= e(url('categoria', 'index')) ?>">
                    Categorias
                </a>

                <a href="<?= e(url('venda', 'index')) ?>">
                    Vendas
                </a>

                <a href="<?= e(url('cliente', 'listar')) ?>">
                    Clientes
                </a>

                <a href="<?= e(url('fornecedor', 'index')) ?>">
                    Fornecedores
                </a>

                <a href="<?= e(url('entrada', 'index')) ?>">
                    Entradas
                </a>

                <a href="<?= e(url('relatorio', 'index')) ?>">
                    Relatórios
                </a>

                <a
                    href="<?= e(url('loja', 'index')) ?>"
                    target="_blank"
                    rel="noopener"
                >
                    🎮 Visitar a loja
                </a>

            </nav>

            <!-- INDICADORES -->
            <div class="dashboard-kpis">

                <div class="dashboard-kpi">

                    <span class="dashboard-kpi-label">
                        Vendas (mês)
                    </span>

                    <strong class="dashboard-kpi-value">
                        <?= (int) $kpiVendasMes ?>
                    </strong>

                </div>

                <div class="dashboard-kpi">

                    <span class="dashboard-kpi-label">
                        Faturamento (mês)
                    </span>

                    <strong class="dashboard-kpi-value">
                        <?= e(moeda($kpiEntradasMes)) ?>
                    </strong>

                </div>

                <div class="dashboard-kpi">

                    <span class="dashboard-kpi-label">
                        Produtos
                    </span>

                    <strong class="dashboard-kpi-value">
                        <?= (int) $kpiTotalProdutos ?>
                    </strong>

                </div>

            </div>

        </section>

    </main>

</body>
</html>
