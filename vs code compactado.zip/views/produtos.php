

<?php
/**
 * NexGames - Administração de Produtos/Jogos
 */

/* Dados recebidos do controller */

$produtos = isset($produtos) && is_array($produtos)
    ? $produtos
    : [];

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$editar = isset($editar) && is_array($editar)
    ? $editar
    : null;

$nomeAdmin = (string) ($_SESSION['nome'] ?? 'Administrador');

/* Dados para edição */

$editando = $editar !== null;

$idEdicao = (int) (
    $editar['id_produto'] ??
    $editar['id'] ??
    0
);

$nomeEdicao = (string) ($editar['nome'] ?? '');
$descricaoEdicao = (string) ($editar['descricao'] ?? '');
$precoEdicao = $editar['preco'] ?? '';
$promoEdicao = $editar['preco_promocional'] ?? '';
$ofertaEdicao = !empty($editar['em_oferta']);
$arquivoEdicao = (string) ($editar['arquivo_download'] ?? '');

/* Categorias selecionadas na edição */

$categoriasEdicao = [];

if ($editando) {
    foreach ((array) ($editar['categorias'] ?? []) as $cat) {
        $idCategoria = is_array($cat)
            ? (int) ($cat['id_categoria'] ?? $cat['id'] ?? 0)
            : (int) $cat;

        if ($idCategoria > 0) {
            $categoriasEdicao[] = $idCategoria;
        }
    }

    if (empty($categoriasEdicao) && !empty($editar['categorias_ids'])) {
        $categoriasEdicao = array_map(
            'intval',
            explode(',', (string) $editar['categorias_ids'])
        );
    }
}

$categoriasEdicao = array_values(
    array_unique($categoriasEdicao)
);

/* Preparação da listagem */

$listaJogos = [];

foreach ($produtos as $produto) {
    if (!is_array($produto)) {
        continue;
    }

    $idProduto = (int) (
        $produto['id_produto'] ??
        $produto['id'] ??
        0
    );

    $precoOriginal = (float) ($produto['preco'] ?? 0);
    $precoPromocional = $produto['preco_promocional'] ?? null;

    $emOferta = (
        !empty($produto['em_oferta']) &&
        $precoPromocional !== null
    );

    $precoFinal = $emOferta
        ? (float) $precoPromocional
        : $precoOriginal;

    /* Categorias */

    $categoriasTexto = (string) (
        $produto['categorias_nome'] ??
        $produto['categorias_nomes'] ??
        $produto['categoria_nome'] ??
        ''
    );

    if ($categoriasTexto === '' && !empty($produto['categorias'])) {
        $nomesCategorias = [];

        foreach ((array) $produto['categorias'] as $categoria) {
            if (is_array($categoria)) {
                $nomesCategorias[] = (string) ($categoria['nome'] ?? '');
            } elseif (is_string($categoria)) {
                $nomesCategorias[] = $categoria;
            }
        }

        $categoriasTexto = implode(
            ', ',
            array_filter($nomesCategorias)
        );
    }

    /* Imagem - caminho corrigido para InfinityFree */

    $imagemProduto = trim((string) ($produto['imagem'] ?? ''));

    if (
        $imagemProduto !== '' &&
        !preg_match('~^(https?://|/)~i', $imagemProduto)
    ) {
        $imagemProduto = '/' . ltrim($imagemProduto, '/');
    }

    $listaJogos[] = [
        'id' => $idProduto,
        'nome' => (string) ($produto['nome'] ?? ''),
        'categorias' => $categoriasTexto,
        'preco' => $precoFinal,
        'imagem' => $imagemProduto,
        'ativo' => (int) ($produto['ativo'] ?? 1),
        'oferta' => $emOferta
    ];
}

$totalJogos = count($listaJogos);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Produtos/Jogos — NexGames</title>

    <!-- Favicon corrigido -->
    <link
        rel="icon"
        href="/public/assets/img/favicon-nex.png"
    >

    <!-- CSS corrigido -->
    <link
        rel="stylesheet"
        href="/public/assets/css/admin-produtos.css?v=3"
    >
</head>

<body class="nx-admin-produtos">

    <!-- Cabeçalho administrativo -->

    <header class="nx-admin-header">

        <div class="nx-admin-header-inner">

            <a
                href="<?= e(url('auth', 'dashboard')) ?>"
                class="nx-admin-logo"
                aria-label="Voltar ao dashboard"
            >
                <img
                    src="/public/assets/img/logo-nex.jpeg"
                    alt="NexGames"
                >
            </a>

            <div class="nx-admin-header-right">

                <span class="nx-admin-avatar" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="21" height="21">
                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                            fill="currentColor"
                        />
                        <path
                            d="M4 21c0-5 3-8 8-8s8 3 8 8"
                            fill="currentColor"
                        />
                    </svg>
                </span>

                <span class="nx-admin-nome">
                    <?= e($nomeAdmin) ?>
                </span>

                <a
                    href="<?= e(url('auth', 'dashboard')) ?>"
                    class="nx-admin-header-link"
                >
                    Dashboard
                </a>

                <a
                    href="<?= e(url('auth', 'logout')) ?>"
                    class="nx-admin-header-link"
                >
                    Sair
                </a>

            </div>

        </div>

    </header>

    <!-- Conteúdo principal -->

    <main class="nx-admin-main">

        <div class="nx-admin-tag">
            Produtos/Jogos
        </div>

        <div class="nx-admin-grid">

            <!-- Cadastro e edição -->

            <section class="nx-admin-form-panel">

                <h1>
                    <?= $editando ? 'Editar jogo' : 'Cadastrar jogo' ?>
                </h1>

                <?php if ($editando): ?>
                    <p class="nx-admin-editando">
                        Editando jogo #<?= $idEdicao ?>
                    </p>
                <?php endif; ?>

                <form
                    action="<?= e(url('produto', 'salvar')) ?>"
                    method="post"
                    enctype="multipart/form-data"
                    class="nx-admin-form"
                >

                    <?= csrfCampo() ?>

                    <input
                        type="hidden"
                        name="id_produto"
                        value="<?= $idEdicao ?>"
                    >

                    <!-- Nome -->

                    <div class="nx-admin-field">

                        <label for="nome">
                            Nome do jogo
                        </label>

                        <input
                            type="text"
                            id="nome"
                            name="nome"
                            value="<?= e($nomeEdicao) ?>"
                            placeholder="Digite o nome do jogo..."
                            maxlength="150"
                            required
                        >

                    </div>

                    <!-- Descrição -->

                    <div class="nx-admin-field">

                        <label for="descricao">
                            Descrição
                        </label>

                        <textarea
                            id="descricao"
                            name="descricao"
                            rows="4"
                            placeholder="Digite a descrição do jogo..."
                        ><?= e($descricaoEdicao) ?></textarea>

                    </div>

                    <!-- Preços -->

                    <div class="nx-admin-price-grid">

                        <div class="nx-admin-field">

                            <label for="preco">
                                Preço (R$)
                            </label>

                            <input
                                type="number"
                                id="preco"
                                name="preco"
                                value="<?= e((string) $precoEdicao) ?>"
                                min="0.01"
                                step="0.01"
                                placeholder="0,00"
                                required
                            >

                        </div>

                        <div class="nx-admin-field">

                            <label for="preco_promocional">
                                Preço promocional (R$)
                            </label>

                            <input
                                type="number"
                                id="preco_promocional"
                                name="preco_promocional"
                                value="<?= e((string) $promoEdicao) ?>"
                                min="0.01"
                                step="0.01"
                                placeholder="0,00"
                            >

                        </div>

                    </div>

                    <!-- Categorias -->

                    <div class="nx-admin-field">

                        <label for="categorias">
                            Categoria(s)
                        </label>

                        <select
                            id="categorias"
                            name="categorias[]"
                            multiple
                            size="5"
                            required
                        >

                            <?php foreach ($categorias as $categoria): ?>

                                <?php
                                if (!is_array($categoria)) {
                                    continue;
                                }

                                $categoriaId = (int) (
                                    $categoria['id_categoria'] ??
                                    $categoria['id'] ??
                                    0
                                );

                                $categoriaNome = (string) (
                                    $categoria['nome'] ?? ''
                                );
                                ?>

                                <option
                                    value="<?= $categoriaId ?>"
                                    <?= in_array(
                                        $categoriaId,
                                        $categoriasEdicao,
                                        true
                                    ) ? 'selected' : '' ?>
                                >
                                    <?= e($categoriaNome) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <small>
                            Segure Ctrl para selecionar várias categorias.
                        </small>

                    </div>

                    <!-- Imagem -->

                    <div class="nx-admin-field">

                        <label for="imagem">
                            Imagem do jogo
                        </label>

                        <input
                            type="file"
                            id="imagem"
                            name="imagem"
                            accept="image/jpeg,image/png,image/webp"
                        >

                        <small>
                            JPG, PNG ou WEBP. Máximo de 2 MB.
                        </small>

                    </div>

                    <!-- Arquivo de download -->

                    <div class="nx-admin-field">

                        <label for="arquivo_download">
                            Arquivo para download
                        </label>

                        <input
                            type="text"
                            id="arquivo_download"
                            name="arquivo_download"
                            value="<?= e($arquivoEdicao) ?>"
                            placeholder="Ex.: downloads/jogo.png"
                        >

                        <small>
                            Informe o caminho do arquivo.
                            O upload direto será implementado depois.
                        </small>

                    </div>

                    <!-- Em oferta -->

                    <label class="nx-admin-checkbox">

                        <input
                            type="checkbox"
                            name="em_oferta"
                            value="1"
                            <?= $ofertaEdicao ? 'checked' : '' ?>
                        >

                        <span>Em oferta</span>

                    </label>

                    <!-- Botões -->

                    <div class="nx-admin-form-actions">

                        <button
                            type="submit"
                            class="nx-admin-btn nx-admin-btn-primary"
                        >
                            <?= $editando
                                ? 'Salvar alterações'
                                : 'Salvar jogo' ?>
                        </button>

                        <a
                            href="<?= e(url('produto', 'index')) ?>"
                            class="nx-admin-btn nx-admin-btn-outline"
                        >
                            <?= $editando ? 'Cancelar' : 'Limpar' ?>
                        </a>

                    </div>

                </form>

            </section>

            <!-- Jogos cadastrados -->

            <section class="nx-admin-list-panel">

                <div class="nx-admin-list-top">

                    <div>
                        <h2>Jogos cadastrados</h2>

                        <p>
                            <?= $totalJogos ?> jogo(s) encontrado(s)
                        </p>
                    </div>

                </div>

                <!-- Filtros -->

                <div class="nx-admin-filters">

                    <input
                        type="search"
                        id="nx-pesquisar-jogo"
                        placeholder="Pesquisar jogos..."
                        aria-label="Pesquisar jogos cadastrados"
                    >

                    <select
                        id="nx-filtrar-status"
                        aria-label="Filtrar por status"
                    >
                        <option value="todos">Todos</option>
                        <option value="ativo">Ativos</option>
                        <option value="inativo">Inativos</option>
                    </select>

                    <select
                        id="nx-filtrar-oferta"
                        aria-label="Filtrar ofertas"
                    >
                        <option value="todos">Todas ofertas</option>
                        <option value="oferta">Em oferta</option>
                        <option value="normal">Sem oferta</option>
                    </select>

                </div>

                <!-- Tabela -->

                <div class="nx-admin-table-wrap">

                    <table class="nx-admin-table">

                        <thead>
                            <tr>
                                <th>Imagem</th>
                                <th>Nome</th>
                                <th>Categoria(s)</th>
                                <th>Preço</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody id="nx-tabela-jogos">

                            <?php foreach ($listaJogos as $jogo): ?>

                                <?php
                                $nomePesquisa = mb_strtolower($jogo['nome']);

                                $categoriasPesquisa = mb_strtolower(
                                    $jogo['categorias']
                                );

                                $statusJogo = $jogo['ativo']
                                    ? 'ativo'
                                    : 'inativo';

                                $ofertaJogo = $jogo['oferta']
                                    ? 'oferta'
                                    : 'normal';
                                ?>

                                <tr
                                    class="nx-admin-game-row"
                                    data-nome="<?= e($nomePesquisa) ?>"
                                    data-categorias="<?= e($categoriasPesquisa) ?>"
                                    data-status="<?= $statusJogo ?>"
                                    data-oferta="<?= $ofertaJogo ?>"
                                >

                                    <!-- Imagem -->

                                    <td>
                                        <div class="nx-admin-game-image">

                                            <?php if ($jogo['imagem'] !== ''): ?>

                                                <img
                                                    src="<?= e($jogo['imagem']) ?>"
                                                    alt="<?= e($jogo['nome']) ?>"
                                                    loading="lazy"
                                                >

                                            <?php else: ?>

                                                <span aria-hidden="true">
                                                    🎮
                                                </span>

                                            <?php endif; ?>

                                        </div>
                                    </td>

                                    <!-- Nome -->

                                    <td class="nx-admin-game-name">
                                        <?= e($jogo['nome']) ?>
                                    </td>

                                    <!-- Categorias -->

                                    <td class="nx-admin-game-categories">
                                        <?= e(
                                            $jogo['categorias'] !== ''
                                                ? $jogo['categorias']
                                                : 'Sem categoria'
                                        ) ?>
                                    </td>

                                    <!-- Preço -->

                                    <td class="nx-admin-game-price">
                                        R$ <?= number_format(
                                            $jogo['preco'],
                                            2,
                                            ',',
                                            '.'
                                        ) ?>
                                    </td>

                                    <!-- Status -->

                                    <td>
                                        <span class="nx-admin-status <?= $statusJogo ?>">
                                            <?= $jogo['ativo']
                                                ? 'Ativo'
                                                : 'Inativo' ?>
                                        </span>
                                    </td>

                                    <!-- Ações -->

                                    <td>

                                        <div class="nx-admin-row-actions">

                                            <!-- Editar -->

                                            <a
                                                class="nx-admin-action-edit"
                                                href="<?= e(url(
                                                    'produto',
                                                    'index',
                                                    ['id' => $jogo['id']]
                                                )) ?>"
                                                title="Editar jogo"
                                            >
                                                Editar
                                            </a>

                                            <!-- Ativar ou desativar -->

                                            <form
                                                action="<?= e(url('produto', 'toggle')) ?>"
                                                method="post"
                                            >

                                                <?= csrfCampo() ?>

                                                <input
                                                    type="hidden"
                                                    name="id_produto"
                                                    value="<?= $jogo['id'] ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="ativo"
                                                    value="<?= $jogo['ativo'] ? 0 : 1 ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="nx-admin-action-toggle"
                                                >
                                                    <?= $jogo['ativo']
                                                        ? 'Desativar'
                                                        : 'Ativar' ?>
                                                </button>

                                            </form>

                                            <!-- Excluir -->

                                            <form
                                                action="<?= e(url('produto', 'deletar')) ?>"
                                                method="post"
                                                onsubmit="return confirm('Tem certeza que deseja excluir este jogo? Essa ação não poderá ser desfeita.');"
                                            >

                                                <?= csrfCampo() ?>

                                                <input
                                                    type="hidden"
                                                    name="id_produto"
                                                    value="<?= $jogo['id'] ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="nx-admin-action-delete"
                                                    title="Excluir jogo"
                                                    aria-label="Excluir <?= e($jogo['nome']) ?>"
                                                >
                                                    <svg
                                                        viewBox="0 0 24 24"
                                                        width="17"
                                                        height="17"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        stroke-width="1.8"
                                                        aria-hidden="true"
                                                    >
                                                        <path d="M4 7h16" />
                                                        <path d="M10 4h4" />
                                                        <path d="M6 7l1 13h10l1-13" />
                                                        <path d="M10 11v6M14 11v6" />
                                                    </svg>
                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                    <p
                        class="nx-admin-empty"
                        id="nx-sem-resultados"
                        hidden
                    >
                        Nenhum jogo encontrado com esses filtros.
                    </p>

                    <?php if (empty($listaJogos)): ?>

                        <p class="nx-admin-empty">
                            Nenhum jogo cadastrado ainda.
                        </p>

                    <?php endif; ?>

                </div>

            </section>

        </div>

    </main>

    <!-- Pesquisa e filtros -->

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const pesquisa = document.getElementById('nx-pesquisar-jogo');
            const status = document.getElementById('nx-filtrar-status');
            const oferta = document.getElementById('nx-filtrar-oferta');

            const linhas = Array.from(
                document.querySelectorAll('.nx-admin-game-row')
            );

            const mensagem = document.getElementById('nx-sem-resultados');

            function filtrarJogos() {
                const termo = pesquisa.value.trim().toLowerCase();
                const statusEscolhido = status.value;
                const ofertaEscolhida = oferta.value;

                let visiveis = 0;

                linhas.forEach(function (linha) {
                    const nome = linha.dataset.nome || '';
                    const categorias = linha.dataset.categorias || '';

                    const correspondeTexto =
                        nome.includes(termo) ||
                        categorias.includes(termo);

                    const correspondeStatus =
                        statusEscolhido === 'todos' ||
                        linha.dataset.status === statusEscolhido;

                    const correspondeOferta =
                        ofertaEscolhida === 'todos' ||
                        linha.dataset.oferta === ofertaEscolhida;

                    const mostrar =
                        correspondeTexto &&
                        correspondeStatus &&
                        correspondeOferta;

                    linha.hidden = !mostrar;

                    if (mostrar) {
                        visiveis++;
                    }
                });

                if (mensagem) {
                    mensagem.hidden =
                        visiveis > 0 || linhas.length === 0;
                }
            }

            pesquisa.addEventListener('input', filtrarJogos);
            status.addEventListener('change', filtrarJogos);
            oferta.addEventListener('change', filtrarJogos);
        });
    </script>

</body>
</html>
