
<?php
/**
 * NexGames - Comprovante de pedido
 * Arquivo: views/nota_fiscal.php
 */

/* Dados recebidos do controller */

$pedido = isset($pedido) && is_array($pedido)
    ? $pedido
    : [];

$cliente = isset($cliente) && is_array($cliente)
    ? $cliente
    : [];

$itensPedido = isset($pedido['itens']) && is_array($pedido['itens'])
    ? $pedido['itens']
    : [];

/* Informações do pedido */

$idPedido = (int) ($pedido['id_pedido'] ?? 0);

$numeroNota = str_pad(
    (string) $idPedido,
    6,
    '0',
    STR_PAD_LEFT
);

/* Data e hora */

$dataPedido = (string) ($pedido['data_pedido'] ?? '');

$timestampPedido = $dataPedido !== ''
    ? strtotime($dataPedido)
    : false;

$dataPedidoFormatada = $timestampPedido !== false
    ? date('d/m/Y', $timestampPedido)
    : 'Não informada';

$horaPedidoFormatada = $timestampPedido !== false
    ? date('H:i:s', $timestampPedido)
    : 'Não informada';

/* Status do pedido */

$statusPedido = (string) (
    $pedido['status'] ??
    $pedido['STATUS'] ??
    ''
);

$rotulosStatus = [
    'aguardando_pagamento' => 'Aguardando pagamento',
    'pago' => 'Pago',
    'cancelado' => 'Cancelado'
];

$statusFormatado = $rotulosStatus[$statusPedido]
    ?? ($statusPedido !== '' ? ucfirst($statusPedido) : 'Não informado');

/* Dados do cliente */

$nomeCliente = (string) ($cliente['nome'] ?? 'Não informado');
$cpfCliente = (string) ($cliente['cpf'] ?? '');
$emailCliente = (string) ($cliente['email'] ?? '');

$cpfFormatado = $cpfCliente !== ''
    ? formatarCpf($cpfCliente)
    : 'Não informado';

/* Valor total */

$valorTotal = (float) ($pedido['valor_total'] ?? 0);

$valorTotalFormatado = number_format(
    $valorTotal,
    2,
    ',',
    '.'
);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Comprovante do Pedido - Nº <?= e($numeroNota) ?>
    </title>

    <link
        rel="icon"
        type="image/png"
        href="public/assets/img/dashboard.png"
    >

    <link
        rel="stylesheet"
        href="public/assets/css/nota.css"
    >
</head>

<body>

    <div class="nf-container">

        <!-- Cabeçalho -->

        <header class="nf-cabecalho">

            <div class="nf-emitente">

                <h1 class="nf-emitente-nome">
                    NEX GAMES
                </h1>

                <p class="nf-emitente-documento">
                    Documento demonstrativo — sem validade fiscal
                </p>

                <p class="nf-emitente-endereco">
                    Loja virtual de jogos digitais —
                    Onde sua próxima aventura começa
                </p>

            </div>

            <div class="nf-documento-info">

                <h2 class="nf-documento-titulo">
                    COMPROVANTE DE PEDIDO
                </h2>

                <div class="nf-documento-dados">

                    <p class="nf-dado-linha">
                        <strong>NÚMERO:</strong>
                        <?= e($numeroNota) ?>
                    </p>

                    <p class="nf-dado-linha">
                        <strong>TIPO:</strong>
                        Simulação acadêmica
                    </p>

                </div>

            </div>

        </header>

        <!-- Informações do pedido -->

        <section class="nf-emissao">

            <div class="nf-emissao-bloco">

                <span class="nf-emissao-label">
                    DATA DO PEDIDO
                </span>

                <span class="nf-emissao-valor">
                    <?= e($dataPedidoFormatada) ?>
                </span>

            </div>

            <div class="nf-emissao-bloco">

                <span class="nf-emissao-label">
                    HORA DO PEDIDO
                </span>

                <span class="nf-emissao-valor">
                    <?= e($horaPedidoFormatada) ?>
                </span>

            </div>

            <div class="nf-emissao-bloco">

                <span class="nf-emissao-label">
                    REFERÊNCIA PEDIDO
                </span>

                <span class="nf-emissao-valor">
                    #<?= $idPedido ?>
                </span>

            </div>

            <div class="nf-emissao-bloco">

                <span class="nf-emissao-label">
                    STATUS
                </span>

                <span class="nf-emissao-valor">
                    <?= e($statusFormatado) ?>
                </span>

            </div>

        </section>

        <!-- Dados do cliente -->

        <section class="nf-emissao">

            <div class="nf-emissao-bloco" style="width: 100%;">

                <span class="nf-emissao-label">
                    DESTINATÁRIO
                </span>

                <span class="nf-emissao-valor">
                    <?= e($nomeCliente) ?>
                    — CPF <?= e($cpfFormatado) ?>
                </span>

                <?php if ($emailCliente !== ''): ?>

                    <p class="nf-emitente-endereco">
                        E-mail: <?= e($emailCliente) ?>
                    </p>

                <?php endif; ?>

                <p class="nf-emitente-endereco">
                    Entrega digital: download disponível em
                    "Meus Jogos" após a confirmação do pagamento.
                </p>

            </div>

        </section>

        <!-- Jogos do pedido -->

        <main class="nf-conteudo">

            <table class="nf-tabela-produtos">

                <thead>

                    <tr>
                        <th class="nf-th-codigo">CÓDIGO</th>
                        <th class="nf-th-descricao">DESCRIÇÃO DO PRODUTO</th>
                        <th class="nf-th-qtd">QTD</th>
                        <th class="nf-th-valor-uni">V. UNITÁRIO</th>
                        <th class="nf-th-valor-tot">V. TOTAL</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if (empty($itensPedido)): ?>

                        <tr>
                            <td colspan="5">
                                Nenhum jogo encontrado neste pedido.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($itensPedido as $item): ?>

                            <?php
                            if (!is_array($item)) {
                                continue;
                            }

                            $idProduto = (int) (
                                $item['id_produto'] ?? 0
                            );

                            $nomeProduto = (string) (
                                $item['produto_nome'] ?? 'Jogo'
                            );

                            /* Cada item representa uma licença digital */

                            $quantidade = 1;

                            $precoUnitario = (float) (
                                $item['preco_unitario'] ?? 0
                            );

                            $subtotal = (float) (
                                $item['subtotal'] ??
                                ($precoUnitario * $quantidade)
                            );

                            $precoUnitarioFormatado = number_format(
                                $precoUnitario,
                                2,
                                ',',
                                '.'
                            );

                            $subtotalFormatado = number_format(
                                $subtotal,
                                2,
                                ',',
                                '.'
                            );
                            ?>

                            <tr>

                                <!-- Código -->

                                <td class="nf-td-codigo">
                                    #<?= $idProduto ?>
                                </td>

                                <!-- Nome do jogo -->

                                <td class="nf-td-descricao">
                                    <?= e($nomeProduto) ?>
                                </td>

                                <!-- Quantidade -->

                                <td class="nf-td-qtd">
                                    <?= $quantidade ?>
                                </td>

                                <!-- Preço unitário -->

                                <td class="nf-td-valor-uni">
                                    R$ <?= $precoUnitarioFormatado ?>
                                </td>

                                <!-- Subtotal -->

                                <td class="nf-td-valor-tot">
                                    R$ <?= $subtotalFormatado ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </main>

        <!-- Total do pedido -->

        <footer class="nf-rodape">

            <div class="nf-total-bloco">

                <span class="nf-total-label">
                    VALOR TOTAL DO PEDIDO
                </span>

                <span class="nf-total-valor">
                    R$ <?= $valorTotalFormatado ?>
                </span>

            </div>

        </footer>

        <!-- Impressão -->

        <div class="nf-botoes no-print">

            <button
                type="button"
                class="nf-btn-imprimir"
                onclick="window.print()"
            >
                Imprimir comprovante
            </button>

        </div>

    </div>

</body>
</html>
