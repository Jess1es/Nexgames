<?php

$fornecedores = $fornecedores ?? [];
$editar = $editar ?? null;

$editando = !empty($editar);

$id = (int) ($editar['id_fornecedor'] ?? $editar['id'] ?? 0);
$nome = (string) ($editar['nome'] ?? '');
$cnpj = (string) ($editar['cnpj'] ?? '');
$telefone = (string) ($editar['telefone'] ?? '');
$email = (string) ($editar['email'] ?? '');
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Fornecedores — NexGames</title>

    <link rel="stylesheet" href="public/assets/css/style.css">
    <link rel="stylesheet" href="public/assets/css/nex.css">
    <link rel="stylesheet" href="public/assets/css/dashboard.css">

    <style>
        .fornecedores-container {
            max-width: 1150px;
            margin: 45px auto;
            padding: 20px;
            color: #fff;
        }

        .fornecedores-voltar {
            display: inline-block;
            margin-bottom: 25px;
            padding: 12px 28px;
            border: 1px solid #8b35ff;
            border-radius: 25px;
            background: #b8b8b8;
            color: #111;
            text-decoration: none;
        }

        .fornecedores-card {
            background: #121016;
            border: 1px solid #8b35ff;
            border-radius: 28px;
            padding: 30px;
            margin-bottom: 28px;
        }

        .fornecedores-card h1,
        .fornecedores-card h2 {
            margin: 0 0 10px;
            color: #fff;
        }

        .fornecedores-descricao {
            margin-bottom: 25px;
            color: #bbb;
        }

        .fornecedores-form {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        .fornecedores-campo {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .fornecedores-campo label {
            font-weight: bold;
        }

        .fornecedores-campo input {
            width: 100%;
            box-sizing: border-box;
            padding: 13px;
            border: 1px solid #8b35ff;
            border-radius: 10px;
            background: #201b29;
            color: #fff;
            font-size: 15px;
        }

        .fornecedores-acoes {
            grid-column: 1 / -1;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .fornecedores-btn {
            display: inline-block;
            padding: 11px 22px;
            border: 1px solid #8b35ff;
            border-radius: 12px;
            background: #8b35ff;
            color: #fff;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .fornecedores-btn-secundario {
            background: transparent;
        }

        .fornecedores-tabela-area {
            overflow-x: auto;
        }

        .fornecedores-tabela {
            width: 100%;
            border-collapse: collapse;
            min-width: 780px;
        }

        .fornecedores-tabela th,
        .fornecedores-tabela td {
            padding: 16px 12px;
            border-bottom: 1px solid #502077;
            text-align: left;
        }

        .fornecedores-tabela th {
            border-bottom: 2px solid #8b35ff;
        }

        .fornecedores-tabela td {
            color: #eee;
        }

        .fornecedores-status {
            display: inline-block;
            padding: 7px 13px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .fornecedores-ativo {
            background: #25834a;
            color: #fff;
        }

        .fornecedores-inativo {
            background: #8c3333;
            color: #fff;
        }

        .fornecedores-acoes-tabela {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .fornecedores-acoes-tabela form {
            margin: 0;
        }

        .fornecedores-acoes-tabela .fornecedores-btn {
            font-size: 12px;
            padding: 8px 12px;
        }

        .fornecedores-vazio {
            padding: 25px;
            text-align: center;
            color: #bbb;
        }

        @media (max-width: 650px) {
            .fornecedores-container {
                margin: 20px auto;
            }

            .fornecedores-card {
                padding: 20px;
            }

            .fornecedores-form {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body class="painel">

<main class="fornecedores-container">

    <a
        class="fornecedores-voltar"
        href="<?= e(url('auth', 'dashboard')) ?>"
    >
        Voltar ao Dashboard
    </a>

    <section class="fornecedores-card">

        <h1>
            <?= $editando
                ? 'Editar fornecedor'
                : 'Cadastrar fornecedor' ?>
        </h1>

        <p class="fornecedores-descricao">
            Gerencie os fornecedores cadastrados na NexGames.
        </p>

        <form
            class="fornecedores-form"
            action="<?= e(url('fornecedor', 'salvar')) ?>"
            method="POST"
        >
            <?= csrfCampo() ?>

            <input
                type="hidden"
                name="id"
                value="<?= $id ?>"
            >

            <div class="fornecedores-campo">
                <label for="nome">Nome do fornecedor *</label>

                <input
                    type="text"
                    id="nome"
                    name="nome"
                    maxlength="100"
                    value="<?= e($nome) ?>"
                    required
                >
            </div>

            <div class="fornecedores-campo">
                <label for="cnpj">CNPJ *</label>

                <input
                    type="text"
                    id="cnpj"
                    name="cnpj"
                    maxlength="20"
                    value="<?= e($cnpj) ?>"
                    required
                >
            </div>

            <div class="fornecedores-campo">
                <label for="telefone">Telefone</label>

                <input
                    type="text"
                    id="telefone"
                    name="telefone"
                    value="<?= e($telefone) ?>"
                >
            </div>

            <div class="fornecedores-campo">
                <label for="email">E-mail</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= e($email) ?>"
                >
            </div>

            <div class="fornecedores-acoes">

                <button
                    type="submit"
                    class="fornecedores-btn"
                >
                    <?= $editando
                        ? 'Salvar alterações'
                        : 'Cadastrar fornecedor' ?>
                </button>

                <?php if ($editando): ?>
                    <a
                        class="fornecedores-btn fornecedores-btn-secundario"
                        href="<?= e(url('fornecedor', 'index')) ?>"
                    >
                        Cancelar edição
                    </a>
                <?php endif; ?>

            </div>
        </form>

    </section>

    <section class="fornecedores-card">

        <h2>Fornecedores cadastrados</h2>

        <p class="fornecedores-descricao">
            Consulte e gerencie os fornecedores do sistema.
        </p>

        <div class="fornecedores-tabela-area">

            <table class="fornecedores-tabela">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Fornecedor</th>
                        <th>CNPJ</th>
                        <th>Telefone</th>
                        <th>E-mail</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (empty($fornecedores)): ?>

                        <tr>
                            <td colspan="7" class="fornecedores-vazio">
                                Nenhum fornecedor cadastrado.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($fornecedores as $fornecedor): ?>

                            <?php
                            $fornecedorId = (int) (
                                $fornecedor['id_fornecedor']
                                ?? $fornecedor['id']
                                ?? 0
                            );

                            $ativo = (int) (
                                $fornecedor['ativo'] ?? 1
                            ) === 1;
                            ?>

                            <tr>

                                <td>
                                    #<?= $fornecedorId ?>
                                </td>

                                <td>
                                    <?= e($fornecedor['nome'] ?? '') ?>
                                </td>

                                <td>
                                    <?= e($fornecedor['cnpj'] ?? '') ?>
                                </td>

                                <td>
                                    <?= e($fornecedor['telefone'] ?? '-') ?>
                                </td>

                                <td>
                                    <?= e($fornecedor['email'] ?? '-') ?>
                                </td>

                                <td>
                                    <span class="fornecedores-status <?= $ativo
                                        ? 'fornecedores-ativo'
                                        : 'fornecedores-inativo' ?>">
                                        <?= $ativo ? 'Ativo' : 'Inativo' ?>
                                    </span>
                                </td>

                                <td>

                                    <div class="fornecedores-acoes-tabela">

                                        <a
                                            class="fornecedores-btn"
                                            href="<?= e(url(
                                                'fornecedor',
                                                'index',
                                                ['id' => $fornecedorId]
                                            )) ?>"
                                        >
                                            Editar
                                        </a>

                                        <form
                                            action="<?= e(url('fornecedor', 'toggle')) ?>"
                                            method="POST"
                                        >
                                            <?= csrfCampo() ?>

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= $fornecedorId ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="ativo"
                                                value="<?= $ativo ? 0 : 1 ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="fornecedores-btn fornecedores-btn-secundario"
                                            >
                                                <?= $ativo
                                                    ? 'Desativar'
                                                    : 'Ativar' ?>
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</main>

</body>
</html>
