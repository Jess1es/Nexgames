
<?php

$resumo = array_replace([
    'total_vendas' => 0,
    'pedidos_realizados' => 0,
    'clientes_ativos' => 0,
    'produtos_cadastrados' => 0
], $resumo ?? []);

$periodo = array_replace([
    'dias' => 30,
    'total_pedidos' => 0,
    'faturamento' => 0
], $periodo ?? []);

$topProdutos = $topProdutos ?? [];

$brl = fn($valor) =>
    'R$ ' . number_format((float) $valor, 2, ',', '.');

$escapar = fn($valor) =>
    htmlspecialchars(
        (string) $valor,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">

    <style>
        @page {
            margin: 30px;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #222;
        }

        h1 {
            font-size: 20px;
            color: #5b2bd6;
            border-bottom: 2px solid #5b2bd6;
            padding-bottom: 10px;
        }

        h2 {
            font-size: 15px;
            color: #5b2bd6;
            margin-top: 24px;
        }

        .subtitulo {
            color: #666;
            font-size: 11px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            margin-bottom: 15px;
        }

        th, td {
            border: 1px solid #aaa;
            padding: 8px;
            font-size: 10px;
        }

        th {
            background: #eeeeee;
            text-align: left;
        }

        .num {
            text-align: right;
        }

        .vazio {
            text-align: center;
            color: #666;
        }

        .rodape {
            margin-top: 30px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
            text-align: center;
            color: #777;
            font-size: 10px;
        }
    </style>
</head>

<body>

    <h1>NEXGAMES — Relatório Gerencial</h1>

    <p class="subtitulo">
        Gerado em: <?= date('d/m/Y H:i') ?>
    </p>

    <!-- RESUMO DA LOJA -->

    <h2>Resumo da loja</h2>

    <table>
        <thead>
            <tr>
                <th>Total de vendas</th>
                <th>Pedidos realizados</th>
                <th>Clientes cadastrados</th>
                <th>Jogos cadastrados</th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td>
                    <?= (int) $resumo['total_vendas'] ?>
                </td>

                <td>
                    <?= (int) $resumo['pedidos_realizados'] ?>
                </td>

                <td>
                    <?= (int) $resumo['clientes_ativos'] ?>
                </td>

                <td>
                    <?= (int) $resumo['produtos_cadastrados'] ?>
                </td>
            </tr>
        </tbody>
    </table>

    <!-- INFORMAÇÕES DO PERÍODO -->

    <h2>
        Informações gerais — últimos
        <?= (int) $periodo['dias'] ?> dias
    </h2>

    <table>
        <thead>
            <tr>
                <th>Período analisado</th>
                <th>Total de pedidos</th>
                <th>Faturamento total</th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td>
                    Últimos <?= (int) $periodo['dias'] ?> dias
                </td>

                <td>
                    <?= (int) $periodo['total_pedidos'] ?>
                </td>

                <td>
                    <?= $brl($periodo['faturamento']) ?>
                </td>
            </tr>
        </tbody>
    </table>

    <!-- JOGOS MAIS VENDIDOS -->

    <h2>Jogos mais vendidos</h2>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Jogo</th>
                <th class="num">Vendas</th>
                <th class="num">Faturamento</th>
            </tr>
        </thead>

        <tbody>

            <?php if (empty($topProdutos)): ?>

                <tr>
                    <td colspan="4" class="vazio">
                        Nenhuma venda encontrada.
                    </td>
                </tr>

            <?php else: ?>

                <?php foreach ($topProdutos as $i => $p): ?>

                    <tr>
                        <td>
                            <?= $i + 1 ?>
                        </td>

                        <td>
                            <?= $escapar($p['nome']) ?>
                        </td>

                        <td class="num">
                            <?= (int) $p['total_vendido'] ?>
                        </td>

                        <td class="num">
                            <?= $brl($p['receita']) ?>
                        </td>
                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

        </tbody>
    </table>

    <div class="rodape">
        NEXGAMES — Onde sua próxima aventura começa.
        <p>Relatório gerado automaticamente pelo sistema.</p>
    </div>

</body>
</html>
