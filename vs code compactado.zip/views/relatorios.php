
<?php

$nomeUser = $_SESSION['nome'] ?? 'Administrador';

$resumo = array_replace([
    'total_vendas' => 0,
    'pedidos_realizados' => 0,
    'clientes_ativos' => 0,
    'produtos_cadastrados' => 0
], $resumo ?? []);

$periodo = array_replace([
    'dias' => 30,
    'total_pedidos' => 0,
    'faturamento' => 0
], $periodo ?? []);

$topProdutos = $topProdutos ?? [];
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Relatórios — NexGames</title>

    <link rel="icon"
          type="image/png"
          href="public/assets/img/dashboard.png">

    <!-- CSS existentes -->
    <link rel="stylesheet"
          href="public/assets/css/style.css">

    <link rel="stylesheet"
          href="public/assets/css/nex.css">

    <!-- CSS exclusivo -->
    <link rel="stylesheet"
          href="public/assets/css/relatorios.css">
</head>

<body class="nx-relatorios">

    <!-- CABEÇALHO -->
    <header class="nx-rel-header">

        <div class="nx-rel-header-inner">

            <!-- LOGO -->
            <a
                class="nx-rel-logo"
                href="<?= e(url('auth', 'dashboard')) ?>"
                title="Voltar ao Dashboard">

               <img
                src="public/assets/img/logo-nex.jpeg?v=20261116"
                alt="NEX Gaming Store">

            </a>

            <!-- ADMINISTRADOR -->
            <div class="nx-rel-admin">

                <span class="nx-rel-avatar"
                      aria-hidden="true">
                    ●
                </span>

                <div class="nx-rel-admin-info">

                    <strong>
                        <?= e($nomeUser) ?>
                    </strong>

                    <a href="<?= e(url('auth', 'dashboard')) ?>">
                        Dashboard
                    </a>

                    <a href="<?= e(url('auth', 'logout')) ?>">
                        Sair
                    </a>

                </div>

            </div>

        </div>

    </header>

    <!-- CONTEÚDO PRINCIPAL -->
    <main class="nx-rel-container">

        <!-- IDENTIFICAÇÃO -->
        <div class="nx-rel-pagebar">

            <span class="nx-rel-chip">
                Relatórios
            </span>

        </div>

        <!-- PRIMEIRO PAINEL -->
        <section class="nx-rel-panel nx-rel-summary">

            <h1>Relatórios</h1>

            <p class="nx-rel-subtitle">
                Resumo das informações da sua loja
            </p>

            <!-- INDICADORES -->
            <div class="nx-rel-kpis">

                <!-- TOTAL DE VENDAS -->
                <div class="nx-rel-kpi">

                    <span class="nx-rel-kpi-label">
                        Total de vendas
                    </span>

                    <strong class="nx-rel-kpi-value">
                        <?= (int) $resumo['total_vendas'] ?>
                    </strong>

                </div>

                <!-- PEDIDOS REALIZADOS -->
                <div class="nx-rel-kpi">

                    <span class="nx-rel-kpi-label">
                        Pedidos Realizados
                    </span>

                    <strong class="nx-rel-kpi-value">
                        <?= (int) $resumo['pedidos_realizados'] ?>
                    </strong>

                </div>

                <!-- CLIENTES ATIVOS -->
                <div class="nx-rel-kpi">

                    <span class="nx-rel-kpi-label">
                        Clientes ativos
                    </span>

                    <strong class="nx-rel-kpi-value">
                        <?= (int) $resumo['clientes_ativos'] ?>
                    </strong>

                </div>

                <!-- PRODUTOS CADASTRADOS -->
                <div class="nx-rel-kpi">

                    <span class="nx-rel-kpi-label">
                        Produtos cadastrados
                    </span>

                    <strong class="nx-rel-kpi-value">
                        <?= (int) $resumo['produtos_cadastrados'] ?>
                    </strong>

                </div>

            </div>

        </section>

        <!-- SEGUNDO PAINEL -->
        <section class="nx-rel-panel nx-rel-products">

            <h2>Produtos mais vendidos</h2>

            <?php if (empty($topProdutos)): ?>

                <div class="nx-rel-empty">
                    Nenhum produto encontrado
                </div>

            <?php else: ?>

                <div class="nx-rel-table-scroll">

                    <table class="nx-rel-table">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Jogo</th>
                                <th>Vendas</th>
                                <th>Faturamento</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($topProdutos as $i => $p): ?>

                                <tr>

                                    <td>
                                        <?= $i + 1 ?>
                                    </td>

                                    <td>
                                        <?= e($p['nome']) ?>
                                    </td>

                                    <td class="nx-rel-num">
                                        <?= (int) $p['total_vendido'] ?>
                                    </td>

                                    <td class="nx-rel-num">
                                        <?= moeda($p['receita']) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

        <!-- TERCEIRO PAINEL -->
        <section class="nx-rel-panel nx-rel-general">

            <h2>Informações gerais</h2>

            <div class="nx-rel-info">

                <!-- PERÍODO -->
                <div class="nx-rel-info-item">

                    <span class="nx-rel-info-label">
                        Período analisado
                    </span>

                    <strong class="nx-rel-info-value">
                        Últimos <?= (int) $periodo['dias'] ?> dias
                    </strong>

                </div>

                <!-- PEDIDOS -->
                <div class="nx-rel-info-item">

                    <span class="nx-rel-info-label">
                        Total de pedidos
                    </span>

                    <strong class="nx-rel-info-value">
                        <?= (int) $periodo['total_pedidos'] ?>
                    </strong>

                </div>

                <!-- FATURAMENTO -->
                <div class="nx-rel-info-item">

                    <span class="nx-rel-info-label">
                        Faturamento total
                    </span>

                    <strong class="nx-rel-info-value">
                        <?= moeda($periodo['faturamento']) ?>
                    </strong>

                </div>

            </div>

        </section>

        <!-- EXPORTAÇÃO -->
        <div class="nx-rel-actions">

            <a
                class="nx-rel-btn"
                href="<?= e(url('relatorio', 'exportarExcel')) ?>">

                Exportar para Excel

            </a>

            <a
                class="nx-rel-btn nx-rel-btn-outline"
                href="<?= e(url('relatorio', 'exportarPdf')) ?>">

                Exportar para PDF

            </a>

        </div>

    </main>

</body>
</html>
