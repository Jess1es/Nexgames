
<?php

$nomeUser = (string) ($_SESSION['nome'] ?? 'Administrador');

$categorias = isset($categorias) && is_array($categorias)
    ? $categorias
    : [];

$editar = isset($editar) && is_array($editar)
    ? $editar
    : null;

/* Dados da categoria em edição */

$editando = $editar !== null;

$idEdicao = (int) ($editar['id_categoria'] ?? 0);
$nomeEdicao = (string) ($editar['nome'] ?? '');
$descricaoEdicao = (string) ($editar['descricao'] ?? '');

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Categorias — NexGames</title>

    <link
        rel="icon"
        type="image/png"
        href="public/assets/img/dashboard.png"
    >

    <link
        rel="stylesheet"
        href="public/assets/css/style.css"
    >

    <link
        rel="stylesheet"
        href="public/assets/css/nex.css"
    >

    <link
        rel="stylesheet"
        href="public/assets/css/categorias.css"
    >
</head>

<body class="nx-categorias">

    <!-- Cabeçalho -->

    <header class="nx-cat-header">

        <div class="nx-cat-header-inner">

            <!-- Logo -->

            <a
                class="nx-cat-logo"
                href="<?= e(url('auth', 'dashboard')) ?>"
            >
                <img
                    src="public/assets/img/logo-nex.jpeg?v=20261116"
                    alt="NexGames"
                >
            </a>

            <!-- Administrador -->

            <div class="nx-cat-admin">

                <div class="nx-cat-avatar" aria-hidden="true">
                    ●
                </div>

                <div class="nx-cat-admin-info">

                    <strong>
                        <?= e($nomeUser) ?>
                    </strong>

                    <a href="<?= e(url('auth', 'dashboard')) ?>">
                        Dashboard
                    </a>

                    <a href="<?= e(url('auth', 'logout')) ?>">
                        Sair
                    </a>

                </div>

            </div>

        </div>

    </header>

    <!-- Conteúdo principal -->

    <main class="nx-cat-container">

        <div class="nx-cat-pagebar">

            <span class="nx-cat-chip">
                Categorias
            </span>

        </div>

        <div class="nx-cat-layout">

            <!-- Cadastro e edição -->

            <section class="nx-cat-form-panel">

                <h1>
                    <?= $editando
                        ? 'Editar categoria'
                        : 'Cadastrar categoria' ?>
                </h1>

                <?php if ($editando): ?>

                    <p class="nx-cat-editing">
                        Editando categoria #<?= $idEdicao ?>
                    </p>

                <?php endif; ?>

                <form
                    method="post"
                    action="<?= e(url('categoria', 'salvar')) ?>"
                >

                    <?= csrfCampo() ?>

                    <!-- ID esperado pelo CategoriaController -->

                    <input
                        type="hidden"
                        name="id"
                        value="<?= $idEdicao ?>"
                    >

                    <!-- Nome -->

                    <div class="nx-cat-field">

                        <label for="nome">
                            Nome
                        </label>

                        <input
                            type="text"
                            id="nome"
                            name="nome"
                            maxlength="150"
                            placeholder="Digite o nome da categoria..."
                            value="<?= e($nomeEdicao) ?>"
                            required
                        >

                    </div>

                    <!-- Descrição -->

                    <div class="nx-cat-field">

                        <label for="descricao">
                            Descrição
                        </label>

                        <textarea
                            id="descricao"
                            name="descricao"
                            rows="5"
                            placeholder="Digite a descrição da categoria..."
                            required
                        ><?= e($descricaoEdicao) ?></textarea>

                    </div>

                    <!-- Botões -->

                    <div class="nx-cat-form-actions">

                        <button
                            type="submit"
                            class="nx-cat-btn-save"
                        >
                            <?= $editando
                                ? 'Salvar alterações'
                                : 'Salvar categoria' ?>
                        </button>

                        <a
                            class="nx-cat-btn-clear"
                            href="<?= e(url('categoria', 'index')) ?>"
                        >
                            <?= $editando ? 'Cancelar' : 'Limpar' ?>
                        </a>

                    </div>

                </form>

            </section>

            <!-- Listagem de categorias -->

            <section class="nx-cat-list-panel">

                <div class="nx-cat-table-wrapper">

                    <table class="nx-cat-table">

                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Jogos</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php if (empty($categorias)): ?>

                                <tr>
                                    <td
                                        colspan="5"
                                        class="nx-cat-empty"
                                    >
                                        Nenhuma categoria cadastrada.
                                    </td>
                                </tr>

                            <?php else: ?>

                                <?php foreach ($categorias as $categoria): ?>

                                    <?php
                                    if (!is_array($categoria)) {
                                        continue;
                                    }

                                    /* Dados da categoria */

                                    $idCategoria = (int) (
                                        $categoria['id_categoria'] ?? 0
                                    );

                                    $nomeCategoria = (string) (
                                        $categoria['nome'] ?? ''
                                    );

                                    $descricaoCategoria = (string) (
                                        $categoria['descricao'] ?? ''
                                    );

                                    $quantidadeJogos = (int) (
                                        $categoria['qtd_produtos'] ?? 0
                                    );

                                    $ativo = (int) (
                                        $categoria['ativo'] ?? 0
                                    );

                                    $categoriaAtiva = $ativo === 1;
                                    ?>

                                    <tr>

                                        <!-- ID -->

                                        <td class="nx-cat-id">
                                            #<?= $idCategoria ?>
                                        </td>

                                        <!-- Nome e descrição -->

                                        <td class="nx-cat-name">

                                            <strong>
                                                <?= e($nomeCategoria) ?>
                                            </strong>

                                            <?php if ($descricaoCategoria !== ''): ?>

                                                <small>
                                                    <?= e($descricaoCategoria) ?>
                                                </small>

                                            <?php endif; ?>

                                        </td>

                                        <!-- Quantidade de jogos -->

                                        <td class="nx-cat-count">
                                            <?= $quantidadeJogos ?>
                                        </td>

                                        <!-- Status -->

                                        <td>

                                            <?php if ($categoriaAtiva): ?>

                                                <span class="nx-cat-status nx-cat-status-active">
                                                    Ativa
                                                </span>

                                            <?php else: ?>

                                                <span class="nx-cat-status nx-cat-status-inactive">
                                                    Inativa
                                                </span>

                                            <?php endif; ?>

                                        </td>

                                        <!-- Ações -->

                                        <td>

                                            <div class="nx-cat-row-actions">

                                                <!-- Editar -->

                                                <a
                                                    class="nx-cat-action-btn"
                                                    href="<?= e(url(
                                                        'categoria',
                                                        'index',
                                                        ['id' => $idCategoria]
                                                    )) ?>"
                                                >
                                                    Editar
                                                </a>

                                                <!-- Ativar ou inativar -->

                                                <form
                                                    method="post"
                                                    action="<?= e(url('categoria', 'toggle')) ?>"
                                                    <?= $categoriaAtiva
                                                        ? 'onsubmit="return confirm(\'Inativar esta categoria? Ela deixará de aparecer no menu da loja.\')"'
                                                        : '' ?>
                                                >

                                                    <?= csrfCampo() ?>

                                                    <input
                                                        type="hidden"
                                                        name="id_categoria"
                                                        value="<?= $idCategoria ?>"
                                                    >

                                                    <input
                                                        type="hidden"
                                                        name="ativo"
                                                        value="<?= $categoriaAtiva ? 0 : 1 ?>"
                                                    >

                                                    <button
                                                        type="submit"
                                                        class="nx-cat-action-btn"
                                                    >
                                                        <?= $categoriaAtiva
                                                            ? 'Inativar'
                                                            : 'Ativar' ?>
                                                    </button>

                                                </form>

                                                <!-- Excluir -->

                                                <form
                                                    method="post"
                                                    action="<?= e(url('categoria', 'deletar')) ?>"
                                                    onsubmit="return confirm('Excluir esta categoria permanentemente? A exclusão só será possível se não houver jogos vinculados.');"
                                                >

                                                    <?= csrfCampo() ?>

                                                    <input
                                                        type="hidden"
                                                        name="id_categoria"
                                                        value="<?= $idCategoria ?>"
                                                    >

                                                    <button
                                                        type="submit"
                                                        class="nx-cat-action-btn nx-cat-action-delete"
                                                    >
                                                        Excluir
                                                    </button>

                                                </form>

                                            </div>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </section>

        </div>

    </main>

</body>
</html>
