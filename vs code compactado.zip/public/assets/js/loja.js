
/* NexGames - Funções do cliente */

(function () {
    'use strict';

    /* Máscara de CPF */

    function mascaraCpf(valor) {
        valor = valor.replace(/\D/g, '').slice(0, 11);

        return valor
            .replace(/^(\d{3})(\d)/, '$1.$2')
            .replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
            .replace(/\.(\d{3})(\d)/, '.$1-$2');
    }

    /* Máscara de telefone */

    function mascaraTelefone(valor) {
        valor = valor.replace(/\D/g, '').slice(0, 11);

        if (valor.length > 10) {
            return valor.replace(
                /^(\d{2})(\d{5})(\d{4})$/,
                '($1) $2-$3'
            );
        }

        if (valor.length > 6) {
            return valor.replace(
                /^(\d{2})(\d{4})(\d{0,4})$/,
                '($1) $2-$3'
            );
        }

        if (valor.length > 2) {
            return valor.replace(
                /^(\d{2})(\d*)$/,
                '($1) $2'
            );
        }

        return valor;
    }

    /* Aplicar máscaras */

    document.querySelectorAll('[data-mascara]').forEach(function (campo) {
        var tipo = campo.dataset.mascara;

        if (tipo !== 'cpf' && tipo !== 'telefone') {
            return;
        }

        var formatar = tipo === 'cpf'
            ? mascaraCpf
            : mascaraTelefone;

        campo.addEventListener('input', function () {
            campo.value = formatar(campo.value);
        });
    });

    /* Atualização automática do carrinho */

    document.querySelectorAll('[data-autoenviar]').forEach(function (campo) {
        campo.addEventListener('change', function () {
            var quantidade = Number(campo.value);

            if (
                campo.form &&
                Number.isInteger(quantidade) &&
                quantidade >= 1
            ) {
                campo.form.requestSubmit();
            }
        });
    });

})();
