<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Configurações e funções auxiliares */

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/helpers.php';

/* Conexão com o banco */

Database::getConnection();

/* Rota padrão: página inicial da loja */

$controller = (string) ($_GET['controller'] ?? 'loja');
$action = (string) ($_GET['action'] ?? 'index');

/* Validação dos parâmetros */

$padraoRota = '/^[a-zA-Z][a-zA-Z0-9]*$/';

if (
    !preg_match($padraoRota, $controller) ||
    !preg_match($padraoRota, $action)
) {
    http_response_code(400);
    exit('Requisição inválida.');
}

/* Controllers disponíveis */

$controllers = [
    'auth' => 'AuthController',
    'produto' => 'ProdutoController',
    'venda' => 'VendaController',
    'relatorio' => 'RelatorioController',
    'usuario' => 'UsuarioController',
    'categoria' => 'CategoriaController',
    'fornecedor' => 'FornecedorController',
    'entrada' => 'EntradaController',
    'loja' => 'LojaController',
    'carrinho' => 'CarrinhoController',
    'cliente' => 'ClienteController',
    'pedido' => 'PedidoController',
    'avaliacao' => 'AvaliacaoController'
];

/* Verifica se o controller foi registrado */

if (!isset($controllers[$controller])) {
    http_response_code(404);
    exit('Controller inválido.');
}

/* Localiza o arquivo do controller */

$nomeController = $controllers[$controller];

$caminhoController = __DIR__
    . '/controllers/'
    . $nomeController
    . '.php';

/* Verifica se o arquivo existe */

if (!is_file($caminhoController)) {
    http_response_code(404);
    exit('Controller não encontrado.');
}

/* Carrega o controller */

require_once $caminhoController;

/* Verifica se a classe existe */

if (!class_exists($nomeController)) {
    http_response_code(500);
    exit('Classe do controller não encontrada.');
}

/* Instancia o controller */

$c = new $nomeController();

/* Verifica se a ação é válida */

if (
    str_starts_with($action, '__') ||
    !is_callable([$c, $action])
) {
    http_response_code(404);
    exit('Ação inválida.');
}

/* Executa a ação solicitada */

$c->$action();
